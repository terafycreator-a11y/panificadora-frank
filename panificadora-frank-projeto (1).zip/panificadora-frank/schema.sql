-- =============================================================================
-- PANIFICADORA FRANK - Schema do banco de dados (Cloudflare D1 / SQLite)
-- =============================================================================
-- Aplicar em producao:
--   npx wrangler d1 execute panificadora-frank-db --remote --file=./schema.sql
-- Aplicar localmente (desenvolvimento):
--   npx wrangler d1 execute panificadora-frank-db --local --file=./schema.sql
--
-- Este arquivo e idempotente: pode ser executado mais de uma vez.
-- =============================================================================

PRAGMA foreign_keys = ON;

-- -----------------------------------------------------------------------------
-- Versao do schema
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS app_meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
INSERT INTO app_meta (key, value) VALUES ('schema_version', '1')
  ON CONFLICT(key) DO UPDATE SET value = excluded.value;

-- -----------------------------------------------------------------------------
-- Administradores
-- A senha NUNCA e gravada em texto puro: usamos PBKDF2-SHA256.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  email                TEXT    NOT NULL UNIQUE,
  name                 TEXT    NOT NULL DEFAULT 'Administrador',
  password_hash        TEXT    NOT NULL,
  role                 TEXT    NOT NULL DEFAULT 'admin',
  active               INTEGER NOT NULL DEFAULT 1,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  last_login_at        TEXT,
  created_at           TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at           TEXT    NOT NULL DEFAULT (datetime('now')),
  CHECK (role IN ('admin', 'editor'))
);
CREATE INDEX IF NOT EXISTS idx_admins_email ON admins(email);

-- -----------------------------------------------------------------------------
-- Sessoes (cookie HttpOnly -> token aleatorio; o banco guarda apenas o hash)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sessions (
  id           TEXT    PRIMARY KEY,
  admin_id     INTEGER NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  token_hash   TEXT    NOT NULL UNIQUE,
  ip           TEXT,
  user_agent   TEXT,
  created_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  last_seen_at TEXT    NOT NULL DEFAULT (datetime('now')),
  expires_at   TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_admin   ON sessions(admin_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_sessions_token   ON sessions(token_hash);

-- -----------------------------------------------------------------------------
-- Midias / imagens enviadas pelo Painel ADM
-- Os arquivos ficam no proprio banco (D1) - o projeto NAO usa R2.
-- Limite por imagem: 2 MB (limite de linha do D1) - o upload comprime antes de enviar.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS media (
  id          TEXT    PRIMARY KEY,
  filename    TEXT    NOT NULL,
  mime_type   TEXT    NOT NULL,
  size        INTEGER NOT NULL,
  width       INTEGER,
  height      INTEGER,
  alt         TEXT    NOT NULL DEFAULT '',
  data        BLOB    NOT NULL,
  uploaded_by INTEGER REFERENCES admins(id) ON DELETE SET NULL,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_media_created ON media(created_at);

-- -----------------------------------------------------------------------------
-- Quadros / secoes dinamicas (criados pelo Painel ADM, sem alterar codigo)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sections (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  title        TEXT    NOT NULL,
  subtitle     TEXT    NOT NULL DEFAULT '',
  body         TEXT    NOT NULL DEFAULT '',
  image        TEXT    NOT NULL DEFAULT '',
  button_label TEXT    NOT NULL DEFAULT '',
  button_url   TEXT    NOT NULL DEFAULT '',
  button_style TEXT    NOT NULL DEFAULT 'primary',
  layout       TEXT    NOT NULL DEFAULT 'image-right',
  background   TEXT    NOT NULL DEFAULT 'light',
  active       INTEGER NOT NULL DEFAULT 1,
  sort_order   INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  CHECK (layout     IN ('image-right', 'image-left', 'image-top', 'no-image')),
  CHECK (background IN ('light', 'tint', 'dark')),
  CHECK (button_style IN ('primary', 'secondary', 'whatsapp'))
);
CREATE INDEX IF NOT EXISTS idx_sections_order ON sections(sort_order, id);

-- -----------------------------------------------------------------------------
-- Produtos
-- status: 'available'  -> sempre disponivel
--         'unavailable'-> sempre indisponivel
--         'auto'       -> disponivel ate o horario definido em available_until
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT    NOT NULL,
  description     TEXT    NOT NULL DEFAULT '',
  price           REAL,
  price_note      TEXT    NOT NULL DEFAULT '',
  image           TEXT    NOT NULL DEFAULT '',
  status          TEXT    NOT NULL DEFAULT 'available',
  available_until TEXT,
  active          INTEGER NOT NULL DEFAULT 1,
  highlight       INTEGER NOT NULL DEFAULT 0,
  sort_order      INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at      TEXT    NOT NULL DEFAULT (datetime('now')),
  CHECK (status IN ('available', 'unavailable', 'auto'))
);
CREATE INDEX IF NOT EXISTS idx_products_order  ON products(sort_order, id);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(active);

-- -----------------------------------------------------------------------------
-- Produtos relacionados a um quadro/secao (relacao N:N)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS section_products (
  section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (section_id, product_id)
);
CREATE INDEX IF NOT EXISTS idx_section_products_section ON section_products(section_id);

-- -----------------------------------------------------------------------------
-- Textos editaveis do site publico (chave -> valor)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS content_blocks (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- -----------------------------------------------------------------------------
-- Configuracoes gerais (chave -> valor)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- -----------------------------------------------------------------------------
-- Tentativas de login (rate limit / auditoria)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  email      TEXT    NOT NULL DEFAULT '',
  ip         TEXT    NOT NULL DEFAULT '',
  success    INTEGER NOT NULL DEFAULT 0,
  created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_login_attempts_lookup ON login_attempts(email, ip, created_at);

-- =============================================================================
-- DADOS INICIAIS (valores padrao editaveis pelo Painel ADM)
-- Nao ha senha padrao: o primeiro administrador e criado pelo assistente em /admin
-- =============================================================================

INSERT OR IGNORE INTO settings (key, value) VALUES
  ('company_name',        'Panificadora Frank'),
  ('company_tagline',     'Pao quentinho todos os dias'),
  ('logo_image',          ''),
  ('phone',               ''),
  ('whatsapp',            ''),
  ('whatsapp_message',    'Ola! Vim pelo site da Panificadora Frank e gostaria de fazer um pedido.'),
  ('instagram',           ''),
  ('facebook',            ''),
  ('tiktok',              ''),
  ('email',               ''),
  ('address_line',        ''),
  ('address_city',        ''),
  ('address_notes',       ''),
  ('google_maps_url',     ''),
  ('google_maps_embed',   ''),
  ('timezone',            'America/Sao_Paulo'),
  ('currency',            'BRL'),
  ('business_hours',      '[{"day":"monday","label":"Segunda-feira","closed":false,"open":"06:00","close":"19:00"},{"day":"tuesday","label":"Terca-feira","closed":false,"open":"06:00","close":"19:00"},{"day":"wednesday","label":"Quarta-feira","closed":false,"open":"06:00","close":"19:00"},{"day":"thursday","label":"Quinta-feira","closed":false,"open":"06:00","close":"19:00"},{"day":"friday","label":"Sexta-feira","closed":false,"open":"06:00","close":"19:00"},{"day":"saturday","label":"Sabado","closed":false,"open":"06:00","close":"18:00"},{"day":"sunday","label":"Domingo","closed":true,"open":"07:00","close":"12:00"}]'),
  ('seo_title',           'Panificadora Frank'),
  ('seo_description',     'Paes, bolos, salgados e doces feitos diariamente na Panificadora Frank.'),
  ('footer_note',         '');

INSERT OR IGNORE INTO content_blocks (key, value) VALUES
  ('hero.badge',            'Fornada quentinha todos os dias'),
  ('hero.title',            'Panificadora Frank'),
  ('hero.subtitle',         'Paes, bolos, salgados e doces preparados diariamente com receita de familia. Encomende pelo WhatsApp e retire na loja.'),
  ('hero.button_primary',   'Conhecer os produtos'),
  ('hero.button_secondary', 'Falar no WhatsApp'),
  ('hero.image',            '/assets/img/hero-panificadora.jpg'),
  ('about.title',           'Sobre a Panificadora Frank'),
  ('about.subtitle',        'Tradicao, forno quente e receita de familia'),
  ('about.body',            'A Panificadora Frank comeca o dia de madrugada: a massa descansa, o forno acende e, antes do sol nascer, o cheiro de pao fresco ja toma conta da rua.\n\nTrabalhamos com fermentacao natural, ingredientes selecionados e producao diaria. Do pao frances de casca crocante aos bolos e salgados de encomenda, tudo e preparado em pequenas fornadas para chegar fresquinho na sua mesa.\n\nVenha nos visitar, tomar um cafe e escolher o seu pao do dia.'),
  ('about.image',           '/assets/img/sobre-panificadora.jpg'),
  ('products.title',        'Nossos produtos'),
  ('products.subtitle',     'Producao diaria. Confira abaixo o que esta disponivel agora.'),
  ('contact.title',         'Fale com a gente'),
  ('contact.subtitle',      'Encomendas, duvidas e orcamentos: e so chamar no WhatsApp.'),
  ('location.title',        'Onde estamos'),
  ('location.subtitle',     'Passe na loja e escolha o seu pao quentinho.'),
  ('footer.about',          'Panificadora Frank - pao fresquinho, bolos e salgados feitos no dia.'),
  ('footer.rights',         'Todos os direitos reservados.');