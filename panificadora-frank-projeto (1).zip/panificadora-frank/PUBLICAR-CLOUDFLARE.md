# Publicar na Cloudflare — guia rápido (copiar e colar)

> Guia curto para colocar o site da Panificadora Frank no ar.
> A explicação completa está no [README.md](./README.md).

## Antes de começar

- Conta na Cloudflare (o plano gratuito é suficiente).
- Node.js 18+ instalado no seu computador.
- O projeto descompactado em uma pasta.

## Passo 1 — Instalar o Wrangler e entrar na conta

```bash
cd panificadora-frank
npm install
npx wrangler login
```

O navegador abre para você autorizar. Depois disso, o terminal fica conectado à sua conta.

## Passo 2 — Criar o banco de dados

```bash
npx wrangler d1 create panificadora-frank-db
```

O comando imprime um `database_id`. **Copie esse valor** e substitua
`COLE_AQUI_O_DATABASE_ID` no arquivo `wrangler.toml`:

```toml
[[d1_databases]]
binding = "DB"
database_name = "panificadora-frank-db"
database_id = "cole-o-id-aqui"      # <-- troque esta linha
migrations_dir = "migrations"
```

## Passo 3 — Criar as tabelas no banco de produção

```bash
npm run db:remote
```

> Pode rodar quantas vezes quiser: o script não apaga dados existentes.

## Passo 4 — Publicar

```bash
npm run deploy
```

No fim, o terminal mostra algo como:

```
https://panificadora-frank.seu-usuario.workers.dev
```

## Passo 5 — Criar o primeiro administrador

Abra `https://SEU-ENDERECO/admin/`. Como ainda não existe administrador, aparece a tela
**“Configuracao inicial”** — crie seu e-mail e senha ali e pronto.

Alternativa por linha de comando:

```bash
node scripts/create-admin.mjs --email seu@email.com --senha "SuaSenha123" --nome "Seu Nome"
```

## Passo 6 — Preencher os dados reais da padaria

Entre em `/admin/` e vá em **Configuracoes**:

| Campo | O que preencher |
| --- | --- |
| Nome da empresa | Panificadora Frank |
| Telefone | telefone da loja |
| WhatsApp | número com país e DDD (ex.: `5511999999999`) |
| Instagram | `@seu_instagram` ou o link completo |
| Endereço | rua, número, cidade |
| Link do Google Maps | link de compartilhar do Maps |
| Link de incorporar o mapa | veja o passo 7 |
| Horários | marque os dias fechados e os horários |

Depois vá em **Textos** (para a história da padaria e as frases do site) e em
**Produtos** (para cadastrar seus pães, bolos e salgados com foto e preço).

## Passo 7 — Como pegar o link de incorporar o mapa

1. Abra o Google Maps e encontre a padaria.
2. Clique em **Compartilhar** → aba **Incorporar um mapa**.
3. Copie **apenas o endereço que começa com `https://www.google.com/maps/embed?pb=...`**
   (não copie a tag `<iframe>` inteira).
4. Cole no campo **“Link de incorporar o mapa”** no Painel ADM.

## Passo 8 — Domínio próprio (opcional)

No painel da Cloudflare:

**Workers & Pages → panificadora-frank → Settings → Domains & Routes → Add custom domain**

Informe `www.panificadorafrank.com.br` (ou o domínio desejado). A Cloudflare cuida do DNS
e do certificado HTTPS automaticamente.

---

## Checklist final

- [ ] `database_id` preenchido no `wrangler.toml`
- [ ] `npm run db:remote` executado com sucesso
- [ ] `npm run deploy` concluído
- [ ] Primeiro administrador criado em `/admin/`
- [ ] Telefone, WhatsApp, Instagram e endereço preenchidos em Configurações
- [ ] Horários de atendimento conferidos
- [ ] Produtos cadastrados com foto e preço
- [ ] Textos da seção “Sobre” atualizados com a história real da padaria
- [ ] Site aberto no celular para conferência final

---

## Problemas comuns

| Sintoma | Causa provável | Solução |
| --- | --- | --- |
| `Error: database_id is not a valid UUID` | o ID ainda é o valor de exemplo | copie o ID real do passo 2 |
| Site abre, mas os produtos não aparecem | tabelas não criadas | rode `npm run db:remote` |
| “E-mail ou senha incorretos” e não existe admin | primeiro admin não foi criado | abra `/admin/` ou use o `create-admin.mjs` |
| Imagem recusada no upload | arquivo maior que 2 MB depois da compressão | reduza a imagem ou envie JPG |
| Erro `authenticated` ao publicar | sessão do wrangler expirada | rode `npx wrangler login` de novo |
| Mapa não aparece, só o botão | falta o link de *incorporar* | veja o passo 7 |

## Atualizar o site depois de mudar o código

```bash
npm run deploy
```

Os dados do banco (produtos, textos, imagens) **não** são afetados pelo deploy.
