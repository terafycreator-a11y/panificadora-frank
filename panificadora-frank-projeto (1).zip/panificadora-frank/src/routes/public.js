/**
 * Rotas publicas (nao exigem autenticacao).
 *   GET /api/site            -> todo o conteudo do site publico em uma unica chamada
 *   GET /api/products        -> apenas os produtos
 *   GET /api/media/:id       -> serve a imagem guardada no D1
 *   GET /api/health          -> diagnostico (usado no guia de publicacao)
 */

import { fail, json, parseJsonSafe, nowInTimezone, minutesFromTime } from '../lib/util.js';

/* -------------------------------------------------------------------------- */
/* Disponibilidade                                                            */
/* -------------------------------------------------------------------------- */

export function businessHoursList(raw) {
  const parsed = parseJsonSafe(raw, []);
  return Array.isArray(parsed) ? parsed : [];
}

/**
 * Calcula se o produto esta DISPONIVEL agora.
 * Retorna { available, reason, detail }.
 *  reason: 'status'   -> definido manualmente pelo ADM
 *          'schedule' -> disponibilidade automatica por horario
 *          'closed'   -> loja fechada no dia/horario atual
 */
export function resolveAvailability(product, { hours, timezone, now }) {
  if (Number(product.active) !== 1) {
    return { available: false, reason: 'status', detail: 'Produto desativado no Painel ADM.' };
  }

  if (product.status === 'unavailable') {
    return { available: false, reason: 'status', detail: 'Marcado como nao disponivel.' };
  }

  if (product.status === 'available') {
    return { available: true, reason: 'status', detail: 'Disponivel sempre.' };
  }

  // status === 'auto'
  const today = hours.find((h) => h && h.day === now.weekday);
  const limit = product.available_until ? minutesFromTime(product.available_until) : null;
  const nowMinutes = minutesFromTime(now.time);

  if (limit !== null && nowMinutes !== null && nowMinutes > limit) {
    return {
      available: false,
      reason: 'schedule',
      detail: `Disponivel ate ${product.available_until}.`,
    };
  }

  if (!today || today.closed) {
    return { available: false, reason: 'closed', detail: 'Loja fechada hoje.' };
  }

  const open = minutesFromTime(today.open);
  const close = minutesFromTime(today.close);
  if (open !== null && nowMinutes !== null && nowMinutes < open) {
    return { available: false, reason: 'closed', detail: `A loja abre as ${today.open}.` };
  }
  if (close !== null && nowMinutes !== null && nowMinutes > close) {
    return { available: false, reason: 'closed', detail: `A loja fechou as ${today.close}.` };
  }

  return {
    available: true,
    reason: 'schedule',
    detail: limit !== null ? `Disponivel ate ${product.available_until}.` : 'Disponivel agora.',
  };
}

/* -------------------------------------------------------------------------- */
/* Consultas                                                                  */
/* -------------------------------------------------------------------------- */

export async function fetchSettings(env) {
  const { results } = await env.DB.prepare(`SELECT key, value FROM settings`).all();
  const out = {};
  for (const row of results || []) out[row.key] = row.value;
  return out;
}

export async function fetchContent(env) {
  const { results } = await env.DB.prepare(`SELECT key, value FROM content_blocks`).all();
  const out = {};
  for (const row of results || []) out[row.key] = row.value;
  return out;
}

export async function fetchProducts(env, { onlyActive = true } = {}) {
  const sql = onlyActive
    ? `SELECT * FROM products WHERE active = 1 ORDER BY sort_order ASC, id ASC`
    : `SELECT * FROM products ORDER BY sort_order ASC, id ASC`;
  const { results } = await env.DB.prepare(sql).all();
  return results || [];
}

export async function fetchSections(env, { onlyActive = true } = {}) {
  const sql = onlyActive
    ? `SELECT * FROM sections WHERE active = 1 ORDER BY sort_order ASC, id ASC`
    : `SELECT * FROM sections ORDER BY sort_order ASC, id ASC`;
  const { results } = await env.DB.prepare(sql).all();
  return results || [];
}

export async function fetchSectionProductLinks(env, sectionIds = []) {
  if (!sectionIds.length) return new Map();
  const placeholders = sectionIds.map(() => '?').join(',');
  const { results } = await env.DB.prepare(
    `SELECT section_id, product_id FROM section_products
      WHERE section_id IN (${placeholders})
      ORDER BY section_id, sort_order, product_id`
  )
    .bind(...sectionIds)
    .all();

  const map = new Map();
  for (const row of results || []) {
    if (!map.has(row.section_id)) map.set(row.section_id, []);
    map.get(row.section_id).push(row.product_id);
  }
  return map;
}

/** Monta a lista de produtos com disponibilidade resolvida e preco formatado. */
export function decorateProducts(products, settings) {
  const hours = businessHoursList(settings.business_hours);
  const timezone = settings.timezone || 'America/Sao_Paulo';
  const now = nowInTimezone(timezone);

  return products.map((p) => {
    const availability = resolveAvailability(p, { hours, timezone, now });
    return {
      id: p.id,
      name: p.name,
      description: p.description,
      price: p.price,
      price_formatted: formatPrice(p.price, settings.currency),
      price_note: p.price_note,
      image: p.image,
      status: p.status,
      available_until: p.available_until,
      highlight: Number(p.highlight) === 1,
      sort_order: p.sort_order,
      availability,
    };
  });
}

export function formatPrice(price, currency = 'BRL') {
  if (price === null || price === undefined || price === '') return '';
  const value = Number(price);
  if (!Number.isFinite(value)) return '';
  try {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: currency || 'BRL' }).format(value);
  } catch {
    return `R$ ${value.toFixed(2).replace('.', ',')}`;
  }
}

/* -------------------------------------------------------------------------- */
/* Handlers                                                                   */
/* -------------------------------------------------------------------------- */

export async function handleSiteData(env) {
  const [settings, content, products, sections] = await Promise.all([
    fetchSettings(env),
    fetchContent(env),
    fetchProducts(env, { onlyActive: true }),
    fetchSections(env, { onlyActive: true }),
  ]);

  const links = await fetchSectionProductLinks(env, sections.map((s) => s.id));
  const decorated = decorateProducts(products, settings);
  const byId = new Map(decorated.map((p) => [p.id, p]));

  const hours = businessHoursList(settings.business_hours);
  const now = nowInTimezone(settings.timezone || 'America/Sao_Paulo');
  const today = hours.find((h) => h && h.day === now.weekday) || null;
  const storeOpen = Boolean(today && !today.closed);

  return json({
    settings: publicSettings(settings),
    content,
    hours,
    products: decorated.filter((p) => p.availability.available),
    all_products: decorated,
    sections: sections.map((s) => ({
      id: s.id,
      title: s.title,
      subtitle: s.subtitle,
      body: s.body,
      image: s.image,
      button_label: s.button_label,
      button_url: s.button_url,
      button_style: s.button_style,
      layout: s.layout,
      background: s.background,
      products: (links.get(s.id) || []).map((pid) => byId.get(pid)).filter(Boolean),
    })),
    store: {
      open_now: storeOpen && isWithinHours(today, now.time),
      today,
      now: { time: now.time, weekday: now.weekday, date: now.date },
    },
  });
}

function isWithinHours(today, currentTime) {
  if (!today || today.closed) return false;
  const current = minutesFromTime(currentTime);
  const open = minutesFromTime(today.open);
  const close = minutesFromTime(today.close);
  if (current === null) return false;
  if (open !== null && current < open) return false;
  if (close !== null && current > close) return false;
  return true;
}

/** Nunca expor segredos/chaves internas ao publico. */
function publicSettings(settings) {
  const blocked = new Set(['setup_token']);
  const out = {};
  for (const [key, value] of Object.entries(settings)) {
    if (blocked.has(key)) continue;
    out[key] = value;
  }
  return out;
}

export async function handlePublicProducts(env) {
  const settings = await fetchSettings(env);
  const products = await fetchProducts(env, { onlyActive: true });
  const decorated = decorateProducts(products, settings);
  return json({ products: decorated.filter((p) => p.availability.available) });
}

export async function handleMedia(env, id) {
  const cleanId = String(id || '').replace(/[^A-Za-z0-9_-]/g, '');
  if (!cleanId) return fail(400, 'Identificador de imagem invalido.');

  const row = await env.DB.prepare(
    `SELECT mime_type, data, filename, created_at FROM media WHERE id = ? LIMIT 1`
  )
    .bind(cleanId)
    .first();

  if (!row || !row.data) return fail(404, 'Imagem nao encontrada.');

  const bytes = typeof row.data === 'string' ? base64ToBytes(row.data) : row.data;
  return new Response(bytes, {
    headers: {
      'content-type': row.mime_type || 'image/jpeg',
      'cache-control': 'public, max-age=31536000, immutable',
      'content-length': String(bytes.byteLength ?? bytes.length ?? 0),
      'x-content-type-options': 'nosniff',
    },
  });
}

export function base64ToBytes(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

export async function handleHealth(env, request) {
  let db = 'ok';
  let counts = {};
  try {
    const [p, s, m] = await Promise.all([
      env.DB.prepare(`SELECT COUNT(*) AS total FROM products`).first(),
      env.DB.prepare(`SELECT COUNT(*) AS total FROM sections`).first(),
      env.DB.prepare(`SELECT COUNT(*) AS total FROM media`).first(),
    ]);
    counts = {
      products: Number(p?.total || 0),
      sections: Number(s?.total || 0),
      media: Number(m?.total || 0),
    };
  } catch (error) {
    db = `erro: ${error.message}`;
  }

  const adminRow = await env.DB.prepare(`SELECT COUNT(*) AS total FROM admins WHERE active = 1`)
    .first()
    .catch(() => null);

  return json({
    status: db === 'ok' ? 'ok' : 'degradado',
    app: env.APP_NAME || 'Panificadora Frank',
    environment: env.APP_ENV || 'unknown',
    database: db,
    counts,
    admins: Number(adminRow?.total || 0),
    setup_required: Number(adminRow?.total || 0) === 0,
    kv_enabled: Boolean(env.SESSION_KV),
    time: new Date().toISOString(),
  });
}