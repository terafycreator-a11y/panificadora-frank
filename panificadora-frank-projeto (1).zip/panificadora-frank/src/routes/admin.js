/**
 * Rotas administrativas (todas exigem sessao valida).
 *   Produtos  -> /api/admin/products
 *   Secoes    -> /api/admin/sections
 *   Config.   -> /api/admin/settings
 *   Textos    -> /api/admin/content
 *   Imagens   -> /api/admin/media  (+ /api/media/:id para leitura publica)
 */

import {
  ALLOWED_IMAGE_TYPES,
  MAX_IMAGE_BYTES,
  bool,
  fail,
  int,
  isTime,
  json,
  num,
  ok,
  randomId,
  readJson,
  safeUrl,
  str,
  text,
} from '../lib/util.js';
import { fetchSectionProductLinks } from './public.js';

const PRODUCT_STATUS = ['available', 'unavailable', 'auto'];
const SECTION_LAYOUTS = ['image-right', 'image-left', 'image-top', 'no-image'];
const SECTION_BACKGROUNDS = ['light', 'tint', 'dark'];
const BUTTON_STYLES = ['primary', 'secondary', 'whatsapp'];

/* -------------------------------------------------------------------------- */
/* Produtos                                                                   */
/* -------------------------------------------------------------------------- */

export async function listProducts(env) {
  const { results } = await env.DB.prepare(
    `SELECT id, name, description, price, price_note, image, status, available_until,
            active, highlight, sort_order, created_at, updated_at
       FROM products ORDER BY sort_order ASC, id ASC`
  ).all();
  return ok({ products: results || [] });
}

export function normalizeProduct(body, existing = null) {
  const name = str(body.name, { max: 160 });
  if (!name) return { error: 'O nome do produto e obrigatorio.' };

  const status = PRODUCT_STATUS.includes(body.status) ? body.status : 'available';
  const availableUntil = status === 'auto' ? isTime(body.available_until) : null;
  if (status === 'auto' && !availableUntil) {
    return { error: 'Informe um horario valido (HH:MM) em "Disponivel ate".' };
  }

  return {
    data: {
      name,
      description: text(body.description, { max: 4000 }),
      price: num(body.price),
      price_note: str(body.price_note, { max: 120 }),
      image: safeUrl(body.image),
      status,
      available_until: availableUntil,
      active: bool(body.active, existing ? Number(existing.active) === 1 : true) ? 1 : 0,
      highlight: bool(body.highlight, existing ? Number(existing.highlight) === 1 : false) ? 1 : 0,
      sort_order: int(body.sort_order, {
        fallback: existing ? Number(existing.sort_order) : 0,
        min: 0,
        max: 100000,
      }),
    },
  };
}

export async function createProduct(request, env) {
  const body = await readJson(request);
  if (!body) return fail(400, 'Dados invalidos.');

  const { data, error } = normalizeProduct(body);
  if (error) return fail(400, error);

  if (!body.sort_order) {
    const row = await env.DB.prepare(`SELECT COALESCE(MAX(sort_order), 0) + 10 AS next FROM products`).first();
    data.sort_order = Number(row?.next || 10);
  }

  const result = await env.DB.prepare(
    `INSERT INTO products (name, description, price, price_note, image, status, available_until, active, highlight, sort_order)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      data.name,
      data.description,
      data.price,
      data.price_note,
      data.image,
      data.status,
      data.available_until,
      data.active,
      data.highlight,
      data.sort_order
    )
    .run();

  const id = result.meta?.last_row_id;
  return json({ ok: true, id, message: 'Produto criado com sucesso.' }, { status: 201 });
}

export async function updateProduct(request, env, id) {
  const body = await readJson(request);
  if (!body) return fail(400, 'Dados invalidos.');

  const existing = await env.DB.prepare(`SELECT * FROM products WHERE id = ?`).bind(id).first();
  if (!existing) return fail(404, 'Produto nao encontrado.');

  const { data, error } = normalizeProduct(body, existing);
  if (error) return fail(400, error);

  await env.DB.prepare(
    `UPDATE products SET name = ?, description = ?, price = ?, price_note = ?, image = ?,
            status = ?, available_until = ?, active = ?, highlight = ?, sort_order = ?,
            updated_at = datetime('now')
      WHERE id = ?`
  )
    .bind(
      data.name,
      data.description,
      data.price,
      data.price_note,
      data.image,
      data.status,
      data.available_until,
      data.active,
      data.highlight,
      data.sort_order,
      id
    )
    .run();

  return ok({ id, message: 'Produto atualizado com sucesso.' });
}

export async function deleteProduct(env, id) {
  const existing = await env.DB.prepare(`SELECT id FROM products WHERE id = ?`).bind(id).first();
  if (!existing) return fail(404, 'Produto nao encontrado.');

  await env.DB.prepare(`DELETE FROM products WHERE id = ?`).bind(id).run();
  return ok({ message: 'Produto excluido.' });
}

/** Reordena produtos. body: { order: [id, id, ...] } */
export async function reorderProducts(request, env) {
  const body = await readJson(request);
  const order = Array.isArray(body?.order) ? body.order.map((v) => int(v)).filter((v) => v > 0) : [];
  if (!order.length) return fail(400, 'Lista de ordem invalida.');

  const statements = order.map((productId, index) =>
    env.DB.prepare(`UPDATE products SET sort_order = ?, updated_at = datetime('now') WHERE id = ?`).bind(
      (index + 1) * 10,
      productId
    )
  );
  await env.DB.batch(statements);
  return ok({ message: 'Ordem atualizada.' });
}

/* -------------------------------------------------------------------------- */
/* Secoes / quadros dinamicos                                                  */
/* -------------------------------------------------------------------------- */

export async function listSections(env) {
  const { results } = await env.DB.prepare(
    `SELECT * FROM sections ORDER BY sort_order ASC, id ASC`
  ).all();
  const sections = results || [];
  const links = await fetchSectionProductLinks(env, sections.map((s) => s.id));

  return ok({
    sections: sections.map((s) => ({ ...s, product_ids: links.get(s.id) || [] })),
  });
}

function normalizeSection(body, existing = null) {
  const title = str(body.title, { max: 160 });
  if (!title) return { error: 'O titulo da secao e obrigatorio.' };

  const buttonLabel = str(body.button_label, { max: 80 });
  const buttonUrl = safeUrl(body.button_url);
  if (buttonLabel && !buttonUrl) {
    return { error: 'Informe o link do botao (endereco interno, https://, mailto: ou tel:).' };
  }

  const productIds = Array.isArray(body.product_ids)
    ? body.product_ids.map((v) => int(v)).filter((v) => v > 0).slice(0, 60)
    : [];

  return {
    data: {
      title,
      subtitle: str(body.subtitle, { max: 240 }),
      body: text(body.body, { max: 8000 }),
      image: safeUrl(body.image),
      button_label: buttonLabel,
      button_url: buttonUrl,
      button_style: BUTTON_STYLES.includes(body.button_style) ? body.button_style : 'primary',
      layout: SECTION_LAYOUTS.includes(body.layout) ? body.layout : 'image-right',
      background: SECTION_BACKGROUNDS.includes(body.background) ? body.background : 'light',
      active: bool(body.active, existing ? Number(existing.active) === 1 : true) ? 1 : 0,
      sort_order: int(body.sort_order, {
        fallback: existing ? Number(existing.sort_order) : 0,
        min: 0,
        max: 100000,
      }),
      product_ids: productIds,
    },
  };
}

async function syncSectionProducts(env, sectionId, productIds) {
  await env.DB.prepare(`DELETE FROM section_products WHERE section_id = ?`).bind(sectionId).run();
  if (!productIds.length) return;
  const statements = productIds.map((productId, index) =>
    env.DB.prepare(`INSERT OR IGNORE INTO section_products (section_id, product_id, sort_order) VALUES (?, ?, ?)`).bind(
      sectionId,
      productId,
      (index + 1) * 10
    )
  );
  await env.DB.batch(statements);
}

export async function createSection(request, env) {
  const body = await readJson(request);
  if (!body) return fail(400, 'Dados invalidos.');

  const { data, error } = normalizeSection(body);
  if (error) return fail(400, error);

  if (!body.sort_order) {
    const row = await env.DB.prepare(`SELECT COALESCE(MAX(sort_order), 0) + 10 AS next FROM sections`).first();
    data.sort_order = Number(row?.next || 10);
  }

  const result = await env.DB.prepare(
    `INSERT INTO sections (title, subtitle, body, image, button_label, button_url, button_style, layout, background, active, sort_order)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      data.title,
      data.subtitle,
      data.body,
      data.image,
      data.button_label,
      data.button_url,
      data.button_style,
      data.layout,
      data.background,
      data.active,
      data.sort_order
    )
    .run();

  const id = result.meta?.last_row_id;
  await syncSectionProducts(env, id, data.product_ids);
  return json({ ok: true, id, message: 'Secao criada com sucesso.' }, { status: 201 });
}

export async function updateSection(request, env, id) {
  const body = await readJson(request);
  if (!body) return fail(400, 'Dados invalidos.');

  const existing = await env.DB.prepare(`SELECT * FROM sections WHERE id = ?`).bind(id).first();
  if (!existing) return fail(404, 'Secao nao encontrada.');

  const { data, error } = normalizeSection(body, existing);
  if (error) return fail(400, error);

  await env.DB.prepare(
    `UPDATE sections SET title = ?, subtitle = ?, body = ?, image = ?, button_label = ?, button_url = ?,
            button_style = ?, layout = ?, background = ?, active = ?, sort_order = ?, updated_at = datetime('now')
      WHERE id = ?`
  )
    .bind(
      data.title,
      data.subtitle,
      data.body,
      data.image,
      data.button_label,
      data.button_url,
      data.button_style,
      data.layout,
      data.background,
      data.active,
      data.sort_order,
      id
    )
    .run();

  await syncSectionProducts(env, id, data.product_ids);
  return ok({ id, message: 'Secao atualizada com sucesso.' });
}

export async function deleteSection(env, id) {
  const existing = await env.DB.prepare(`SELECT id FROM sections WHERE id = ?`).bind(id).first();
  if (!existing) return fail(404, 'Secao nao encontrada.');

  await env.DB.prepare(`DELETE FROM sections WHERE id = ?`).bind(id).run();
  return ok({ message: 'Secao excluida.' });
}

export async function reorderSections(request, env) {
  const body = await readJson(request);
  const order = Array.isArray(body?.order) ? body.order.map((v) => int(v)).filter((v) => v > 0) : [];
  if (!order.length) return fail(400, 'Lista de ordem invalida.');

  const statements = order.map((sectionId, index) =>
    env.DB.prepare(`UPDATE sections SET sort_order = ?, updated_at = datetime('now') WHERE id = ?`).bind(
      (index + 1) * 10,
      sectionId
    )
  );
  await env.DB.batch(statements);
  return ok({ message: 'Ordem atualizada.' });
}

/* -------------------------------------------------------------------------- */
/* Configuracoes e textos                                                     */
/* -------------------------------------------------------------------------- */

const SETTINGS_KEYS = [
  'company_name',
  'company_tagline',
  'logo_image',
  'phone',
  'whatsapp',
  'whatsapp_message',
  'instagram',
  'facebook',
  'tiktok',
  'email',
  'address_line',
  'address_city',
  'address_notes',
  'google_maps_url',
  'google_maps_embed',
  'timezone',
  'currency',
  'business_hours',
  'seo_title',
  'seo_description',
  'footer_note',
];

const CONTENT_KEYS = [
  'hero.badge',
  'hero.title',
  'hero.subtitle',
  'hero.button_primary',
  'hero.button_secondary',
  'hero.image',
  'about.title',
  'about.subtitle',
  'about.body',
  'about.image',
  'products.title',
  'products.subtitle',
  'contact.title',
  'contact.subtitle',
  'location.title',
  'location.subtitle',
  'footer.about',
  'footer.rights',
];

const LINK_KEYS = new Set(['logo_image', 'hero.image', 'about.image']);
const SHORT_KEYS = new Set(['phone', 'whatsapp', 'instagram', 'facebook', 'tiktok', 'email', 'company_name', 'company_tagline', 'currency', 'footer_note']);

function sanitizeSettingValue(key, value) {
  if (LINK_KEYS.has(key)) return safeUrl(value);
  if (SHORT_KEYS.has(key)) return str(value, { max: 300 });
  return text(value, { max: 20000 });
}

export async function getSettings(env) {
  const { results } = await env.DB.prepare(`SELECT key, value FROM settings`).all();
  const settings = {};
  for (const row of results || []) settings[row.key] = row.value;
  return ok({ settings });
}

export async function updateSettings(request, env) {
  const body = await readJson(request);
  if (!body || typeof body !== 'object') return fail(400, 'Dados invalidos.');

  const updates = [];

  for (const [key, rawValue] of Object.entries(body)) {
    if (!SETTINGS_KEYS.includes(key)) continue;

    if (key === 'business_hours') {
      const parsed = Array.isArray(rawValue) ? rawValue : null;
      if (!parsed) return fail(400, 'Horarios invalidos.');
      const normalized = parsed.slice(0, 7).map((entry) => ({
        day: str(entry?.day, { max: 20 }),
        label: str(entry?.label, { max: 40 }),
        closed: Boolean(entry?.closed),
        open: isTime(entry?.open) || '00:00',
        close: isTime(entry?.close) || '23:59',
      }));
      updates.push(['business_hours', JSON.stringify(normalized)]);
      continue;
    }

    if (key === 'google_maps_embed') {
      const embed = str(rawValue, { max: 2000 });
      if (embed && !/^https:\/\//i.test(embed)) {
        return fail(400, 'O link de incorporar o mapa deve comecar com https://');
      }
      updates.push([key, embed]);
      continue;
    }

    if (key === 'google_maps_url') {
      const mapsUrl = str(rawValue, { max: 1000 });
      if (mapsUrl && !/^https?:\/\//i.test(mapsUrl)) {
        return fail(400, 'O link do Google Maps deve comecar com https://');
      }
      updates.push([key, mapsUrl]);
      continue;
    }

    if (key === 'instagram' || key === 'facebook' || key === 'tiktok') {
      const handle = str(rawValue, { max: 300 });
      // Aceita "@usuario", "usuario" ou um link completo https://
      if (handle && !/^https?:\/\//i.test(handle) && !/^@?[\w.\-]{2,60}$/.test(handle)) {
        return fail(400, `Valor invalido em ${key}. Use @usuario ou um link https:// completo.`);
      }
      updates.push([key, handle]);
      continue;
    }

    if (key === 'email') {
      const mail = str(rawValue, { max: 200 });
      if (mail && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(mail)) {
        return fail(400, 'Informe um e-mail valido.');
      }
      updates.push([key, mail]);
      continue;
    }

    if (key === 'timezone') {
      const tz = str(rawValue, { max: 60 });
      try {
        new Intl.DateTimeFormat('en-US', { timeZone: tz || 'America/Sao_Paulo' });
        updates.push([key, tz || 'America/Sao_Paulo']);
      } catch {
        return fail(400, 'Fuso horario invalido.');
      }
      continue;
    }

    if (key === 'currency') {
      const currency = str(rawValue, { max: 3, fallback: 'BRL' }).toUpperCase() || 'BRL';
      updates.push([key, currency]);
      continue;
    }

    updates.push([key, sanitizeSettingValue(key, str(rawValue, { max: 20000, trim: false }))]);
  }

  if (!updates.length) return fail(400, 'Nenhuma configuracao valida foi enviada.');

  await env.DB.batch(
    updates.map(([key, value]) =>
      env.DB.prepare(
        `INSERT INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
      ).bind(key, value)
    )
  );

  return ok({ message: 'Configuracoes salvas com sucesso.', updated: updates.length });
}

export async function getContent(env) {
  const { results } = await env.DB.prepare(`SELECT key, value FROM content_blocks`).all();
  const content = {};
  for (const row of results || []) content[row.key] = row.value;
  return ok({ content });
}

export async function updateContent(request, env) {
  const body = await readJson(request);
  if (!body || typeof body !== 'object') return fail(400, 'Dados invalidos.');

  const updates = [];
  for (const [key, rawValue] of Object.entries(body)) {
    if (!CONTENT_KEYS.includes(key)) continue;
    const value = key.endsWith('.image')
      ? safeUrl(rawValue)
      : text(rawValue, { max: 12000 });
    updates.push([key, value]);
  }

  if (!updates.length) return fail(400, 'Nenhum texto valido foi enviado.');

  await env.DB.batch(
    updates.map(([key, value]) =>
      env.DB.prepare(
        `INSERT INTO content_blocks (key, value, updated_at) VALUES (?, ?, datetime('now'))
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`
      ).bind(key, value)
    )
  );

  return ok({ message: 'Textos salvos com sucesso.', updated: updates.length });
}

/* -------------------------------------------------------------------------- */
/* Midias / imagens                                                           */
/* -------------------------------------------------------------------------- */

export async function listMedia(env) {
  const { results } = await env.DB.prepare(
    `SELECT id, filename, mime_type, size, width, height, alt, created_at FROM media ORDER BY created_at DESC LIMIT 200`
  ).all();
  return ok({ media: results || [] });
}

/**
 * Upload de imagem.
 * Aceita multipart/form-data com o campo `file` (preferencial - o navegador ja
 * redimensiona/comprime antes de enviar) ou JSON { filename, mime_type, data_base64 }.
 */
export async function uploadMedia(request, env, admin) {
  let filename = '';
  let mimeType = '';
  let bytes = null;
  let width = null;
  let height = null;
  let alt = '';

  const contentType = request.headers.get('content-type') || '';

  if (contentType.includes('multipart/form-data')) {
    let form;
    try {
      form = await request.formData();
    } catch {
      return fail(400, 'Nao foi possivel ler o arquivo enviado.');
    }
    const file = form.get('file');
    if (!file || typeof file === 'string') return fail(400, 'Nenhum arquivo foi enviado.');

    filename = str(file.name || 'imagem', { max: 200 });
    mimeType = str(file.type || '', { max: 60 }).toLowerCase();
    width = form.get('width') ? int(form.get('width'), { min: 1, max: 10000 }) : null;
    height = form.get('height') ? int(form.get('height'), { min: 1, max: 10000 }) : null;
    alt = str(form.get('alt'), { max: 200 });
    const buffer = await file.arrayBuffer();
    bytes = new Uint8Array(buffer);
  } else {
    const body = await readJson(request);
    if (!body || !body.data_base64) return fail(400, 'Arquivo nao enviado.');
    filename = str(body.filename || 'imagem', { max: 200 });
    mimeType = str(body.mime_type || '', { max: 60 }).toLowerCase();
    width = body.width ? int(body.width, { min: 1, max: 10000 }) : null;
    height = body.height ? int(body.height, { min: 1, max: 10000 }) : null;
    alt = str(body.alt, { max: 200 });
    try {
      const binary = atob(String(body.data_base64));
      bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    } catch {
      return fail(400, 'Arquivo invalido.');
    }
  }

  if (!bytes || !bytes.length) return fail(400, 'O arquivo esta vazio.');
  if (bytes.byteLength > MAX_IMAGE_BYTES) {
    return fail(413, `A imagem tem ${(bytes.byteLength / 1048576).toFixed(2)} MB. O limite e 2 MB por arquivo.`);
  }

  // Detecta o tipo real pelo conteudo (nunca confiar apenas na extensao).
  const detected = detectImageType(bytes);
  if (!detected) return fail(415, 'Formato nao suportado. Envie JPG, PNG ou WebP.');
  if (!ALLOWED_IMAGE_TYPES.includes(detected)) return fail(415, 'Formato nao suportado. Envie JPG, PNG ou WebP.');
  mimeType = detected;

  const id = randomId(12);
  await env.DB.prepare(
    `INSERT INTO media (id, filename, mime_type, size, width, height, alt, data, uploaded_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(id, filename, mimeType, bytes.byteLength, width, height, alt, bytes, admin.id)
    .run();

  return json(
    {
      ok: true,
      media: { id, url: `/api/media/${id}`, filename, mime_type: mimeType, size: bytes.byteLength, width, height },
      message: 'Imagem enviada com sucesso.',
    },
    { status: 201 }
  );
}

/** Le os "magic bytes" para confirmar que o arquivo e realmente uma imagem. */
export function detectImageType(bytes) {
  if (!bytes || bytes.length < 12) return null;
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg';
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return 'image/png';
  if (
    bytes[0] === 0x52 &&
    bytes[1] === 0x49 &&
    bytes[2] === 0x46 &&
    bytes[3] === 0x46 &&
    bytes[8] === 0x57 &&
    bytes[9] === 0x45 &&
    bytes[10] === 0x42 &&
    bytes[11] === 0x50
  ) {
    return 'image/webp';
  }
  return null;
}

export async function deleteMedia(env, id) {
  const row = await env.DB.prepare(`SELECT id FROM media WHERE id = ?`).bind(id).first();
  if (!row) return fail(404, 'Imagem nao encontrada.');

  await env.DB.prepare(`DELETE FROM media WHERE id = ?`).bind(id).run();
  return ok({ message: 'Imagem excluida.' });
}

export async function updateMediaAlt(request, env, id) {
  const body = await readJson(request);
  if (!body) return fail(400, 'Dados invalidos.');

  const row = await env.DB.prepare(`SELECT id FROM media WHERE id = ?`).bind(id).first();
  if (!row) return fail(404, 'Imagem nao encontrada.');

  await env.DB.prepare(`UPDATE media SET alt = ? WHERE id = ?`)
    .bind(str(body.alt, { max: 200 }), id)
    .run();
  return ok({ message: 'Descricao da imagem atualizada.' });
}
