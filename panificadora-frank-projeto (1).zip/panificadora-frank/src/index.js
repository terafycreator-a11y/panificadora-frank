/**
 * Panificadora Frank - Worker principal (Cloudflare Workers + D1).
 *
 * Este unico Worker:
 *   1. Responde a API em /api/* (site publico + Painel ADM)
 *   2. Serve os arquivos estaticos de ./public (site publico e /admin)
 *
 * Sem dependencias externas: apenas Web APIs (fetch, crypto, atob/btoa, Intl).
 */

import { fail, json, int, ok, readJson, str, noContent } from './lib/util.js';
import {
  createAdmin,
  handleChangePassword,
  handleLogin,
  handleLogout,
  handleMe,
  handleSetup,
  handleSetupStatus,
  requireAuth,
} from './lib/auth.js';
import {
  handleHealth,
  handleMedia,
  handlePublicProducts,
  handleSiteData,
} from './routes/public.js';
import {
  createProduct,
  createSection,
  deleteMedia,
  deleteProduct,
  deleteSection,
  getContent,
  getSettings,
  listMedia,
  listProducts,
  listSections,
  reorderProducts,
  reorderSections,
  updateContent,
  updateMediaAlt,
  updateProduct,
  updateSection,
  updateSettings,
  uploadMedia,
} from './routes/admin.js';

/* -------------------------------------------------------------------------- */
/* CORS (necessario apenas quando o painel for hospedado em outro dominio)     */
/* -------------------------------------------------------------------------- */

function corsHeaders(request, env) {
  const origin = request.headers.get('origin') || '';
  const allowed = str(env.ALLOWED_ORIGIN, { max: 300 });
  const headers = new Headers();
  if (allowed && origin === allowed) {
    headers.set('access-control-allow-origin', origin);
    headers.set('access-control-allow-credentials', 'true');
    headers.set('access-control-allow-headers', 'content-type');
    headers.set('access-control-allow-methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    headers.set('vary', 'origin');
  }
  return headers;
}

/* -------------------------------------------------------------------------- */
/* Roteamento                                                                 */
/* -------------------------------------------------------------------------- */

function segments(pathname) {
  return pathname.split('/').filter(Boolean);
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    // Requisicoes que nao sao da API seguem para os arquivos estaticos.
    if (!path.startsWith('/api/')) {
      if (!env.ASSETS) {
        return fail(500, 'Binding de arquivos estaticos (ASSETS) nao configurado.');
      }
      return env.ASSETS.fetch(request);
    }

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders(request, env) });
    }

    let response;
    try {
      response = await route(request, env, url, ctx);
    } catch (error) {
      console.error('[api] erro nao tratado', path, error?.stack || error);
      const message =
        env.APP_ENV === 'development'
          ? `Erro interno: ${error?.message || error}`
          : 'Erro interno no servidor. Tente novamente em instantes.';
      response = fail(500, message);
    }

    // Aplica CORS quando configurado e garante cabecalhos de seguranca.
    const cors = corsHeaders(request, env);
    if ([...cors.keys()].length) {
      const merged = new Headers(response.headers);
      for (const [key, value] of cors.entries()) merged.set(key, value);
      response = new Response(response.body, { status: response.status, headers: merged });
    }
    return response;
  },
};

async function route(request, env, url, ctx) {
  const path = url.pathname.replace(/\/+$/, '') || '/api';
  const parts = segments(path); // ['api', ...]
  const method = request.method.toUpperCase();

  /* ------------------------------- Publico ------------------------------- */

  if (path === '/api/health' && method === 'GET') return handleHealth(env, request);
  if (path === '/api/site' && method === 'GET') return handleSiteData(env);
  if (path === '/api/products' && method === 'GET') return handlePublicProducts(env);

  if (parts[1] === 'media' && parts[2] && method === 'GET') return handleMedia(env, parts[2]);

  /* ------------------------- Autenticacao / setup ------------------------ */

  if (path === '/api/setup/status' && method === 'GET') return handleSetupStatus(env);
  if (path === '/api/setup' && method === 'POST') return handleSetup(request, env);
  if (path === '/api/auth/login' && method === 'POST') return handleLogin(request, env);
  if (path === '/api/auth/logout' && method === 'POST') return handleLogout(request, env);
  if (path === '/api/auth/me' && method === 'GET') return handleMe(request, env);

  /* --------------------- Rotas administrativas protegidas ---------------- */

  if (parts[1] !== 'admin') return fail(404, 'Rota nao encontrada.');

  const { admin, response: unauthorized } = await requireAuth(request, env);
  if (unauthorized) return unauthorized;

  const resource = parts[2];
  const rawId = parts[3] || '';
  const id = rawId ? int(rawId, { fallback: 0 }) : 0;
  const sub = parts[4];
  const isReorder = rawId === 'reorder';

  if (path === '/api/admin/session' && method === 'GET') {
    return ok({ admin: { id: admin.id, email: admin.email, name: admin.name, role: admin.role } });
  }
  if (path === '/api/admin/change-password' && method === 'POST') {
    return handleChangePassword(request, env, admin);
  }

  /* Produtos */
  if (resource === 'products') {
    if (isReorder) {
      if (method === 'POST') return reorderProducts(request, env);
      return fail(405, 'Use POST para reordenar produtos.');
    }
    if (!rawId && method === 'GET') return listProducts(env);
    if (!rawId && method === 'POST') return createProduct(request, env);
    if (id && !sub) {
      if (method === 'PUT' || method === 'PATCH') return updateProduct(request, env, id);
      if (method === 'DELETE') return deleteProduct(env, id);
    }
    return fail(405, 'Metodo nao permitido para este recurso.');
  }

  /* Secoes / quadros */
  if (resource === 'sections') {
    if (isReorder) {
      if (method === 'POST') return reorderSections(request, env);
      return fail(405, 'Use POST para reordenar secoes.');
    }
    if (!rawId && method === 'GET') return listSections(env);
    if (!rawId && method === 'POST') return createSection(request, env);
    if (id && !sub) {
      if (method === 'PUT' || method === 'PATCH') return updateSection(request, env, id);
      if (method === 'DELETE') return deleteSection(env, id);
    }
    return fail(405, 'Metodo nao permitido para este recurso.');
  }

  /* Configuracoes */
  if (resource === 'settings') {
    if (method === 'GET') return getSettings(env);
    if (method === 'PUT' || method === 'POST') return updateSettings(request, env);
    return fail(405, 'Metodo nao permitido para este recurso.');
  }

  /* Textos editaveis */
  if (resource === 'content') {
    if (method === 'GET') return getContent(env);
    if (method === 'PUT' || method === 'POST') return updateContent(request, env);
    return fail(405, 'Metodo nao permitido para este recurso.');
  }

  /* Imagens */
  if (resource === 'media') {
    if (!rawId && method === 'GET') return listMedia(env);
    if (!rawId && method === 'POST') return uploadMedia(request, env, admin);
    if (rawId && !sub && method === 'DELETE') return deleteMedia(env, rawId);
    if (rawId && !sub && (method === 'PATCH' || method === 'PUT')) return updateMediaAlt(request, env, rawId);
    return fail(405, 'Metodo nao permitido para este recurso.');
  }

  /* Administradores */
  if (resource === 'admins') {
    if (admin.role !== 'admin') return fail(403, 'Apenas administradores podem gerenciar usuarios.');
    if (!rawId && method === 'GET') return listAdmins(env);
    if (!rawId && method === 'POST') return createAdminHandler(request, env);
    if (id && !sub && method === 'DELETE') return deleteAdmin(env, id, admin);
    if (id && !sub && (method === 'PUT' || method === 'PATCH')) return updateAdmin(request, env, id);
    return fail(405, 'Metodo nao permitido para este recurso.');
  }

  return fail(404, 'Rota administrativa nao encontrada.');
}

/* -------------------------------------------------------------------------- */
/* Gerenciamento de administradores                                           */
/* -------------------------------------------------------------------------- */

async function listAdmins(env) {
  const { results } = await env.DB.prepare(
    `SELECT a.id, a.email, a.name, a.role, a.active, a.last_login_at, a.created_at,
            (SELECT COUNT(*) FROM sessions s WHERE s.admin_id = a.id AND s.expires_at > datetime('now')) AS active_sessions
       FROM admins a ORDER BY a.id ASC`
  ).all();
  return ok({ admins: results || [] });
}

async function createAdminHandler(request, env) {
  const body = await readJson(request);
  if (!body) return fail(400, 'Dados invalidos.');

  const result = await createAdmin(env, {
    email: body.email,
    name: body.name,
    password: body.password,
    role: body.role === 'editor' ? 'editor' : 'admin',
    mustChangePassword: 1,
  });
  if (result.error) return fail(400, result.error);

  return json({ ok: true, id: result.id, message: 'Administrador criado com sucesso.' }, { status: 201 });
}

async function updateAdmin(request, env, id) {
  const body = await readJson(request);
  if (!body) return fail(400, 'Dados invalidos.');

  const existing = await env.DB.prepare(`SELECT * FROM admins WHERE id = ?`).bind(id).first();
  if (!existing) return fail(404, 'Administrador nao encontrado.');

  const name = str(body.name, { max: 120, fallback: existing.name });
  const role = body.role === 'editor' || body.role === 'admin' ? body.role : existing.role;
  const active = body.active === undefined ? Number(existing.active) : body.active ? 1 : 0;

  if (Number(existing.active) === 1 && active === 0) {
    const row = await env.DB.prepare(`SELECT COUNT(*) AS total FROM admins WHERE active = 1`).first();
    if (Number(row?.total || 0) <= 1) return fail(400, 'Nao e possivel desativar o ultimo administrador ativo.');
  }

  await env.DB.prepare(
    `UPDATE admins SET name = ?, role = ?, active = ?, updated_at = datetime('now') WHERE id = ?`
  )
    .bind(name, role, active, id)
    .run();

  if (active === 0) {
    await env.DB.prepare(`DELETE FROM sessions WHERE admin_id = ?`).bind(id).run();
  }

  return ok({ message: 'Administrador atualizado.' });
}

async function deleteAdmin(env, id, current) {
  if (id === current.id) return fail(400, 'Voce nao pode excluir o proprio usuario.');

  const existing = await env.DB.prepare(`SELECT id, role FROM admins WHERE id = ?`).bind(id).first();
  if (!existing) return fail(404, 'Administrador nao encontrado.');

  const row = await env.DB.prepare(`SELECT COUNT(*) AS total FROM admins WHERE role = 'admin'`).first();
  if (existing.role === 'admin' && Number(row?.total || 0) <= 1) {
    return fail(400, 'Nao e possivel excluir o ultimo administrador.');
  }

  await env.DB.prepare(`DELETE FROM admins WHERE id = ?`).bind(id).run();
  return noContent();
}
