/* ==========================================================================
   Panificadora Frank - Painel ADM
   SPA em JavaScript puro. Toda a persistencia acontece na API
   (/api/...) com sessoes HttpOnly validadas no servidor.
   ========================================================================== */
(function () {
  'use strict';

  /* --------------------------------------------------------------------- */
  /* Estado e utilitarios                                                   */
  /* --------------------------------------------------------------------- */

  var state = {
    admin: null,
    settings: {},
    content: {},
    products: [],
    sections: [],
    media: [],
    admins: [],
    view: 'dashboard',
    editingProductId: null,
    editingSectionId: null,
    sectionProductIds: [],
    uploading: false,
    mustChangePassword: false,
  };

  function $(id) {
    return document.getElementById(id);
  }

  function el(selector, root) {
    return (root || document).querySelector(selector);
  }

  function all(selector, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(selector));
  }

  function esc(value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /** Quebras de linha -> paragrafos (para exibicao) */
  function paragraphs(value) {
    var t = String(value || '').trim();
    if (!t) return '';
    return t
      .split(/\n{2,}/)
      .map(function (block) {
        return '<p>' + esc(block).replace(/\n/g, '<br />') + '</p>';
      })
      .join('');
  }

  function formatDate(value) {
    if (!value) return '-';
    var iso = String(value).replace(' ', 'T') + (String(value).includes('Z') ? '' : 'Z');
    var date = new Date(iso);
    if (isNaN(date.getTime())) return String(value);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  function formatBytes(bytes) {
    var n = Number(bytes) || 0;
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
    return (n / 1048576).toFixed(2) + ' MB';
  }

  function formatPrice(value, currency) {
    if (value === null || value === undefined || value === '') return '';
    var n = Number(value);
    if (!Number.isFinite(n)) return '';
    try {
      return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: currency || 'BRL' }).format(n);
    } catch (e) {
      return 'R$ ' + n.toFixed(2).replace('.', ',');
    }
  }

  /* --------------------------------------------------------------------- */
  /* API                                                                    */
  /* --------------------------------------------------------------------- */

  function api(path, options) {
    var opts = options || {};
    var config = {
      method: opts.method || 'GET',
      credentials: 'same-origin',
      headers: Object.assign({ accept: 'application/json' }, opts.headers || {}),
    };

    if (opts.body instanceof FormData) {
      config.body = opts.body;
    } else if (opts.body !== undefined) {
      config.headers['content-type'] = 'application/json';
      config.body = JSON.stringify(opts.body);
    }

    return fetch('/api' + path, config).then(function (response) {
      if (response.status === 204) return { ok: true };
      return response
        .json()
        .catch(function () {
          return { error: 'Resposta invalida do servidor (HTTP ' + response.status + ').' };
        })
        .then(function (data) {
          if (!response.ok) {
            var error = new Error(data && data.error ? data.error : 'Erro HTTP ' + response.status);
            error.status = response.status;
            error.data = data;
            throw error;
          }
          return data;
        });
    });
  }

  /* --------------------------------------------------------------------- */
  /* Toasts e alertas                                                       */
  /* --------------------------------------------------------------------- */

  function toast(message, type) {
    var area = $('toast-area');
    if (!area) return;
    var node = document.createElement('div');
    node.className = 'toast' + (type ? ' toast--' + type : '');
    node.textContent = message;
    area.appendChild(node);
    window.setTimeout(function () {
      node.style.transition = 'opacity .25s ease';
      node.style.opacity = '0';
      window.setTimeout(function () {
        if (node.parentNode) node.parentNode.removeChild(node);
      }, 260);
    }, type === 'error' ? 5200 : 3200);
  }

  function alertBox(containerId, message, type, list) {
    var box = $(containerId);
    if (!box) return;
    if (!message) {
      box.innerHTML = '';
      return;
    }
    var items = Array.isArray(list) && list.length
      ? '<ul>' + list.map(function (i) { return '<li>' + esc(i) + '</li>'; }).join('') + '</ul>'
      : '';
    box.innerHTML =
      '<div class="alert alert--' + (type || 'error') + '"><span>' + esc(message) + '</span></div>';
    if (items) {
      box.querySelector('.alert').insertAdjacentHTML('beforeend', items);
    }
  }

  function busy(button, isBusy, labelWhileBusy) {
    if (!button) return;
    if (isBusy) {
      button.dataset.originalLabel = button.innerHTML;
      button.disabled = true;
      button.innerHTML = '<span class="btn__spinner"></span>' + (labelWhileBusy ? ' ' + labelWhileBusy : '');
    } else {
      button.disabled = false;
      if (button.dataset.originalLabel) button.innerHTML = button.dataset.originalLabel;
    }
  }

  /* --------------------------------------------------------------------- */
  /* Modal generico                                                         */
  /* --------------------------------------------------------------------- */

  var modalCleanup = null;

  function openModal(options) {
    closeModal();

    var overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.innerHTML =
      '<div class="sheet' + (options.size === 'sm' ? ' sheet--sm' : '') + '" role="dialog" aria-modal="true">' +
      '<div class="sheet__head">' +
      '<h2 class="sheet__title">' + esc(options.title || '') + '</h2>' +
      '<button class="sheet__close" type="button" aria-label="Fechar">' +
      '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M18 6L6 18M6 6l12 12"/></svg>' +
      '</button>' +
      '</div>' +
      '<div class="sheet__body">' + (options.body || '') + '</div>' +
      (options.footer ? '<div class="sheet__foot">' + options.footer + '</div>' : '') +
      '</div>';

    document.body.appendChild(overlay);
    document.body.classList.add('no-scroll');

    overlay.addEventListener('click', function (event) {
      if (event.target === overlay && options.dismissible !== false) closeModal();
    });

    function onKey(event) {
      if (event.key === 'Escape' && options.dismissible !== false) closeModal();
    }
    document.addEventListener('keydown', onKey);

    var closeBtn = el('.sheet__close', overlay);
    if (closeBtn) closeBtn.addEventListener('click', closeModal);

    modalCleanup = function () {
      document.removeEventListener('keydown', onKey);
    };

    if (typeof options.onOpen === 'function') options.onOpen(overlay);
    return overlay;
  }

  function closeModal() {
    var existing = el('.overlay');
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
    document.body.classList.remove('no-scroll');
    if (modalCleanup) {
      modalCleanup();
      modalCleanup = null;
    }
  }

  /** Confirmacao antes de excluir (evita perda de dados por toque acidental). */
  function confirmDialog(options) {
    return new Promise(function (resolve) {
      var overlay = openModal({
        title: options.title || 'Confirmar',
        size: 'sm',
        body:
          '<p style="margin:0 0 6px">' + esc(options.message || 'Deseja continuar?') + '</p>' +
          (options.detail ? '<p style="color:var(--muted);font-size:.88rem;margin:0">' + esc(options.detail) + '</p>' : ''),
        footer:
          '<button class="btn btn--ghost" type="button" data-role="cancel">Cancelar</button>' +
          '<button class="btn btn--danger" type="button" data-role="confirm">' + esc(options.confirmLabel || 'Excluir') + '</button>',
      });

      function done(value) {
        closeModal();
        resolve(value);
      }

      el('[data-role="cancel"]', overlay).addEventListener('click', function () {
        done(false);
      });
      el('[data-role="confirm"]', overlay).addEventListener('click', function () {
        done(true);
      });
    });
  }

  /* --------------------------------------------------------------------- */
  /* Upload de imagem (com otimizacao no navegador)                         */
  /* --------------------------------------------------------------------- */

  var MAX_UPLOAD_BYTES = 2 * 1024 * 1024;
  var ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
  var MAX_DIMENSION = 1600;
  var uploaderSeq = 0;

  function readFile(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () {
        resolve(reader.result);
      };
      reader.onerror = function () {
        reject(new Error('Nao foi possivel ler o arquivo.'));
      };
      reader.readAsDataURL(file);
    });
  }

  function loadImage(dataUrl) {
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () {
        resolve(img);
      };
      img.onerror = function () {
        reject(new Error('Arquivo de imagem invalido ou corrompido.'));
      };
      img.src = dataUrl;
    });
  }

  /**
   * Redimensiona/comprime a imagem no proprio celular antes de enviar.
   * Mantem PNG quando ha transparencia; caso contrario usa JPEG.
   */
  function optimizeImage(file) {
    if (!ACCEPTED_TYPES.includes(file.type)) {
      return Promise.reject(new Error('Formato nao aceito. Envie JPG, PNG ou WebP.'));
    }
    if (file.size > 12 * 1024 * 1024) {
      return Promise.reject(new Error('Arquivo muito grande (limite de 12 MB antes da otimizacao).'));
    }

    return readFile(file).then(loadImage).then(function (img) {
      var width = img.naturalWidth;
      var height = img.naturalHeight;
      var scale = Math.min(1, MAX_DIMENSION / Math.max(width, height));

      // Se ja for pequena e leve, envia o original.
      if (scale === 1 && file.size <= MAX_UPLOAD_BYTES) {
        return { dataUrl: img.src, width: width, height: height, size: file.size, mime: file.type, optimized: false };
      }

      var targetW = Math.max(1, Math.round(width * scale));
      var targetH = Math.max(1, Math.round(height * scale));

      var canvas = document.createElement('canvas');
      canvas.width = targetW;
      canvas.height = targetH;
      var ctx = canvas.getContext('2d');

      var keepPng = file.type === 'image/png';
      if (!keepPng) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, targetW, targetH);
      }
      ctx.drawImage(img, 0, 0, targetW, targetH);

      var quality = 0.82;
      var mime = keepPng ? 'image/png' : 'image/jpeg';
      var dataUrl = canvas.toDataURL(mime, quality);

      // Reduz a qualidade progressivamente ate caber no limite do servidor.
      var attempts = 0;
      while (dataUrl.length * 0.75 > MAX_UPLOAD_BYTES && quality > 0.4 && attempts < 5) {
        quality -= 0.12;
        attempts += 1;
        dataUrl = canvas.toDataURL('image/jpeg', quality);
        mime = 'image/jpeg';
      }

      return {
        dataUrl: dataUrl,
        width: targetW,
        height: targetH,
        size: Math.round(dataUrl.length * 0.75),
        mime: mime,
        optimized: true,
      };
    });
  }

  function buildUploader(container, options) {
    var opts = options || {};
    var currentUrl = opts.value || '';
    // Cada uploader recebe IDs unicos (varios podem coexistir na mesma pagina).
    var uid = 'up' + uploaderSeq++;

    container.innerHTML =
      '<div class="uploader">' +
      '<div class="uploader__preview" id="' + uid + '-preview" data-role="preview">' +
      (currentUrl
        ? '<img src="' + esc(currentUrl) + '" alt="Imagem atual" />'
        : '<div class="uploader__placeholder">' +
          '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-6 6"/></svg>' +
          '<span>Nenhuma imagem</span></div>') +
      '</div>' +
      '<div class="btn-row" style="justify-content:center">' +
      '<label class="btn btn--sm btn--ghost" for="' + uid + '-input" style="cursor:pointer">' +
      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>' +
      '<span data-role="label">' + (currentUrl ? 'Trocar imagem' : 'Escolher imagem') + '</span>' +
      '</label>' +
      (currentUrl
        ? '<button class="btn btn--sm btn--danger" type="button" data-role="remove">Remover</button>'
        : '') +
      '</div>' +
      '<input type="file" id="' + uid + '-input" data-role="input" accept="image/jpeg,image/png,image/webp" />' +
      '<div class="uploader__info" data-role="info">JPG, PNG ou WebP. A imagem e redimensionada e comprimida antes de enviar (limite final de 2 MB).</div>' +
      '<div class="uploader__progress" data-role="progress" hidden><div class="uploader__bar" data-role="bar"></div></div>' +
      '</div>';

    var input = el('[data-role="input"]', container);
    var info = el('[data-role="info"]', container);
    var preview = el('[data-role="preview"]', container);
    var progress = el('[data-role="progress"]', container);
    var bar = el('[data-role="bar"]', container);
    var label = el('[data-role="label"]', container);
    var removeBtn = el('[data-role="remove"]', container);

    function setValue(url) {
      if (typeof opts.onChange === 'function') opts.onChange(url);
    }

    function clearImage() {
      preview.innerHTML =
        '<div class="uploader__placeholder">' +
        '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-6 6"/></svg>' +
        '<span>Nenhuma imagem</span></div>';
      var btn = el('[data-role="remove"]', container);
      if (btn && btn.parentNode) btn.parentNode.removeChild(btn);
      if (label) label.textContent = 'Escolher imagem';
      removeBtn = null;
      setValue('');
    }

    function addRemoveButton() {
      if (el('[data-role="remove"]', container)) return;
      var row = el('.btn-row', container);
      var btn = document.createElement('button');
      btn.className = 'btn btn--sm btn--danger';
      btn.type = 'button';
      btn.setAttribute('data-role', 'remove');
      btn.textContent = 'Remover';
      btn.addEventListener('click', function () {
        clearImage();
        toast('Imagem removida. Salve o formulario para confirmar.', 'success');
      });
      row.appendChild(btn);
    }

    if (removeBtn) {
      removeBtn.addEventListener('click', function () {
        preview.innerHTML =
          '<div class="uploader__placeholder">' +
          '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-6 6"/></svg>' +
          '<span>Nenhuma imagem</span></div>';
        if (removeBtn.parentNode) removeBtn.parentNode.removeChild(removeBtn);
        if (label) label.textContent = 'Escolher imagem';
        removeBtn = null;
        setValue('');
        toast('Imagem removida. Salve o formulario para confirmar.', 'success');
      });
    }

    input.addEventListener('change', function () {
      var file = input.files && input.files[0];
      input.value = '';
      if (!file) return;
      if (state.uploading) return;

      state.uploading = true;
      if (progress) progress.hidden = false;
      if (bar) bar.style.width = '25%';
      if (info) info.textContent = 'Otimizando imagem...';

      optimizeImage(file)
        .then(function (result) {
          if (bar) bar.style.width = '55%';
          if (info) {
            info.textContent =
              'Enviando ' + formatBytes(result.size) + ' (' + result.width + 'x' + result.height + ')' +
              (result.optimized ? ' - imagem otimizada automaticamente.' : '');
          }

          return api('/admin/media', {
            method: 'POST',
            body: {
              filename: file.name,
              mime_type: result.mime,
              data_base64: String(result.dataUrl).split(',')[1] || '',
              width: result.width,
              height: result.height,
            },
          });
        })
        .then(function (response) {
          if (bar) bar.style.width = '100%';
          var media = response.media;
          preview.innerHTML = '<img src="' + esc(media.url) + '" alt="Nova imagem" />';
          addRemoveButton();
          if (label) label.textContent = 'Trocar imagem';
          if (info) info.textContent = 'Imagem enviada: ' + media.filename + ' (' + formatBytes(media.size) + ')';
          setValue(media.url);
          toast('Imagem enviada com sucesso.', 'success');
          state.media.unshift(media);
          if (state.view === 'media') renderMedia();
        })
        .catch(function (error) {
          if (info) info.textContent = 'JPG, PNG ou WebP (ate 2 MB).';
          toast(error.message || 'Falha no envio da imagem.', 'error');
        })
        .then(function () {
          state.uploading = false;
          window.setTimeout(function () {
            if (progress) progress.hidden = true;
            if (bar) bar.style.width = '0';
          }, 900);
        });
    });
  }

  /* --------------------------------------------------------------------- */
  /* Navegacao                                                              */
  /* --------------------------------------------------------------------- */

  var VIEWS = ['dashboard', 'products', 'sections', 'content', 'media', 'settings', 'account'];

  function showView(view) {
    if (VIEWS.indexOf(view) === -1) view = 'dashboard';
    state.view = view;

    VIEWS.forEach(function (name) {
      var section = $('view-' + name);
      if (section) section.hidden = name !== view;
    });

    all('[data-view]').forEach(function (button) {
      button.classList.toggle('is-active', button.getAttribute('data-view') === view);
    });

    if (window.location.hash !== '#' + view) {
      history.replaceState(null, '', '#' + view);
    }

    if (view === 'dashboard') renderDashboard();
    if (view === 'products') renderProducts();
    if (view === 'sections') renderSections();
    if (view === 'content') renderContentForm();
    if (view === 'media') renderMedia();
    if (view === 'settings') renderSettingsForm();
    if (view === 'account') renderAccount();

    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  function initTabs() {
    document.addEventListener('click', function (event) {
      var target = event.target.closest('[data-view]');
      if (!target) return;
      var view = target.getAttribute('data-view');
      if (VIEWS.indexOf(view) === -1) return;
      showView(view);
    });

    // Permite abrir uma aba direto pelo endereco (ex: /admin/#produtos).
    window.addEventListener('hashchange', function () {
      var hash = (window.location.hash || '').replace('#', '');
      if (VIEWS.indexOf(hash) === -1) return;
      if ($('app') && !$('app').hidden) showView(hash);
    });
  }

  /* --------------------------------------------------------------------- */
  /* Resumo                                                                 */
  /* --------------------------------------------------------------------- */

  function availabilityLabel(product) {
    if (!product.active) return { text: 'Inativo', cls: 'badge--neutral' };
    if (product.status === 'available') return { text: 'Disponivel', cls: 'badge--on' };
    if (product.status === 'unavailable') return { text: 'Nao disponivel', cls: 'badge--off' };
    return {
      text: product.available_until ? 'Ate ' + product.available_until : 'Automatico',
      cls: 'badge--warn',
    };
  }

  function renderDashboard() {
    var availableNow = state.products.filter(function (p) {
      return Number(p.active) === 1 && p.status === 'available';
    }).length;

    var stats = [
      { value: state.products.length, label: 'produtos cadastrados' },
      { value: availableNow, label: 'marcados como disponiveis' },
      { value: state.sections.length, label: 'quadros/secoes' },
      { value: state.media.length, label: 'imagens enviadas' },
    ];

    var statsBox = $('dash-stats');
    if (statsBox) {
      statsBox.innerHTML = stats
        .map(function (s) {
          return (
            '<div class="stat"><span class="stat__value">' +
            esc(s.value) +
            '</span><span class="stat__label">' +
            esc(s.label) +
            '</span></div>'
          );
        })
        .join('');
    }

    var box = $('dash-products');
    if (!box) return;

    var list = state.products.filter(function (p) {
      return Number(p.active) === 1;
    });

    if (!list.length) {
      box.innerHTML =
        '<div class="empty"><h3>Nenhum produto ainda</h3><p>Crie o primeiro produto para que ele apareca no site.</p>' +
        '<button class="btn btn--primary" type="button" data-quick="new-product">Criar produto</button></div>';
      return;
    }

    box.innerHTML =
      '<div class="pill-list">' +
      list
        .map(function (p) {
          var badge = availabilityLabel(p);
          return (
            '<span class="badge ' + badge.cls + '"><span class="dot"></span>' + esc(p.name) + '</span>'
          );
        })
        .join('') +
      '</div>' +
      '<p style="margin:12px 0 0;color:var(--muted);font-size:.85rem">A disponibilidade mostrada no site respeita o horario-limite dos produtos com status "Automatico".</p>';
  }

  function initQuickActions() {
    document.addEventListener('click', function (event) {
      var target = event.target.closest('[data-quick]');
      if (!target) return;
      var action = target.getAttribute('data-quick');
      if (action === 'new-product') {
        showView('products');
        openProductForm(null);
      } else if (action === 'new-section') {
        showView('sections');
        openSectionForm(null);
      } else if (action === 'settings') {
        showView('settings');
      } else if (action === 'media') {
        showView('media');
      }
    });
  }

  /* --------------------------------------------------------------------- */
  /* Produtos                                                               */
  /* --------------------------------------------------------------------- */

  function renderProducts() {
    var box = $('products-list');
    if (!box) return;

    if (!state.products.length) {
      box.innerHTML =
        '<div class="empty"><h3>Nenhum produto cadastrado</h3>' +
        '<p>Os produtos aparecem no site assim que forem criados.</p>' +
        '<button class="btn btn--primary" type="button" id="empty-new-product">Criar primeiro produto</button></div>';
      var emptyBtn = $('empty-new-product');
      if (emptyBtn) emptyBtn.addEventListener('click', function () { openProductForm(null); });
      return;
    }

    box.innerHTML = state.products
      .map(function (product, index) {
        var badge = availabilityLabel(product);
        var price = formatPrice(product.price, state.settings.currency);
        var thumb = product.image
          ? '<img class="item__thumb" src="' + esc(product.image) + '" alt="" loading="lazy" />'
          : '<div class="item__thumb item__thumb--empty"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-6 6"/></svg></div>';

        return (
          '<article class="item" data-product="' + esc(product.id) + '">' +
          thumb +
          '<div class="item__main">' +
          '<h3 class="item__title">' + esc(product.name) + '</h3>' +
          '<div class="item__meta">' +
          '<span class="badge ' + badge.cls + '"><span class="dot"></span>' + esc(badge.text) + '</span>' +
          (price ? '<span><strong>' + esc(price) + '</strong></span>' : '') +
          (product.available_until ? '<span>Ate ' + esc(product.available_until) + '</span>' : '') +
          (Number(product.active) === 1 ? '' : '<span class="badge badge--neutral">Oculto no site</span>') +
          (Number(product.highlight) === 1 ? '<span class="badge badge--gold">Destaque</span>' : '') +
          '</div>' +
          (product.description ? '<p class="item__desc">' + esc(product.description) + '</p>' : '') +
          '<div class="item__actions">' +
          '<button class="btn btn--sm" type="button" data-action="edit-product" data-id="' + esc(product.id) + '">Editar</button>' +
          '<button class="btn btn--sm btn--ghost" type="button" data-action="toggle-product" data-id="' + esc(product.id) + '">' +
          (Number(product.active) === 1 ? 'Desativar' : 'Ativar') +
          '</button>' +
          '<button class="btn btn--sm btn--ghost btn--icon" type="button" data-action="move-product-up" data-id="' +
          esc(product.id) +
          '" title="Mover para cima" ' +
          (index === 0 ? 'disabled' : '') +
          '>up</button>' +
          '<button class="btn btn--sm btn--ghost btn--icon" type="button" data-action="move-product-down" data-id="' +
          esc(product.id) +
          '" title="Mover para baixo" ' +
          (index === state.products.length - 1 ? 'disabled' : '') +
          '>down</button>' +
          '<button class="btn btn--sm btn--danger" type="button" data-action="delete-product" data-id="' + esc(product.id) + '">Excluir</button>' +
          '</div>' +
          '</div>' +
          '</article>'
        );
      })
      .join('');

    // Botoes de mover: usa setas reais em vez de texto
    all('[data-action="move-product-up"]', box).forEach(function (btn) {
      btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M18 15l-6-6-6 6"/></svg>';
    });
    all('[data-action="move-product-down"]', box).forEach(function (btn) {
      btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 9l6 6 6-6"/></svg>';
    });
  }

  function openProductForm(productId) {
    var product = productId
      ? state.products.find(function (p) { return String(p.id) === String(productId); })
      : null;

    state.editingProductId = product ? product.id : null;
    var imageValue = product ? product.image || '' : '';

    var overlay = openModal({
      title: product ? 'Editar produto' : 'Novo produto',
      body:
        '<div id="product-form-alert"></div>' +
        '<form id="product-form" autocomplete="off">' +
        '<div class="field">' +
        '<label class="field__label" for="p-name">Nome do produto *</label>' +
        '<input class="input" id="p-name" type="text" maxlength="160" required value="' + esc(product ? product.name : '') + '" />' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="p-description">Descricao</label>' +
        '<textarea class="textarea" id="p-description" maxlength="4000" placeholder="Ex: Pao frances quentinho, assado varias vezes ao dia.">' +
        esc(product ? product.description : '') +
        '</textarea>' +
        '</div>' +
        '<div class="field-row">' +
        '<div class="field">' +
        '<label class="field__label" for="p-price">Preco</label>' +
        '<input class="input" id="p-price" type="text" inputmode="decimal" placeholder="Ex: 12,50" value="' +
        esc(product && product.price !== null && product.price !== undefined ? String(product.price).replace('.', ',') : '') +
        '" />' +
        '<span class="field__hint">Deixe vazio para nao exibir preco.</span>' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="p-price-note">Observacao de preco</label>' +
        '<input class="input" id="p-price-note" type="text" maxlength="120" placeholder="Ex: por quilo" value="' +
        esc(product ? product.price_note : '') +
        '" />' +
        '</div>' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="p-status">Disponibilidade</label>' +
        '<select class="select" id="p-status">' +
        '<option value="available"' + (product && product.status === 'available' ? ' selected' : '') + '>Sempre disponivel</option>' +
        '<option value="auto"' + (product && product.status === 'auto' ? ' selected' : '') + '>Disponivel ate um horario</option>' +
        '<option value="unavailable"' + (product && product.status === 'unavailable' ? ' selected' : '') + '>Nao disponivel</option>' +
        '</select>' +
        '</div>' +
        '<div class="field" id="p-until-wrap"' + (product && product.status === 'auto' ? '' : ' hidden') + '>' +
        '<label class="field__label" for="p-until">Disponivel ate (horario)</label>' +
        '<input class="input" id="p-until" type="time" value="' + esc(product ? product.available_until || '' : '') + '" />' +
        '<span class="field__hint">Depois desse horario o produto aparece como NAO DISPONIVEL no site.</span>' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label">Foto do produto</label>' +
        '<div id="product-uploader"></div>' +
        '</div>' +
        '<div class="field-row">' +
        '<div class="field">' +
        '<label class="switch"><input type="checkbox" id="p-active"' + (!product || Number(product.active) === 1 ? ' checked' : '') + ' />' +
        '<span class="switch__track"></span><span class="switch__text">Produto ativo<span class="switch__sub">Aparece no site</span></span></label>' +
        '</div>' +
        '<div class="field">' +
        '<label class="switch"><input type="checkbox" id="p-highlight"' + (product && Number(product.highlight) === 1 ? ' checked' : '') + ' />' +
        '<span class="switch__track"></span><span class="switch__text">Destacar<span class="switch__sub">Selo de destaque no card</span></span></label>' +
        '</div>' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="p-order">Ordem de exibicao</label>' +
        '<input class="input" id="p-order" type="number" min="0" max="100000" step="1" value="' +
        esc(product ? product.sort_order : '') +
        '" />' +
        '<span class="field__hint">Numeros menores aparecem primeiro. Use tambem os botoes de seta na lista.</span>' +
        '</div>' +
        '</form>',
      footer:
        '<button class="btn btn--ghost" type="button" data-role="cancel">Cancelar</button>' +
        '<button class="btn btn--primary" type="button" id="product-save">' + (product ? 'Salvar alteracoes' : 'Criar produto') + '</button>',
    });

    var statusSelect = el('#p-status', overlay);
    statusSelect.addEventListener('change', function () {
      var wrap = el('#p-until-wrap', overlay);
      if (wrap) wrap.hidden = statusSelect.value !== 'auto';
    });

    buildUploader(el('#product-uploader', overlay), {
      value: imageValue,
      onChange: function (url) {
        imageValue = url;
      },
    });

    el('[data-role="cancel"]', overlay).addEventListener('click', closeModal);

    var saveBtn = el('#product-save', overlay);
    saveBtn.addEventListener('click', function () {
      var name = el('#p-name', overlay).value.trim();
      if (!name) {
        alertBox('product-form-alert', 'Informe o nome do produto.');
        el('#p-name', overlay).classList.add('is-invalid');
        return;
      }

      var status = statusSelect.value;
      var payload = {
        name: name,
        description: el('#p-description', overlay).value,
        price: el('#p-price', overlay).value,
        price_note: el('#p-price-note', overlay).value,
        image: imageValue,
        status: status,
        available_until: status === 'auto' ? el('#p-until', overlay).value : '',
        active: el('#p-active', overlay).checked,
        highlight: el('#p-highlight', overlay).checked,
        sort_order: el('#p-order', overlay).value,
      };

      if (status === 'auto' && !payload.available_until) {
        alertBox('product-form-alert', 'Informe o horario em "Disponivel ate".');
        return;
      }

      alertBox('product-form-alert', '');
      busy(saveBtn, true, 'Salvando...');

      var request = product
        ? api('/admin/products/' + product.id, { method: 'PUT', body: payload })
        : api('/admin/products', { method: 'POST', body: payload });

      request
        .then(function (response) {
          toast(response.message || 'Produto salvo.', 'success');
          closeModal();
          return loadAll().then(function () {
            renderProducts();
            renderDashboard();
          });
        })
        .catch(function (error) {
          alertBox('product-form-alert', error.message);
          busy(saveBtn, false);
        });
    });
  }

  function handleProductAction(action, id) {
    var product = state.products.find(function (p) { return String(p.id) === String(id); });
    if (!product) return;

    if (action === 'edit-product') {
      openProductForm(id);
      return;
    }

    if (action === 'toggle-product') {
      var payload = {
        name: product.name,
        description: product.description,
        price: product.price,
        price_note: product.price_note,
        image: product.image,
        status: product.status,
        available_until: product.available_until,
        active: Number(product.active) !== 1,
        highlight: Number(product.highlight) === 1,
        sort_order: product.sort_order,
      };
      api('/admin/products/' + id, { method: 'PUT', body: payload })
        .then(function (response) {
          toast(response.message || 'Produto atualizado.', 'success');
          return loadAll().then(function () {
            renderProducts();
            renderDashboard();
          });
        })
        .catch(function (error) {
          toast(error.message, 'error');
        });
      return;
    }

    if (action === 'delete-product') {
      confirmDialog({
        title: 'Excluir produto',
        message: 'Deseja excluir "' + product.name + '"?',
        detail: 'O produto sera removido do site e das secoes relacionadas. Esta acao nao pode ser desfeita.',
      }).then(function (confirmed) {
        if (!confirmed) return;
        api('/admin/products/' + id, { method: 'DELETE' })
          .then(function () {
            toast('Produto excluido.', 'success');
            return loadAll().then(function () {
              renderProducts();
              renderDashboard();
            });
          })
          .catch(function (error) {
            toast(error.message, 'error');
          });
      });
      return;
    }

    if (action === 'move-product-up' || action === 'move-product-down') {
      var index = state.products.indexOf(product);
      var target = action === 'move-product-up' ? index - 1 : index + 1;
      if (target < 0 || target >= state.products.length) return;

      var reordered = state.products.slice();
      var tmp = reordered[index];
      reordered[index] = reordered[target];
      reordered[target] = tmp;

      state.products = reordered;
      renderProducts();

      api('/admin/products/reorder', {
        method: 'POST',
        body: { order: reordered.map(function (p) { return p.id; }) },
      })
        .then(function () {
          toast('Ordem atualizada.', 'success');
        })
        .catch(function (error) {
          toast(error.message, 'error');
          loadAll().then(renderProducts);
        });
    }
  }

  function initProductActions() {
    var box = $('products-list');
    if (!box) return;
    box.addEventListener('click', function (event) {
      var button = event.target.closest('[data-action]');
      if (!button || button.disabled) return;
      handleProductAction(button.getAttribute('data-action'), button.getAttribute('data-id'));
    });

    var newBtn = $('btn-new-product');
    if (newBtn) newBtn.addEventListener('click', function () { openProductForm(null); });
  }

  /* --------------------------------------------------------------------- */
  /* Secoes / quadros                                                       */
  /* --------------------------------------------------------------------- */

  function renderSections() {
    var box = $('sections-list');
    if (!box) return;

    if (!state.sections.length) {
      box.innerHTML =
        '<div class="empty"><h3>Nenhum quadro criado</h3>' +
        '<p>Crie quadros como "Novidades", "Promocoes", "Fabricacao" ou "Encomendas". Voce pode criar quantos quiser.</p>' +
        '<button class="btn btn--primary" type="button" id="empty-new-section">Criar primeiro quadro</button></div>';
      var emptyBtn = $('empty-new-section');
      if (emptyBtn) emptyBtn.addEventListener('click', function () { openSectionForm(null); });
      return;
    }

    box.innerHTML = state.sections
      .map(function (section, index) {
        var thumb = section.image
          ? '<img class="item__thumb" src="' + esc(section.image) + '" alt="" loading="lazy" />'
          : '<div class="item__thumb item__thumb--empty"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="15" width="18" height="5" rx="2"/></svg></div>';

        var layoutLabels = {
          'image-right': 'Imagem a direita',
          'image-left': 'Imagem a esquerda',
          'image-top': 'Imagem em cima',
          'no-image': 'Sem imagem',
        };

        var relatedCount = (section.product_ids || []).length;

        return (
          '<article class="item" data-section="' + esc(section.id) + '">' +
          thumb +
          '<div class="item__main">' +
          '<h3 class="item__title">' + esc(section.title) + '</h3>' +
          '<div class="item__meta">' +
          (Number(section.active) === 1
            ? '<span class="badge badge--on"><span class="dot"></span>Ativo</span>'
            : '<span class="badge badge--off"><span class="dot"></span>Inativo</span>') +
          '<span>' + esc(layoutLabels[section.layout] || section.layout) + '</span>' +
          (relatedCount ? '<span>' + relatedCount + ' produto(s) relacionado(s)</span>' : '') +
          '<span>Ordem ' + esc(section.sort_order) + '</span>' +
          '</div>' +
          (section.body ? '<p class="item__desc">' + esc(section.body) + '</p>' : '') +
          '<div class="item__actions">' +
          '<button class="btn btn--sm" type="button" data-action="edit-section" data-id="' + esc(section.id) + '">Editar</button>' +
          '<button class="btn btn--sm btn--ghost" type="button" data-action="toggle-section" data-id="' + esc(section.id) + '">' +
          (Number(section.active) === 1 ? 'Desativar' : 'Ativar') +
          '</button>' +
          '<button class="btn btn--sm btn--ghost btn--icon" type="button" data-action="move-section-up" data-id="' +
          esc(section.id) +
          '" title="Mover para cima" ' +
          (index === 0 ? 'disabled' : '') +
          '></button>' +
          '<button class="btn btn--sm btn--ghost btn--icon" type="button" data-action="move-section-down" data-id="' +
          esc(section.id) +
          '" title="Mover para baixo" ' +
          (index === state.sections.length - 1 ? 'disabled' : '') +
          '></button>' +
          '<button class="btn btn--sm btn--danger" type="button" data-action="delete-section" data-id="' + esc(section.id) + '">Excluir</button>' +
          '</div>' +
          '</div>' +
          '</article>'
        );
      })
      .join('');

    all('[data-action="move-section-up"]', box).forEach(function (btn) {
      btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M18 15l-6-6-6 6"/></svg>';
    });
    all('[data-action="move-section-down"]', box).forEach(function (btn) {
      btn.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 9l6 6 6-6"/></svg>';
    });
  }

  function openSectionForm(sectionId) {
    var section = sectionId
      ? state.sections.find(function (s) { return String(s.id) === String(sectionId); })
      : null;

    state.editingSectionId = section ? section.id : null;
    state.sectionProductIds = section ? (section.product_ids || []).slice() : [];
    var imageValue = section ? section.image || '' : '';

    var productRows = state.products.length
      ? state.products
          .map(function (p) {
            var checked = state.sectionProductIds.indexOf(p.id) !== -1;
            return (
              '<label class="picker__row">' +
              '<input type="checkbox" value="' + esc(p.id) + '"' + (checked ? ' checked' : '') + ' />' +
              '<span><span class="picker__name">' + esc(p.name) + '</span>' +
              '<span class="picker__meta">' +
              (Number(p.active) === 1 ? 'ativo' : 'inativo') +
              (p.price ? ' - ' + esc(formatPrice(p.price, state.settings.currency)) : '') +
              '</span></span>' +
              '</label>'
            );
          })
          .join('')
      : '<div class="picker__row" style="cursor:default"><span class="picker__meta">Nenhum produto cadastrado ainda.</span></div>';

    var overlay = openModal({
      title: section ? 'Editar quadro/secao' : 'Novo quadro/secao',
      body:
        '<div id="section-form-alert"></div>' +
        '<form id="section-form" autocomplete="off">' +
        '<div class="field">' +
        '<label class="field__label" for="s-title">Titulo *</label>' +
        '<input class="input" id="s-title" type="text" maxlength="160" placeholder="Ex: Novidades da semana" value="' +
        esc(section ? section.title : '') + '" />' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="s-subtitle">Subtitulo / selo</label>' +
        '<input class="input" id="s-subtitle" type="text" maxlength="240" placeholder="Ex: Chegou hoje" value="' +
        esc(section ? section.subtitle : '') + '" />' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="s-body">Texto</label>' +
        '<textarea class="textarea" id="s-body" maxlength="8000" placeholder="Escreva o texto desta secao. Deixe uma linha em branco entre paragrafos.">' +
        esc(section ? section.body : '') +
        '</textarea>' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label">Imagem da secao</label>' +
        '<div id="section-uploader"></div>' +
        '</div>' +
        '<div class="field-row">' +
        '<div class="field">' +
        '<label class="field__label" for="s-button-label">Texto do botao</label>' +
        '<input class="input" id="s-button-label" type="text" maxlength="80" placeholder="Ex: Ver promocoes" value="' +
        esc(section ? section.button_label : '') + '" />' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="s-button-style">Estilo do botao</label>' +
        '<select class="select" id="s-button-style">' +
        '<option value="primary"' + (section && section.button_style === 'primary' ? ' selected' : '') + '>Vermelho (destaque)</option>' +
        '<option value="secondary"' + (section && section.button_style === 'secondary' ? ' selected' : '') + '>Verde</option>' +
        '<option value="whatsapp"' + (section && section.button_style === 'whatsapp' ? ' selected' : '') + '>WhatsApp</option>' +
        '</select>' +
        '</div>' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="s-button-url">Link do botao</label>' +
        '<input class="input" id="s-button-url" type="text" maxlength="1000" placeholder="Ex: /#produtos ou https://wa.me/55..." value="' +
        esc(section ? section.button_url : '') + '" />' +
        '<span class="field__hint">Aceita link interno (comecando com /), site completo (https://), e-mail (mailto:) ou telefone (tel:).</span>' +
        '</div>' +
        '<div class="field-row">' +
        '<div class="field">' +
        '<label class="field__label" for="s-layout">Layout</label>' +
        '<select class="select" id="s-layout">' +
        '<option value="image-right"' + (section && section.layout === 'image-right' ? ' selected' : '') + '>Imagem a direita</option>' +
        '<option value="image-left"' + (section && section.layout === 'image-left' ? ' selected' : '') + '>Imagem a esquerda</option>' +
        '<option value="image-top"' + (section && section.layout === 'image-top' ? ' selected' : '') + '>Imagem em cima</option>' +
        '<option value="no-image"' + (section && section.layout === 'no-image' ? ' selected' : '') + '>Somente texto</option>' +
        '</select>' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="s-background">Fundo</label>' +
        '<select class="select" id="s-background">' +
        '<option value="light"' + (section && section.background === 'light' ? ' selected' : '') + '>Claro</option>' +
        '<option value="tint"' + (section && section.background === 'tint' ? ' selected' : '') + '>Bege</option>' +
        '<option value="dark"' + (section && section.background === 'dark' ? ' selected' : '') + '>Escuro</option>' +
        '</select>' +
        '</div>' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label">Produtos relacionados (opcional)</label>' +
        '<div class="picker" id="section-products">' + productRows + '</div>' +
        '<span class="field__hint">Os produtos marcados aparecem como selos dentro desta secao no site.</span>' +
        '</div>' +
        '<div class="field-row">' +
        '<div class="field">' +
        '<label class="switch"><input type="checkbox" id="s-active"' + (!section || Number(section.active) === 1 ? ' checked' : '') + ' />' +
        '<span class="switch__track"></span><span class="switch__text">Secao ativa<span class="switch__sub">Aparece no site</span></span></label>' +
        '</div>' +
        '<div class="field">' +
        '<label class="field__label" for="s-order">Ordem de exibicao</label>' +
        '<input class="input" id="s-order" type="number" min="0" max="100000" step="1" value="' +
        esc(section ? section.sort_order : '') +
        '" />' +
        '</div>' +
        '</div>' +
        '</form>',
      footer:
        '<button class="btn btn--ghost" type="button" data-role="cancel">Cancelar</button>' +
        '<button class="btn btn--primary" type="button" id="section-save">' + (section ? 'Salvar alteracoes' : 'Criar secao') + '</button>',
    });

    buildUploader(el('#section-uploader', overlay), {
      value: imageValue,
      onChange: function (url) {
        imageValue = url;
      },
    });

    el('[data-role="cancel"]', overlay).addEventListener('click', closeModal);

    var saveBtn = el('#section-save', overlay);
    saveBtn.addEventListener('click', function () {
      var title = el('#s-title', overlay).value.trim();
      if (!title) {
        alertBox('section-form-alert', 'Informe o titulo da secao.');
        el('#s-title', overlay).classList.add('is-invalid');
        return;
      }

      var buttonLabel = el('#s-button-label', overlay).value.trim();
      var buttonUrl = el('#s-button-url', overlay).value.trim();
      if (buttonLabel && !buttonUrl) {
        alertBox('section-form-alert', 'Informe o link do botao ou apague o texto do botao.');
        return;
      }

      var productIds = all('#section-products input:checked', overlay).map(function (input) {
        return parseInt(input.value, 10);
      });

      var payload = {
        title: title,
        subtitle: el('#s-subtitle', overlay).value,
        body: el('#s-body', overlay).value,
        image: imageValue,
        button_label: buttonLabel,
        button_url: buttonUrl,
        button_style: el('#s-button-style', overlay).value,
        layout: el('#s-layout', overlay).value,
        background: el('#s-background', overlay).value,
        active: el('#s-active', overlay).checked,
        sort_order: el('#s-order', overlay).value,
        product_ids: productIds,
      };

      alertBox('section-form-alert', '');
      busy(saveBtn, true, 'Salvando...');

      var request = section
        ? api('/admin/sections/' + section.id, { method: 'PUT', body: payload })
        : api('/admin/sections', { method: 'POST', body: payload });

      request
        .then(function (response) {
          toast(response.message || 'Secao salva.', 'success');
          closeModal();
          return loadAll().then(function () {
            renderSections();
            renderDashboard();
          });
        })
        .catch(function (error) {
          alertBox('section-form-alert', error.message);
          busy(saveBtn, false);
        });
    });
  }

  function handleSectionAction(action, id) {
    var section = state.sections.find(function (s) { return String(s.id) === String(id); });
    if (!section) return;

    if (action === 'edit-section') {
      openSectionForm(id);
      return;
    }

    if (action === 'toggle-section') {
      var payload = {
        title: section.title,
        subtitle: section.subtitle,
        body: section.body,
        image: section.image,
        button_label: section.button_label,
        button_url: section.button_url,
        button_style: section.button_style,
        layout: section.layout,
        background: section.background,
        active: Number(section.active) !== 1,
        sort_order: section.sort_order,
        product_ids: section.product_ids || [],
      };
      api('/admin/sections/' + id, { method: 'PUT', body: payload })
        .then(function (response) {
          toast(response.message || 'Secao atualizada.', 'success');
          return loadAll().then(function () {
            renderSections();
            renderDashboard();
          });
        })
        .catch(function (error) {
          toast(error.message, 'error');
        });
      return;
    }

    if (action === 'delete-section') {
      confirmDialog({
        title: 'Excluir quadro/secao',
        message: 'Deseja excluir "' + section.title + '"?',
        detail: 'A secao sera removida do site. Os produtos continuam cadastrados.',
      }).then(function (confirmed) {
        if (!confirmed) return;
        api('/admin/sections/' + id, { method: 'DELETE' })
          .then(function () {
            toast('Secao excluida.', 'success');
            return loadAll().then(function () {
              renderSections();
              renderDashboard();
            });
          })
          .catch(function (error) {
            toast(error.message, 'error');
          });
      });
      return;
    }

    if (action === 'move-section-up' || action === 'move-section-down') {
      var index = state.sections.indexOf(section);
      var target = action === 'move-section-up' ? index - 1 : index + 1;
      if (target < 0 || target >= state.sections.length) return;

      var reordered = state.sections.slice();
      var tmp = reordered[index];
      reordered[index] = reordered[target];
      reordered[target] = tmp;

      state.sections = reordered;
      renderSections();

      api('/admin/sections/reorder', {
        method: 'POST',
        body: { order: reordered.map(function (s) { return s.id; }) },
      })
        .then(function () {
          toast('Ordem atualizada.', 'success');
        })
        .catch(function (error) {
          toast(error.message, 'error');
          loadAll().then(renderSections);
        });
    }
  }

  function initSectionActions() {
    var box = $('sections-list');
    if (!box) return;
    box.addEventListener('click', function (event) {
      var button = event.target.closest('[data-action]');
      if (!button || button.disabled) return;
      handleSectionAction(button.getAttribute('data-action'), button.getAttribute('data-id'));
    });

    var newBtn = $('btn-new-section');
    if (newBtn) newBtn.addEventListener('click', function () { openSectionForm(null); });
  }

  /* --------------------------------------------------------------------- */
  /* Textos do site                                                         */
  /* --------------------------------------------------------------------- */

  var CONTENT_FIELDS = [
    {
      group: 'Apresentacao (topo do site)',
      fields: [
        { key: 'hero.badge', label: 'Selo', type: 'text', placeholder: 'Ex: Fornada quentinha todos os dias' },
        { key: 'hero.title', label: 'Titulo principal' },
        { key: 'hero.subtitle', label: 'Frase de apresentacao', type: 'textarea' },
        { key: 'hero.button_primary', label: 'Texto do botao principal' },
        { key: 'hero.button_secondary', label: 'Texto do botao do WhatsApp' },
        { key: 'hero.image', label: 'Imagem de destaque', type: 'image' },
      ],
    },
    {
      group: 'Sobre a panificadora',
      fields: [
        { key: 'about.subtitle', label: 'Selo' },
        { key: 'about.title', label: 'Titulo' },
        { key: 'about.body', label: 'Historia / texto', type: 'textarea', rows: 9 },
        { key: 'about.image', label: 'Imagem', type: 'image' },
      ],
    },
    {
      group: 'Area de produtos',
      fields: [
        { key: 'products.title', label: 'Titulo da secao' },
        { key: 'products.subtitle', label: 'Subtitulo', type: 'textarea', rows: 3 },
      ],
    },
    {
      group: 'Contato',
      fields: [
        { key: 'contact.title', label: 'Titulo' },
        { key: 'contact.subtitle', label: 'Subtitulo', type: 'textarea', rows: 3 },
      ],
    },
    {
      group: 'Localizacao',
      fields: [
        { key: 'location.title', label: 'Titulo' },
        { key: 'location.subtitle', label: 'Subtitulo', type: 'textarea', rows: 3 },
      ],
    },
    {
      group: 'Rodape',
      fields: [
        { key: 'footer.about', label: 'Texto do rodape', type: 'textarea', rows: 3 },
        { key: 'footer.rights', label: 'Texto de direitos autorais' },
      ],
    },
  ];

  function renderContentForm() {
    var box = $('content-form');
    if (!box) return;

    var html = CONTENT_FIELDS.map(function (group) {
      var fields = group.fields
        .map(function (field) {
          var value = state.content[field.key] || '';
          var inputId = 'c-' + field.key.replace(/\./g, '-');

          if (field.type === 'image') {
            return (
              '<div class="field"><label class="field__label">' + esc(field.label) + '</label>' +
              '<div data-image-field="' + esc(field.key) + '"></div></div>'
            );
          }

          if (field.type === 'textarea') {
            return (
              '<div class="field"><label class="field__label" for="' + inputId + '">' + esc(field.label) + '</label>' +
              '<textarea class="textarea" id="' + inputId + '" data-content-key="' + esc(field.key) + '" rows="' +
              (field.rows || 4) +
              '">' + esc(value) + '</textarea></div>'
            );
          }

          return (
            '<div class="field"><label class="field__label" for="' + inputId + '">' + esc(field.label) + '</label>' +
            '<input class="input" type="text" id="' + inputId + '" data-content-key="' + esc(field.key) + '" maxlength="8000" placeholder="' +
            esc(field.placeholder || '') +
            '" value="' + esc(value) + '" /></div>'
          );
        })
        .join('');

      return (
        '<div class="card"><div class="card__head"><h3 class="card__title">' +
        esc(group.group) +
        '</h3></div><div class="card__body">' +
        fields +
        '</div></div>'
      );
    }).join('');

    html +=
      '<div class="card"><div class="card__body"><button class="btn btn--primary btn--block" type="button" id="content-save">Salvar textos</button></div></div>';

    box.innerHTML = '<div id="content-alert"></div>' + html;

    all('[data-image-field]', box).forEach(function (container) {
      var key = container.getAttribute('data-image-field');
      state.content[key] = state.content[key] || '';
      buildUploader(container, {
        value: state.content[key],
        onChange: function (url) {
          state.content[key] = url;
        },
      });
    });

    var saveBtn = $('content-save');
    saveBtn.addEventListener('click', function () {
      var payload = {};
      all('[data-content-key]', box).forEach(function (input) {
        payload[input.getAttribute('data-content-key')] = input.value;
      });
      CONTENT_FIELDS.forEach(function (group) {
        group.fields.forEach(function (field) {
          if (field.type === 'image') payload[field.key] = state.content[field.key] || '';
        });
      });

      alertBox('content-alert', '');
      busy(saveBtn, true, 'Salvando...');

      api('/admin/content', { method: 'PUT', body: payload })
        .then(function (response) {
          toast(response.message || 'Textos salvos.', 'success');
          return loadAll();
        })
        .catch(function (error) {
          alertBox('content-alert', error.message);
        })
        .then(function () {
          busy(saveBtn, false);
        });
    });
  }

  /* --------------------------------------------------------------------- */
  /* Imagens                                                                */
  /* --------------------------------------------------------------------- */

  function renderMedia() {
    var grid = $('media-grid');
    if (!grid) return;

    if (!state.media.length) {
      grid.innerHTML =
        '<div class="empty" style="grid-column:1/-1"><h3>Nenhuma imagem enviada</h3>' +
        '<p>Envie a primeira imagem usando a area acima.</p></div>';
      return;
    }

    grid.innerHTML =
      '<div class="media-grid" style="grid-column:1/-1">' +
      state.media
        .map(function (item) {
          return (
            '<div class="media-card" data-media="' + esc(item.id) + '">' +
            '<img src="/api/media/' + esc(item.id) + '" alt="' + esc(item.alt || item.filename) + '" loading="lazy" data-url="/api/media/' + esc(item.id) + '" />' +
            '<button class="media-card__del" type="button" data-action="delete-media" data-id="' + esc(item.id) + '" aria-label="Excluir imagem">' +
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>' +
            '</button>' +
            '<div class="media-card__meta">' + esc(item.filename) + ' - ' + formatBytes(item.size) + '</div>' +
            '</div>'
          );
        })
        .join('') +
      '</div>';

    all('[data-url]', grid).forEach(function (img) {
      img.addEventListener('click', function () {
        var url = img.getAttribute('data-url');
        copyText(url).then(function () {
          toast('Endereco copiado: ' + url, 'success');
        });
      });
    });
  }

  function copyText(value) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(value);
    }
    return new Promise(function (resolve) {
      var input = document.createElement('textarea');
      input.value = value;
      input.style.position = 'fixed';
      input.style.opacity = '0';
      document.body.appendChild(input);
      input.select();
      try {
        document.execCommand('copy');
      } catch (e) {
        /* ignore */
      }
      document.body.removeChild(input);
      resolve();
    });
  }

  function initMedia() {
    var container = $('media-uploader');
    if (container) {
      buildUploader(container, {
        onChange: function () {
          /* A imagem ja e enviada no upload; a galeria e atualizada abaixo. */
          loadAll().then(renderMedia);
        },
      });
    }

    var box = $('media-grid');
    if (box) {
      box.addEventListener('click', function (event) {
        var button = event.target.closest('[data-action="delete-media"]');
        if (!button) return;
        var id = button.getAttribute('data-id');
        var item = state.media.find(function (m) { return String(m.id) === String(id); });
        if (!item) return;

        var inUse = detectMediaUsage('/api/media/' + id);

        confirmDialog({
          title: 'Excluir imagem',
          message: 'Deseja excluir "' + item.filename + '"?',
          detail: inUse.length
            ? 'Atencao: esta imagem esta sendo usada em: ' + inUse.join(', ') + '. Esses locais ficarao sem imagem.'
            : 'A imagem sera removida definitivamente.',
        }).then(function (confirmed) {
          if (!confirmed) return;
          api('/admin/media/' + id, { method: 'DELETE' })
            .then(function () {
              toast('Imagem excluida.', 'success');
              state.media = state.media.filter(function (m) { return String(m.id) !== String(id); });
              renderMedia();
              renderDashboard();
            })
            .catch(function (error) {
              toast(error.message, 'error');
            });
        });
      });
    }

    var reload = $('btn-reload-media');
    if (reload) {
      reload.addEventListener('click', function () {
        loadAll().then(function () {
          renderMedia();
          toast('Galeria atualizada.', 'success');
        });
      });
    }
  }

  /** Procura onde a imagem esta sendo usada (produtos, secoes, textos). */
  function detectMediaUsage(url) {
    var places = [];
    state.products.forEach(function (p) {
      if (p.image === url) places.push('produto "' + p.name + '"');
    });
    state.sections.forEach(function (s) {
      if (s.image === url) places.push('secao "' + s.title + '"');
    });
    Object.keys(state.content).forEach(function (key) {
      if (state.content[key] === url) places.push('texto "' + key + '"');
    });
    ['logo_image', 'hero.image', 'about.image'].forEach(function (key) {
      if (state.settings[key] === url) places.push('configuracao "' + key + '"');
    });
    return places;
  }

  /* --------------------------------------------------------------------- */
  /* Configuracoes                                                          */
  /* --------------------------------------------------------------------- */

  var WEEKDAYS = [
    { day: 'monday', label: 'Segunda-feira' },
    { day: 'tuesday', label: 'Terca-feira' },
    { day: 'wednesday', label: 'Quarta-feira' },
    { day: 'thursday', label: 'Quinta-feira' },
    { day: 'friday', label: 'Sexta-feira' },
    { day: 'saturday', label: 'Sabado' },
    { day: 'sunday', label: 'Domingo' },
  ];

  function parseHours(raw) {
    try {
      var parsed = JSON.parse(raw || '[]');
      if (!Array.isArray(parsed)) return [];
      return parsed;
    } catch (e) {
      return [];
    }
  }

  function renderSettingsForm() {
    var box = $('settings-form');
    if (!box) return;

    var s = state.settings;
    var hours = parseHours(s.business_hours);

    var hoursHtml = WEEKDAYS.map(function (day) {
      var entry = hours.find(function (h) { return h && h.day === day.day; }) || {
        day: day.day,
        label: day.label,
        closed: false,
        open: '06:00',
        close: '19:00',
      };
      return (
        '<div class="hours-editor__row" data-day="' + esc(day.day) + '">' +
        '<label class="hours-editor__label"><input type="checkbox" data-role="closed"' +
        (entry.closed ? ' checked' : '') +
        ' /> ' +
        esc(day.label) +
        '</label>' +
        '<div class="hours-editor__times">' +
        '<input class="input" type="time" data-role="open" value="' + esc(entry.open || '06:00') + '" />' +
        '<input class="input" type="time" data-role="close" value="' + esc(entry.close || '19:00') + '" />' +
        '</div>' +
        '<input type="hidden" data-role="label" value="' + esc(entry.label || day.label) + '" />' +
        '</div>'
      );
    }).join('');

    box.innerHTML =
      '<div id="settings-alert"></div>' +

      '<div class="card"><div class="card__head"><h3 class="card__title">Identidade</h3>' +
      '<p class="card__sub">Nome e logo usados no site.</p></div><div class="card__body">' +
      '<div class="field"><label class="field__label" for="set-company">Nome da empresa</label>' +
      '<input class="input" id="set-company" maxlength="160" value="' + esc(s.company_name || '') + '" /></div>' +
      '<div class="field"><label class="field__label" for="set-tagline">Frase curta (subtitulo do logo)</label>' +
      '<input class="input" id="set-tagline" maxlength="200" value="' + esc(s.company_tagline || '') + '" /></div>' +
      '<div class="field"><label class="field__label">Logo</label><div id="settings-logo"></div></div>' +
      '</div></div>' +

      '<div class="card"><div class="card__head"><h3 class="card__title">Contato</h3></div><div class="card__body">' +
      '<div class="field-row">' +
      '<div class="field"><label class="field__label" for="set-phone">Telefone</label>' +
      '<input class="input" id="set-phone" type="tel" placeholder="(00) 0000-0000" maxlength="40" value="' + esc(s.phone || '') + '" /></div>' +
      '<div class="field"><label class="field__label" for="set-whatsapp">WhatsApp</label>' +
      '<input class="input" id="set-whatsapp" type="tel" placeholder="5511999999999" maxlength="40" value="' + esc(s.whatsapp || '') + '" />' +
      '<span class="field__hint">Com codigo do pais e DDD. Ex: 5511999999999</span></div>' +
      '</div>' +
      '<div class="field"><label class="field__label" for="set-whatsapp-msg">Mensagem automatica do WhatsApp</label>' +
      '<textarea class="textarea" id="set-whatsapp-msg" rows="3" maxlength="500">' + esc(s.whatsapp_message || '') + '</textarea></div>' +
      '<div class="field-row">' +
      '<div class="field"><label class="field__label" for="set-instagram">Instagram</label>' +
      '<input class="input" id="set-instagram" placeholder="@panificadora ou link completo" maxlength="300" value="' + esc(s.instagram || '') + '" /></div>' +
      '<div class="field"><label class="field__label" for="set-email">E-mail</label>' +
      '<input class="input" id="set-email" type="email" maxlength="200" value="' + esc(s.email || '') + '" /></div>' +
      '</div>' +
      '<div class="field-row">' +
      '<div class="field"><label class="field__label" for="set-facebook">Facebook</label>' +
      '<input class="input" id="set-facebook" maxlength="300" value="' + esc(s.facebook || '') + '" /></div>' +
      '<div class="field"><label class="field__label" for="set-tiktok">TikTok</label>' +
      '<input class="input" id="set-tiktok" maxlength="300" value="' + esc(s.tiktok || '') + '" /></div>' +
      '</div>' +
      '</div></div>' +

      '<div class="card"><div class="card__head"><h3 class="card__title">Endereco e localizacao</h3></div><div class="card__body">' +
      '<div class="field"><label class="field__label" for="set-address">Endereco (rua e numero)</label>' +
      '<input class="input" id="set-address" maxlength="300" value="' + esc(s.address_line || '') + '" /></div>' +
      '<div class="field"><label class="field__label" for="set-city">Cidade / Estado / CEP</label>' +
      '<input class="input" id="set-city" maxlength="300" value="' + esc(s.address_city || '') + '" /></div>' +
      '<div class="field"><label class="field__label" for="set-notes">Complemento / referencia</label>' +
      '<input class="input" id="set-notes" maxlength="300" value="' + esc(s.address_notes || '') + '" /></div>' +
      '<div class="field"><label class="field__label" for="set-maps">Link do Google Maps</label>' +
      '<input class="input" id="set-maps" maxlength="1000" placeholder="https://maps.app.goo.gl/..." value="' + esc(s.google_maps_url || '') + '" />' +
      '<span class="field__hint">Usado no botao "Abrir no Google Maps".</span></div>' +
      '<div class="field"><label class="field__label" for="set-maps-embed">Link de incorporar o mapa (iframe)</label>' +
      '<textarea class="textarea" id="set-maps-embed" rows="3" maxlength="2000" placeholder="https://www.google.com/maps/embed?pb=...">' +
      esc(s.google_maps_embed || '') +
      '</textarea>' +
      '<span class="field__hint">No Google Maps: Compartilhar > Incorporar um mapa > copie apenas o endereco do atributo src.</span></div>' +
      '</div></div>' +

      '<div class="card"><div class="card__head"><h3 class="card__title">Horarios de atendimento</h3>' +
      '<p class="card__sub">Marque "fechado" nos dias sem atendimento.</p></div>' +
      '<div class="card__body"><div class="hours-editor" id="hours-editor">' + hoursHtml + '</div>' +
      '<div class="field" style="margin-top:16px"><label class="field__label" for="set-timezone">Fuso horario</label>' +
      '<input class="input" id="set-timezone" maxlength="60" value="' + esc(s.timezone || 'America/Sao_Paulo') + '" />' +
      '<span class="field__hint">Padrao: America/Sao_Paulo. Usado para calcular a disponibilidade dos produtos.</span></div>' +
      '</div></div>' +

      '<div class="card"><div class="card__head"><h3 class="card__title">Moeda e SEO</h3></div><div class="card__body">' +
      '<div class="field-row">' +
      '<div class="field"><label class="field__label" for="set-currency">Moeda</label>' +
      '<input class="input" id="set-currency" maxlength="3" value="' + esc(s.currency || 'BRL') + '" /></div>' +
      '<div class="field"><label class="field__label" for="set-seo-title">Titulo do site (Google/abas)</label>' +
      '<input class="input" id="set-seo-title" maxlength="160" value="' + esc(s.seo_title || '') + '" /></div>' +
      '</div>' +
      '<div class="field"><label class="field__label" for="set-seo-desc">Descricao do site</label>' +
      '<textarea class="textarea" id="set-seo-desc" rows="3" maxlength="400">' + esc(s.seo_description || '') + '</textarea></div>' +
      '</div></div>' +

      '<div class="card"><div class="card__body"><button class="btn btn--primary btn--block" type="button" id="settings-save">Salvar configuracoes</button></div></div>';

    buildUploader($('settings-logo'), {
      value: s.logo_image || '',
      onChange: function (url) {
        state.settings.logo_image = url;
      },
    });

    var saveBtn = $('settings-save');
    saveBtn.addEventListener('click', function () {
      var hoursPayload = all('#hours-editor .hours-editor__row', box).map(function (row) {
        return {
          day: row.getAttribute('data-day'),
          label: el('[data-role="label"]', row).value,
          closed: el('[data-role="closed"]', row).checked,
          open: el('[data-role="open"]', row).value,
          close: el('[data-role="close"]', row).value,
        };
      });

      var payload = {
        company_name: $('set-company').value,
        company_tagline: $('set-tagline').value,
        logo_image: state.settings.logo_image || '',
        phone: $('set-phone').value,
        whatsapp: $('set-whatsapp').value,
        whatsapp_message: $('set-whatsapp-msg').value,
        instagram: $('set-instagram').value,
        email: $('set-email').value,
        facebook: $('set-facebook').value,
        tiktok: $('set-tiktok').value,
        address_line: $('set-address').value,
        address_city: $('set-city').value,
        address_notes: $('set-notes').value,
        google_maps_url: $('set-maps').value,
        google_maps_embed: $('set-maps-embed').value,
        business_hours: hoursPayload,
        timezone: $('set-timezone').value,
        currency: $('set-currency').value,
        seo_title: $('set-seo-title').value,
        seo_description: $('set-seo-desc').value,
      };

      var mapsUrl = payload.google_maps_url.trim();
      if (mapsUrl && !/^https?:\/\//i.test(mapsUrl)) {
        alertBox('settings-alert', 'O link do Google Maps deve comecar com https://');
        return;
      }

      alertBox('settings-alert', '');
      busy(saveBtn, true, 'Salvando...');

      api('/admin/settings', { method: 'PUT', body: payload })
        .then(function (response) {
          toast(response.message || 'Configuracoes salvas.', 'success');
          return loadAll();
        })
        .then(function () {
          updateTopbar();
          renderSettingsForm();
        })
        .catch(function (error) {
          alertBox('settings-alert', error.message);
          busy(saveBtn, false);
        });
    });
  }

  /* --------------------------------------------------------------------- */
  /* Conta e administradores                                                */
  /* --------------------------------------------------------------------- */

  function renderAccount() {
    var box = $('admins-list');
    if (!box) return;

    if (!state.admins.length) {
      box.innerHTML = '<div class="empty"><p>Nao foi possivel carregar os administradores.</p></div>';
      return;
    }

    box.innerHTML = state.admins
      .map(function (admin) {
        var isMe = state.admin && admin.id === state.admin.id;
        return (
          '<div class="item" style="margin-bottom:10px">' +
          '<div class="item__thumb item__thumb--empty"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></div>' +
          '<div class="item__main">' +
          '<h3 class="item__title">' + esc(admin.name) + (isMe ? ' (voce)' : '') + '</h3>' +
          '<div class="item__meta">' +
          '<span>' + esc(admin.email) + '</span>' +
          '<span class="badge ' + (Number(admin.active) === 1 ? 'badge--on' : 'badge--neutral') + '">' +
          (Number(admin.active) === 1 ? 'Ativo' : 'Inativo') + '</span>' +
          '<span class="badge badge--neutral">' + (admin.role === 'admin' ? 'Administrador' : 'Editor') + '</span>' +
          '<span>Ultimo acesso: ' + esc(formatDate(admin.last_login_at)) + '</span>' +
          '</div>' +
          '<div class="item__actions">' +
          (isMe
            ? '<span style="color:var(--muted);font-size:.82rem">Sessao atual</span>'
            : '<button class="btn btn--sm btn--ghost" type="button" data-action="toggle-admin" data-id="' + esc(admin.id) + '">' +
              (Number(admin.active) === 1 ? 'Desativar' : 'Ativar') +
              '</button>' +
              '<button class="btn btn--sm btn--danger" type="button" data-action="delete-admin" data-id="' + esc(admin.id) + '">Excluir</button>') +
          '</div>' +
          '</div>' +
          '</div>'
        );
      })
      .join('');

    box.onclick = function (event) {
      var button = event.target.closest('[data-action]');
      if (!button) return;
      var id = button.getAttribute('data-id');
      var admin = state.admins.find(function (a) { return String(a.id) === String(id); });
      if (!admin) return;

      if (button.getAttribute('data-action') === 'toggle-admin') {
        api('/admin/admins/' + id, {
          method: 'PUT',
          body: { name: admin.name, role: admin.role, active: Number(admin.active) !== 1 },
        })
          .then(function (response) {
            toast(response.message || 'Administrador atualizado.', 'success');
            return loadAll();
          })
          .then(renderAccount)
          .catch(function (error) {
            toast(error.message, 'error');
          });
        return;
      }

      if (button.getAttribute('data-action') === 'delete-admin') {
        confirmDialog({
          title: 'Excluir administrador',
          message: 'Deseja excluir "' + admin.name + '" (' + admin.email + ')?',
          detail: 'O usuario perdera o acesso ao Painel ADM imediatamente.',
        }).then(function (confirmed) {
          if (!confirmed) return;
          api('/admin/admins/' + id, { method: 'DELETE' })
            .then(function () {
              toast('Administrador excluido.', 'success');
              return loadAll();
            })
            .then(renderAccount)
            .catch(function (error) {
              toast(error.message, 'error');
            });
        });
      }
    };
  }

  function initAccount() {
    var form = $('password-form');
    if (form) {
      form.addEventListener('submit', function (event) {
        event.preventDefault();
        var current = $('pwd-current').value;
        var next = $('pwd-new').value;
        var confirm = $('pwd-confirm').value;

        if (next !== confirm) {
          alertBox('password-alert', 'As senhas novas nao conferem.');
          return;
        }

        var btn = $('password-submit');
        alertBox('password-alert', '');
        busy(btn, true, 'Salvando...');

        api('/admin/change-password', {
          method: 'POST',
          body: { current_password: current, new_password: next, new_password_confirm: confirm },
        })
          .then(function (response) {
            toast(response.message || 'Senha alterada.', 'success');
            form.reset();
            state.mustChangePassword = false;
            alertBox('password-alert', '');
          })
          .catch(function (error) {
            alertBox('password-alert', error.message);
          })
          .then(function () {
            busy(btn, false);
          });
      });
    }

    var newAdmin = $('btn-new-admin');
    if (newAdmin) {
      newAdmin.addEventListener('click', function () {
        var overlay = openModal({
          title: 'Novo administrador',
          size: 'sm',
          body:
            '<div id="admin-form-alert"></div>' +
            '<div class="field"><label class="field__label" for="a-name">Nome</label>' +
            '<input class="input" id="a-name" maxlength="120" /></div>' +
            '<div class="field"><label class="field__label" for="a-email">E-mail</label>' +
            '<input class="input" id="a-email" type="email" maxlength="160" /></div>' +
            '<div class="field"><label class="field__label" for="a-role">Permissao</label>' +
            '<select class="select" id="a-role"><option value="admin">Administrador (acesso total)</option>' +
            '<option value="editor">Editor</option></select></div>' +
            '<div class="field"><label class="field__label" for="a-password">Senha provisoria</label>' +
            '<input class="input" id="a-password" type="text" minlength="8" />' +
            '<span class="field__hint">Minimo 8 caracteres, com uma letra e um numero. O usuario sera obrigado a trocar a senha no primeiro acesso.</span></div>',
          footer:
            '<button class="btn btn--ghost" type="button" data-role="cancel">Cancelar</button>' +
            '<button class="btn btn--primary" type="button" id="admin-save">Criar usuario</button>',
        });

        el('[data-role="cancel"]', overlay).addEventListener('click', closeModal);

        var saveBtn = el('#admin-save', overlay);
        saveBtn.addEventListener('click', function () {
          var payload = {
            name: el('#a-name', overlay).value.trim(),
            email: el('#a-email', overlay).value.trim(),
            role: el('#a-role', overlay).value,
            password: el('#a-password', overlay).value,
          };

          if (!payload.email) {
            alertBox('admin-form-alert', 'Informe o e-mail.');
            return;
          }

          alertBox('admin-form-alert', '');
          busy(saveBtn, true, 'Criando...');

          api('/admin/admins', { method: 'POST', body: payload })
            .then(function (response) {
              toast(response.message || 'Administrador criado.', 'success');
              closeModal();
              return loadAll();
            })
            .then(renderAccount)
            .catch(function (error) {
              alertBox('admin-form-alert', error.message);
              busy(saveBtn, false);
            });
        });
      });
    }
  }

  /* --------------------------------------------------------------------- */
  /* Autenticacao                                                           */
  /* --------------------------------------------------------------------- */

  function updateTopbar() {
    var name = state.settings.company_name || 'Panificadora Frank';
    var mark = $('top-mark');
    if (mark) {
      var parts = name.trim().split(/\s+/).slice(0, 2);
      mark.textContent = parts.map(function (p) { return p.charAt(0).toUpperCase(); }).join('') || 'PF';
    }
    var company = $('top-company');
    if (company) company.textContent = name;
    var user = $('top-user');
    if (user && state.admin) user.textContent = state.admin.name + ' - ' + state.admin.email;
    var sub = $('login-brand-sub');
    if (sub) sub.textContent = name;
  }

  function showScreen(name) {
    ['loading', 'setup', 'login', 'app'].forEach(function (screen) {
      var node = $('screen-' + screen);
      if (node) node.hidden = screen !== name;
    });
    var app = $('app');
    if (app) app.hidden = name !== 'app';
  }

  function initLogin() {
    var form = $('login-form');
    if (!form) return;
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var btn = $('login-submit');
      alertBox('login-alert', '');
      busy(btn, true, 'Entrando...');

      api('/auth/login', {
        method: 'POST',
        body: { email: $('login-email').value.trim(), password: $('login-password').value },
      })
        .then(function () {
          form.reset();
          return startPanel();
        })
        .catch(function (error) {
          alertBox('login-alert', error.message);
          busy(btn, false);
        });
    });
  }

  function initSetup() {
    var form = $('setup-form');
    if (!form) return;
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var password = $('setup-password').value;
      var confirm = $('setup-confirm').value;

      if (password !== confirm) {
        alertBox('setup-alert', 'As senhas nao conferem.');
        return;
      }
      if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) {
        alertBox('setup-alert', 'A senha deve ter no minimo 8 caracteres, com pelo menos uma letra e um numero.');
        return;
      }

      var btn = $('setup-submit');
      alertBox('setup-alert', '');
      busy(btn, true, 'Criando...');

      api('/setup', {
        method: 'POST',
        body: {
          name: $('setup-name').value.trim(),
          email: $('setup-email').value.trim(),
          password: password,
          password_confirm: confirm,
        },
      })
        .then(function () {
          toast('Administrador criado com sucesso.', 'success');
          return startPanel();
        })
        .catch(function (error) {
          alertBox('setup-alert', error.message);
          busy(btn, false);
        });
    });
  }

  function initLogout() {
    var btn = $('btn-logout');
    if (!btn) return;
    btn.addEventListener('click', function () {
      confirmDialog({
        title: 'Sair do Painel ADM',
        message: 'Deseja encerrar a sessao?',
        confirmLabel: 'Sair',
      }).then(function (confirmed) {
        if (!confirmed) return;
        api('/auth/logout', { method: 'POST' })
          .catch(function () {
            /* mesmo com falha, limpamos a tela */
          })
          .then(function () {
            state.admin = null;
            showScreen('login');
            toast('Sessao encerrada.', 'success');
          });
      });
    });
  }

  /* --------------------------------------------------------------------- */
  /* Carregamento de dados                                                  */
  /* --------------------------------------------------------------------- */

  function loadAll() {
    return Promise.all([
      api('/admin/settings'),
      api('/admin/content'),
      api('/admin/products'),
      api('/admin/sections'),
      api('/admin/media'),
      api('/admin/admins').catch(function () {
        return { admins: [] };
      }),
    ]).then(function (results) {
      state.settings = results[0].settings || {};
      state.content = results[1].content || {};
      state.products = results[2].products || [];
      state.sections = results[3].sections || [];
      state.media = results[4].media || [];
      state.admins = results[5].admins || [];
      updateTopbar();
      return state;
    });
  }

  function startPanel() {
    showScreen('app');
    var hash = (window.location.hash || '').replace('#', '');
    var initialView = VIEWS.indexOf(hash) !== -1 ? hash : 'dashboard';

    return api('/auth/me')
      .then(function (me) {
        if (!me.authenticated) {
          showScreen('login');
          return null;
        }
        state.admin = me.admin;
        state.mustChangePassword = Boolean(me.admin.must_change_password);
        return loadAll().then(function () {
          if (state.mustChangePassword) {
            toast('Troque sua senha provisoria em Conta e seguranca.', 'error');
            showView('account');
          } else {
            showView(initialView);
          }
          return state;
        });
      })
      .catch(function () {
        showScreen('login');
        return null;
      });
  }

  function boot() {
    initTabs();
    initQuickActions();
    initProductActions();
    initSectionActions();
    initMedia();
    initAccount();
    initLogin();
    initSetup();
    initLogout();

    var refresh = $('btn-refresh');
    if (refresh) {
      refresh.addEventListener('click', function () {
        loadAll().then(function () {
          renderDashboard();
          toast('Dados atualizados.', 'success');
        });
      });
    }

    showScreen('loading');

    Promise.all([
      api('/setup/status').catch(function () {
        return { setup_required: false };
      }),
      api('/auth/me').catch(function () {
        return { authenticated: false };
      }),
    ])
      .then(function (results) {
        var setup = results[0];
        var me = results[1];

        if (setup.setup_required) {
          showScreen('setup');
          return null;
        }

        var hash = (window.location.hash || '').replace('#', '');
        if (hash === 'setup') {
          history.replaceState(null, '', window.location.pathname);
        }

        if (me.authenticated) return startPanel();

        showScreen('login');
        return null;
      })
      .catch(function (error) {
        showScreen('login');
        alertBox('login-alert', 'Nao foi possivel conectar ao servidor: ' + error.message);
      });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
