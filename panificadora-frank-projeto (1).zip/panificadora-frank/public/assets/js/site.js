/* ==========================================================================
   Panificadora Frank - Site publico
   Consome a API /api/site e monta a pagina. Nenhum dado simulado:
   tudo o que aparece na tela vem do banco de dados (editavel no Painel ADM).
   ========================================================================== */
(function () {
  'use strict';

  var state = {
    data: null,
    filter: 'available',
    whatsapp: '',
    whatsappMessage: '',
  };

  /* --------------------------------------------------------------------- */
  /* Helpers                                                                */
  /* --------------------------------------------------------------------- */

  function $(id) {
    return document.getElementById(id);
  }

  function setText(id, value) {
    var el = $(id);
    if (el) el.textContent = value || '';
  }

  function escapeHtml(value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /** Converte quebras de linha em paragrafos seguros. */
  function paragraphs(value) {
    var text = String(value || '').trim();
    if (!text) return '';
    return text
      .split(/\n{2,}/)
      .map(function (block) {
        var lines = block
          .split('\n')
          .map(function (line) {
            return escapeHtml(line);
          })
          .join('<br />');
        return '<p>' + lines + '</p>';
      })
      .join('');
  }

  function setImage(imgId, url, fallbackId) {
    var img = $(imgId);
    if (!img) return;
    if (url) {
      img.src = url;
      img.removeAttribute('hidden');
      var fallback = $(fallbackId || '');
      if (fallback) fallback.hidden = true;
    } else {
      img.hidden = true;
    }
  }

  function digits(value) {
    return String(value || '').replace(/\D/g, '');
  }

  /** Link de conversa no WhatsApp (wa.me) — abre o aplicativo/site do WhatsApp. */
  function whatsappLink(number, message) {
    var n = digits(number);
    if (!n) return '';
    var text = message ? '?text=' + encodeURIComponent(message) : '';
    return 'https://wa.me/' + n + text;
  }

  function instagramLink(value) {
    if (!value) return '';
    var v = String(value).trim();
    if (/^https?:\/\//i.test(v)) return v;
    var handle = v.replace(/^@/, '');
    return 'https://instagram.com/' + handle;
  }

  function telLink(value) {
    var n = digits(value);
    return n ? 'tel:+' + n.replace(/^\+/, '') : '';
  }

  function formatTimeRange(hours) {
    if (!hours) return '';
    if (hours.closed) return 'Fechado';
    if (hours.open && hours.close) return hours.open + ' as ' + hours.close;
    return hours.open || hours.close || '';
  }

  var WEEKDAY_LABELS = {
    monday: 'Segunda-feira',
    tuesday: 'Terca-feira',
    wednesday: 'Quarta-feira',
    thursday: 'Quinta-feira',
    friday: 'Sexta-feira',
    saturday: 'Sabado',
    sunday: 'Domingo',
  };

  /* --------------------------------------------------------------------- */
  /* Cabecalho / menu                                                       */
  /* --------------------------------------------------------------------- */

  function initHeader(data) {
    var settings = data.settings || {};
    var name = settings.company_name || 'Panificadora Frank';

    setText('brand-name', name);
    setText('brand-tagline', settings.company_tagline || '');
    setText('footer-name', name);
    setText('footer-name-inline', name);

    var monogram = initials(name);
    setText('brand-monogram', monogram);
    setText('footer-monogram', monogram);

    if (settings.logo_image) {
      var logo = $('brand-logo');
      var mono = $('brand-monogram');
      if (logo) {
        logo.src = settings.logo_image;
        logo.hidden = false;
        logo.addEventListener('error', function () {
          logo.hidden = true;
          if (mono) mono.hidden = false;
        });
        if (mono) mono.hidden = true;
      }
    }

    // WhatsApp
    state.whatsapp = settings.whatsapp || settings.phone || '';
    state.whatsappMessage = settings.whatsapp_message || '';
    var wa = whatsappLink(state.whatsapp, state.whatsappMessage);

    ['header-whatsapp', 'hero-button-secondary', 'whatsapp-float'].forEach(function (id) {
      var el = $(id);
      if (!el) return;
      if (wa) {
        el.href = wa;
        el.hidden = false;
      } else {
        el.hidden = true;
      }
    });

    var float = $('whatsapp-float');
    if (float && float.hidden) float.style.display = 'none';

    // Instagram no menu
    var ig = instagramLink(settings.instagram);
    var igEl = $('menu-instagram');
    if (igEl && ig) {
      igEl.href = ig;
      igEl.hidden = false;
    }

    // Google Maps no menu
    var mapsEl = $('menu-maps');
    if (mapsEl && settings.google_maps_url) {
      mapsEl.href = settings.google_maps_url;
      mapsEl.hidden = false;
    }

    // SEO dinamico
    var title = settings.seo_title || name;
    document.title = title;
    var desc = settings.seo_description || '';
    var metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc && desc) metaDesc.setAttribute('content', desc);
    var ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute('content', title);
    var ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc && desc) ogDesc.setAttribute('content', desc);
    if (settings.logo_image) {
      var icon = document.querySelector('link[rel="icon"]');
      if (icon) icon.setAttribute('href', settings.logo_image);
    }

    var theme = document.querySelector('meta[name="theme-color"]');
    if (theme) theme.setAttribute('content', '#c1121f');
  }

  function initials(name) {
    var parts = String(name || '')
      .trim()
      .split(/\s+/)
      .filter(Boolean);
    if (!parts.length) return 'PF';
    var take = parts.slice(0, 2).map(function (p) {
      return p.charAt(0).toUpperCase();
    });
    return take.join('') || 'PF';
  }

  function initMenu() {
    var trigger = $('menu-trigger');
    var panel = $('menu-panel');
    var backdrop = $('menu-backdrop');
    if (!trigger || !panel) return;

    function close() {
      panel.classList.remove('is-open');
      trigger.setAttribute('aria-expanded', 'false');
      if (backdrop) {
        backdrop.classList.remove('is-open');
        window.setTimeout(function () {
          backdrop.hidden = true;
        }, 200);
      }
      document.body.classList.remove('no-scroll');
    }

    function open() {
      panel.classList.add('is-open');
      trigger.setAttribute('aria-expanded', 'true');
      if (backdrop) {
        backdrop.hidden = false;
        requestAnimationFrame(function () {
          backdrop.classList.add('is-open');
        });
      }
    }

    trigger.addEventListener('click', function (event) {
      event.stopPropagation();
      if (panel.classList.contains('is-open')) close();
      else open();
    });

    document.addEventListener('click', function (event) {
      if (!panel.classList.contains('is-open')) return;
      if (!panel.contains(event.target) && event.target !== trigger) close();
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') close();
    });

    if (backdrop) backdrop.addEventListener('click', close);
    panel.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', close);
    });
  }

  function initScrollEffects() {
    var header = $('site-header');
    var links = Array.prototype.slice.call(document.querySelectorAll('.nav__link'));
    var sections = links
      .map(function (link) {
        var id = link.getAttribute('href');
        return id && id.length > 1 ? document.querySelector(id) : null;
      })
      .filter(Boolean);

    function onScroll() {
      if (header) header.classList.toggle('is-scrolled', window.scrollY > 8);

      var offset = window.scrollY + 120;
      var currentIndex = -1;
      sections.forEach(function (section, index) {
        if (section.offsetTop <= offset) currentIndex = index;
      });
      links.forEach(function (link, index) {
        link.classList.toggle('is-active', index === currentIndex);
      });
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  function initReveal() {
    var items = document.querySelectorAll('[data-reveal]');
    if (!items.length) return;

    if (!('IntersectionObserver' in window)) {
      items.forEach(function (el) {
        el.classList.add('is-visible');
      });
      return;
    }

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { rootMargin: '0px 0px -40px 0px', threshold: 0.06 }
    );

    items.forEach(function (el) {
      observer.observe(el);
    });
  }

  /* --------------------------------------------------------------------- */
  /* Apresentacao                                                           */
  /* --------------------------------------------------------------------- */

  function renderHero(data) {
    var content = data.content || {};
    var settings = data.settings || {};

    setText('hero-badge', content['hero.badge']);
    setText('hero-title', content['hero.title'] || settings.company_name || 'Panificadora Frank');
    setText('hero-subtitle', content['hero.subtitle']);

    var primary = $('hero-button-primary');
    if (primary && content['hero.button_primary']) primary.textContent = content['hero.button_primary'];

    var secondaryLabel = $('hero-button-secondary-label');
    if (secondaryLabel && content['hero.button_secondary']) {
      secondaryLabel.textContent = content['hero.button_secondary'];
    }

    // Imagem de destaque: prioridade para o texto editavel, depois configuracao geral.
    var heroImage = content['hero.image'] || settings.logo_image || '/assets/img/hero-panificadora.jpg';
    setImage('hero-image', heroImage);

    // Endereco resumido
    var address = [settings.address_line, settings.address_city].filter(Boolean).join(' - ');
    var addressWrap = $('hero-address');
    if (addressWrap && address) {
      setText('hero-address-text', address);
      addressWrap.hidden = false;
    }

    // Selo de status no destaque
    var openNow = Boolean(data.store && data.store.open_now);
    var badgeText = $('hero-badge-media-text');
    if (badgeText) {
      badgeText.textContent = openNow
        ? 'Aberto agora'
        : data.store && data.store.today && data.store.today.closed
          ? 'Fechado hoje'
          : 'Abre em breve';
    }
    var badgeDot = document.querySelector('#hero-badge-media .status-dot');
    if (badgeDot) {
      badgeDot.classList.remove('status-dot--on', 'status-dot--off');
      badgeDot.classList.add(openNow ? 'status-dot--on' : 'status-dot--off');
    }

    // Status textual acima dos botoes
    var text = $('hero-status-text');
    var dot = $('hero-status-dot');
    if (text) {
      if (openNow && data.store && data.store.today) {
        text.textContent = 'Aberto agora - ' + formatTimeRange(data.store.today);
      } else if (data.store && data.store.today && data.store.today.closed) {
        text.textContent = 'Fechado hoje';
      } else if (data.store && data.store.today) {
        text.textContent = 'Abre as ' + (data.store.today.open || '');
      } else {
        text.textContent = 'Consulte os horarios de atendimento';
      }
    }
    if (dot) {
      dot.classList.remove('status-dot--on', 'status-dot--off');
      dot.classList.add(openNow ? 'status-dot--on' : 'status-dot--off');
    }
  }

  /* --------------------------------------------------------------------- */
  /* Sobre                                                                  */
  /* --------------------------------------------------------------------- */

  function renderAbout(data) {
    var content = data.content || {};
    var settings = data.settings || {};

    setText('about-title', content['about.title'] || 'Sobre a ' + (settings.company_name || 'Panificadora Frank'));
    setText('about-subtitle', content['about.subtitle']);

    var body = $('about-body');
    if (body) body.innerHTML = paragraphs(content['about.body']);

    setImage('about-image', content['about.image'] || '/assets/img/sobre-panificadora.jpg');

    // Fatos: quantidade de produtos disponiveis + horario de hoje + tempo de forno
    var facts = $('about-facts');
    if (facts) {
      var available = (data.products || []).length;
      var today = data.store && data.store.today;
      var items = [
        { value: String(available), label: available === 1 ? 'produto disponivel agora' : 'produtos disponiveis agora' },
      ];
      if (today) {
        items.push({
          value: today.closed ? 'Fechado' : today.open || '-',
          label: today.closed ? 'hoje' : 'abertura hoje',
        });
      }
      items.push({ value: 'Forno', label: 'producao diaria propria' });
      facts.innerHTML = items
        .map(function (item) {
          return (
            '<div class="fact"><span class="fact__value">' +
            escapeHtml(item.value) +
            '</span><span class="fact__label">' +
            escapeHtml(item.label) +
            '</span></div>'
          );
        })
        .join('');
    }
  }

  /* --------------------------------------------------------------------- */
  /* Produtos                                                               */
  /* --------------------------------------------------------------------- */

  function productCard(product) {
    var availability = product.availability || { available: false };
    var isAvailable = Boolean(availability.available);
    var priceHtml = product.price_formatted
      ? '<span class="product-card__price">' + escapeHtml(product.price_formatted) + '</span>'
      : '<span class="product-card__price" style="font-size:.95rem">Consulte</span>';

    if (product.price_note) {
      priceHtml += '<span class="product-card__note">' + escapeHtml(product.price_note) + '</span>';
    }

    var media = product.image
      ? '<img src="' + escapeHtml(product.image) + '" alt="' + escapeHtml(product.name) + '" loading="lazy" onerror="this.parentNode.innerHTML=\'<div class=&quot;product-card__placeholder&quot;><svg width=&quot;42&quot; height=&quot;42&quot; viewBox=&quot;0 0 24 24&quot; fill=&quot;none&quot; stroke=&quot;currentColor&quot; stroke-width=&quot;1.6&quot;><path d=&quot;M3 10h18M5 6h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z&quot;/></svg></div>\'" />'
      : '<div class="product-card__placeholder"><svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M3 10h18M5 6h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z"/></svg></div>';

    var badge = isAvailable
      ? '<span class="product-badge product-badge--on"><span class="status-dot status-dot--on"></span>Disponivel</span>'
      : '<span class="product-badge product-badge--off"><span class="status-dot status-dot--off"></span>Nao disponivel</span>';

    var until = '';
    if (product.available_until) {
      until = isAvailable
        ? '<span class="product-card__until">Disponivel ate as ' + escapeHtml(product.available_until) + '</span>'
        : '<span class="product-card__until product-card__until--off">' + escapeHtml(availability.detail || 'Fora do horario') + '</span>';
    } else if (!isAvailable && availability.detail) {
      until = '<span class="product-card__until product-card__until--off">' + escapeHtml(availability.detail) + '</span>';
    }

    var waButton = '';
    if (isAvailable && state.whatsapp) {
      var msg = 'Ola! Gostaria de encomendar: ' + product.name + '.';
      waButton =
        '<a class="btn btn--whatsapp btn--sm" href="' +
        escapeHtml(whatsappLink(state.whatsapp, msg)) +
        '" target="_blank" rel="noopener" aria-label="Pedir ' +
        escapeHtml(product.name) +
        ' no WhatsApp">Pedir</a>';
    }

    return (
      '<article class="product-card' +
      (isAvailable ? '' : ' product-card--off') +
      '" data-product-id="' +
      escapeHtml(product.id) +
      '">' +
      '<div class="product-card__media">' +
      media +
      badge +
      (product.highlight ? '<span class="product-card__flag">Destaque</span>' : '') +
      '</div>' +
      '<div class="product-card__body">' +
      '<h3 class="product-card__title">' +
      escapeHtml(product.name) +
      '</h3>' +
      '<p class="product-card__desc">' +
      escapeHtml(product.description) +
      '</p>' +
      '<div class="product-card__footer">' +
      '<div>' +
      priceHtml +
      '</div>' +
      waButton +
      '</div>' +
      until +
      '</div>' +
      '</article>'
    );
  }

  function renderProducts(data) {
    var grid = $('products-grid');
    var empty = $('products-empty');
    var loading = $('products-loading');
    var count = $('products-count');
    if (!grid) return;

    if (loading) loading.hidden = true;

    var all = data.all_products || [];
    var available = data.products || [];
    var list = state.filter === 'available' ? available : all;

    if (!list.length) {
      grid.hidden = true;
      grid.innerHTML = '';
      if (empty) {
        empty.hidden = false;
        var emptyText = $('products-empty-text');
        if (emptyText) {
          emptyText.textContent =
            state.filter === 'available'
              ? 'Nenhum produto disponivel neste momento. Toque em "Ver todos" para conferir o catalogo completo.'
              : 'Nenhum produto cadastrado ainda. Cadastre no Painel ADM.';
        }
      }
      if (count) count.textContent = '';
      return;
    }

    grid.innerHTML = list.map(productCard).join('');
    grid.hidden = false;
    if (empty) empty.hidden = true;
    if (count) {
      count.textContent =
        state.filter === 'available'
          ? available.length + ' disponivel(is) agora de ' + all.length + ' no catalogo'
          : all.length + ' produto(s) no catalogo';
    }
  }

  function initFilters() {
    var wrap = $('products-filters');
    if (!wrap) return;
    wrap.addEventListener('click', function (event) {
      var button = event.target.closest('[data-filter]');
      if (!button) return;
      state.filter = button.getAttribute('data-filter');
      wrap.querySelectorAll('.chip').forEach(function (chip) {
        chip.classList.toggle('is-active', chip === button);
      });
      renderProducts(state.data || {});
    });
  }

  /* --------------------------------------------------------------------- */
  /* Quadros / secoes dinamicas                                             */
  /* --------------------------------------------------------------------- */

  function renderSections(data) {
    var wrap = $('dynamic-sections');
    if (!wrap) return;

    var sections = data.sections || [];
    if (!sections.length) {
      wrap.innerHTML = '';
      return;
    }

    wrap.innerHTML = sections
      .map(function (section) {
        var layoutClass =
          section.layout === 'image-left'
            ? ' section-block--left'
            : section.layout === 'image-top'
              ? ' section-block--top'
              : section.layout === 'no-image'
                ? ' section-block--no-image'
                : '';
        var bgClass = section.background === 'dark' ? ' section--dark' : section.background === 'tint' ? ' section--tint' : '';

        var media = '';
        if (section.image && section.layout !== 'no-image') {
          media =
            '<figure class="section-block__media" style="margin:0"><img src="' +
            escapeHtml(section.image) +
            '" alt="' +
            escapeHtml(section.title) +
            '" loading="lazy" /></figure>';
        }

        var button = '';
        if (section.button_label && section.button_url) {
          var cls =
            section.button_style === 'whatsapp'
              ? 'btn--whatsapp'
              : section.button_style === 'secondary'
                ? 'btn--secondary'
                : 'btn--primary';
          var external = /^https?:\/\//i.test(section.button_url);
          button =
            '<div class="btn-row" style="margin-top:18px"><a class="btn ' +
            cls +
            '" href="' +
            escapeHtml(section.button_url) +
            '"' +
            (external ? ' target="_blank" rel="noopener"' : '') +
            '>' +
            escapeHtml(section.button_label) +
            '</a></div>';
        }

        var related = '';
        if (section.products && section.products.length) {
          related =
            '<div class="section-block__products">' +
            section.products
              .map(function (p) {
                return (
                  '<span class="section-block__product-pill"><span class="status-dot ' +
                  (p.availability && p.availability.available ? 'status-dot--on' : 'status-dot--off') +
                  '"></span>' +
                  escapeHtml(p.name) +
                  (p.price_formatted ? ' - ' + escapeHtml(p.price_formatted) : '') +
                  '</span>'
                );
              })
              .join('') +
            '</div>';
        }

        return (
          '<section class="section' +
          bgClass +
          '" id="secao-' +
          escapeHtml(section.id) +
          '">' +
          '<div class="container">' +
          '<div class="section-block' +
          layoutClass +
          '">' +
          '<div class="section-block__grid">' +
          media +
          '<div class="section-block__body" data-reveal>' +
          (section.subtitle ? '<span class="eyebrow">' + escapeHtml(section.subtitle) + '</span>' : '') +
          '<h2>' +
          escapeHtml(section.title) +
          '</h2>' +
          paragraphs(section.body) +
          button +
          related +
          '</div>' +
          '</div>' +
          '</div>' +
          '</div>' +
          '</section>'
        );
      })
      .join('');
  }

  /* --------------------------------------------------------------------- */
  /* Contato / horarios                                                     */
  /* --------------------------------------------------------------------- */

  function iconSvg(name) {
    var icons = {
      whatsapp:
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.47 14.38c-.3-.15-1.77-.87-2.04-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.17.2-.35.22-.65.07-.3-.15-1.27-.47-2.42-1.49-.9-.8-1.5-1.79-1.67-2.09-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.49s1.07 2.89 1.22 3.09c.15.2 2.1 3.21 5.08 4.5.71.31 1.26.49 1.69.63.71.23 1.36.2 1.87.12.57-.09 1.77-.72 2.02-1.42.25-.7.25-1.29.17-1.42-.07-.13-.27-.2-.57-.35M12.04 21.5h-.01a9.4 9.4 0 0 1-4.79-1.31l-.34-.2-3.56.93.95-3.47-.22-.36a9.38 9.38 0 0 1-1.44-5.01c0-5.19 4.23-9.41 9.42-9.41 2.51 0 4.88.98 6.66 2.76a9.34 9.34 0 0 1 2.76 6.66c0 5.19-4.23 9.41-9.43 9.41m8.02-17.43A11.36 11.36 0 0 0 12.04.76C5.78.76.69 5.85.69 12.1c0 2 .52 3.95 1.51 5.67L.6 23.48l5.85-1.53a11.3 11.3 0 0 0 5.59 1.43h.01c6.25 0 11.34-5.09 11.35-11.34 0-3.03-1.18-5.88-3.33-8.02"/></svg>',
      phone:
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>',
      instagram:
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>',
      pin:
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
      clock:
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
      mail:
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>',
      maps:
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 20l-6 2V6l6-2 6 2 6-2v16l-6 2-6-2z"/><path d="M9 4v16M15 6v16"/></svg>',
      facebook:
        '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M14 9h3V6h-3c-2.2 0-4 1.8-4 4v2H8v3h2v8h3v-8h3l1-3h-4v-2c0-.6.4-1 1-1z"/></svg>',
      tiktok:
        '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M16 3h-3v12.5a2.5 2.5 0 1 1-2.5-2.5c.2 0 .3 0 .5.1V10a5.5 5.5 0 1 0 5 5.5V8.8c1 .8 2.2 1.2 3.5 1.3V7.1A4.1 4.1 0 0 1 16 3z"/></svg>',
      admin:
        '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
    };
    return icons[name] || '';
  }

  function contactCard(opts) {
    var tag = opts.href ? 'a' : 'div';
    var attrs = opts.href
      ? ' href="' + escapeHtml(opts.href) + '"' + (opts.external ? ' target="_blank" rel="noopener"' : '')
      : '';
    return (
      '<' +
      tag +
      ' class="contact-card' +
      (opts.red ? ' contact-card--red' : '') +
      '"' +
      attrs +
      '>' +
      '<span class="contact-card__icon">' +
      iconSvg(opts.icon) +
      '</span>' +
      '<span>' +
      '<span class="contact-card__label">' +
      escapeHtml(opts.label) +
      '</span>' +
      '<span class="contact-card__value">' +
      escapeHtml(opts.value) +
      '</span>' +
      (opts.hint ? '<span class="contact-card__hint">' + escapeHtml(opts.hint) + '</span>' : '') +
      '</span>' +
      '</' +
      tag +
      '>'
    );
  }

  function renderContact(data) {
    var settings = data.settings || {};
    var grid = $('contact-grid');
    if (!grid) return;

    setText('contact-title', (data.content || {})['contact.title'] || 'Fale com a gente');
    setText('contact-subtitle', (data.content || {})['contact.subtitle'] || '');

    var cards = [];

    if (settings.phone) {
      cards.push({
        icon: 'phone',
        label: 'Telefone',
        value: settings.phone,
        hint: 'Ligue para encomendar',
        href: telLink(settings.phone),
      });
    }

    if (state.whatsapp) {
      cards.push({
        icon: 'whatsapp',
        label: 'WhatsApp',
        value: settings.whatsapp || settings.phone,
        hint: 'Toque para abrir a conversa',
        href: whatsappLink(state.whatsapp, state.whatsappMessage),
        external: true,
      });
    }

    var ig = instagramLink(settings.instagram);
    if (ig) {
      cards.push({
        icon: 'instagram',
        label: 'Instagram',
        value: settings.instagram,
        hint: 'Acompanhe as novidades',
        href: ig,
        external: true,
        red: true,
      });
    }

    if (settings.email) {
      cards.push({
        icon: 'mail',
        label: 'E-mail',
        value: settings.email,
        hint: 'Envie sua mensagem',
        href: 'mailto:' + settings.email,
      });
    }

    var address = [settings.address_line, settings.address_city].filter(Boolean).join(' - ');
    if (address) {
      cards.push({
        icon: 'pin',
        label: 'Endereco',
        value: address,
        hint: settings.google_maps_url ? 'Toque para abrir no Google Maps' : '',
        href: settings.google_maps_url || '',
        external: true,
      });
    }

    grid.innerHTML = cards.length
      ? cards.map(contactCard).join('')
      : '<div class="empty-state" style="grid-column:1/-1"><p>Os contatos ainda nao foram configurados. Preencha em Painel ADM &gt; Configuracoes.</p></div>';

    renderHours(data);
  }

  function renderHours(data) {
    var wrap = $('contact-hours');
    if (!wrap) return;

    var hours = data.hours || [];
    if (!hours.length) {
      wrap.innerHTML = '';
      return;
    }

    var todayKey = data.store && data.store.now ? data.store.now.weekday : '';

    var rows = hours
      .map(function (h) {
        var isToday = h.day === todayKey;
        var label = h.label || WEEKDAY_LABELS[h.day] || h.day;
        var value = h.closed
          ? '<span class="hours__closed">Fechado</span>'
          : escapeHtml(formatTimeRange(h));
        return (
          '<li class="hours__row' +
          (isToday ? ' is-today' : '') +
          '"><span class="hours__day">' +
          escapeHtml(label) +
          (isToday ? ' (hoje)' : '') +
          '</span><span class="hours__time">' +
          value +
          '</span></li>'
        );
      })
      .join('');

    var openNow = Boolean(data.store && data.store.open_now);
    wrap.innerHTML =
      '<div class="hours"><div class="hours__head">' +
      '<h3 class="hours__title" style="display:flex;align-items:center;gap:9px">' +
      iconSvg('clock') +
      'Horario de atendimento</h3>' +
      '<span class="status-dot ' +
      (openNow ? 'status-dot--on' : 'status-dot--off') +
      '"></span></div><ul class="hours__list">' +
      rows +
      '</ul></div>';
  }

  /* --------------------------------------------------------------------- */
  /* Localizacao                                                            */
  /* --------------------------------------------------------------------- */

  function renderLocation(data) {
    var settings = data.settings || {};
    setText('location-title', (data.content || {})['location.title'] || 'Onde estamos');
    setText('location-subtitle', (data.content || {})['location.subtitle'] || '');

    var frame = $('map-frame');
    var card = $('address-card');
    var address = [settings.address_line, settings.address_city].filter(Boolean).join(', ');
    var embed = settings.google_maps_embed || '';
    var mapsUrl = settings.google_maps_url || '';

    if (frame) {
      if (embed && /^https:\/\//i.test(embed)) {
        frame.innerHTML =
          '<iframe src="' +
          escapeHtml(embed) +
          '" title="Mapa da ' +
          escapeHtml(settings.company_name || 'Panificadora Frank') +
          '" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>';
      } else if (mapsUrl) {
        frame.innerHTML =
          '<div class="map-placeholder">' +
          '<div>' +
          pinIconLarge() +
          '<p style="margin:10px 0 0">' +
          escapeHtml(address || 'Veja a localizacao no Google Maps') +
          '</p>' +
          '<a class="btn btn--primary btn--sm" href="' +
          escapeHtml(mapsUrl) +
          '" target="_blank" rel="noopener" style="margin-top:14px">Abrir no Google Maps</a>' +
          '</div></div>';
      } else {
        frame.innerHTML =
          '<div class="map-placeholder">' +
          '<div>' +
          pinIconLarge() +
          '<p style="margin:10px 0 0">O mapa sera exibido quando o endereco e o link do Google Maps forem configurados no Painel ADM.</p>' +
          '</div></div>';
      }
    }

    if (card) {
      var parts = [];
      parts.push('<h3 style="margin-bottom:10px">' + escapeHtml(settings.company_name || 'Panificadora Frank') + '</h3>');
      if (settings.address_line) parts.push('<p class="address-card__line">' + escapeHtml(settings.address_line) + '</p>');
      if (settings.address_city) parts.push('<p class="address-card__city">' + escapeHtml(settings.address_city) + '</p>');
      if (settings.address_notes) parts.push('<p style="color:var(--muted);font-size:.92rem">' + escapeHtml(settings.address_notes) + '</p>');

      var buttons = [];
      if (mapsUrl) {
        buttons.push(
          '<a class="btn btn--primary btn--sm" href="' +
            escapeHtml(mapsUrl) +
            '" target="_blank" rel="noopener">' +
            iconSvg('maps') +
            ' Abrir no Google Maps</a>'
        );
      }
      if (state.whatsapp) {
        buttons.push(
          '<a class="btn btn--whatsapp btn--sm" href="' +
            escapeHtml(whatsappLink(state.whatsapp, 'Ola! Gostaria de informacoes sobre a Panificadora Frank.')) +
            '" target="_blank" rel="noopener">' +
            iconSvg('whatsapp') +
            ' Chamar no WhatsApp</a>'
        );
      }
      if (buttons.length) {
        parts.push('<div class="btn-row" style="margin-top:16px">' + buttons.join('') + '</div>');
      }
      card.innerHTML = parts.join('');
    }
  }

  function pinIconLarge() {
    return '<svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true" style="color:var(--brand-red)"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>';
  }

  /* --------------------------------------------------------------------- */
  /* Rodape                                                                 */
  /* --------------------------------------------------------------------- */

  function renderFooter(data) {
    var settings = data.settings || {};
    var content = data.content || {};

    setText('footer-about', content['footer.about'] || '');
    setText('footer-rights', '© ' + new Date().getFullYear() + ' ' + (settings.company_name || 'Panificadora Frank') + '. ' + (content['footer.rights'] || ''));

    var contacts = $('footer-contacts');
    if (contacts) {
      var items = [];
      if (settings.phone) {
        items.push(
          '<li><a href="' + escapeHtml(telLink(settings.phone)) + '">' + iconSvg('phone') + escapeHtml(settings.phone) + '</a></li>'
        );
      }
      if (state.whatsapp) {
        items.push(
          '<li><a href="' +
            escapeHtml(whatsappLink(state.whatsapp, state.whatsappMessage)) +
            '" target="_blank" rel="noopener">' +
            iconSvg('whatsapp') +
            'WhatsApp</a></li>'
        );
      }
      if (settings.email) {
        items.push(
          '<li><a href="mailto:' +
            escapeHtml(settings.email) +
            '">' +
            iconSvg('mail') +
            escapeHtml(settings.email) +
            '</a></li>'
        );
      }
      var address = [settings.address_line, settings.address_city].filter(Boolean).join(', ');
      if (address) {
        var addressHtml = iconSvg('pin') + escapeHtml(address);
        items.push(
          '<li>' +
            (settings.google_maps_url
              ? '<a href="' + escapeHtml(settings.google_maps_url) + '" target="_blank" rel="noopener">' + addressHtml + '</a>'
              : addressHtml) +
            '</li>'
        );
      }
      var ig = instagramLink(settings.instagram);
      if (ig) {
        items.push(
          '<li><a href="' + escapeHtml(ig) + '" target="_blank" rel="noopener">' + iconSvg('instagram') + escapeHtml(settings.instagram) + '</a></li>'
        );
      }
      contacts.innerHTML = items.length
        ? items.join('')
        : '<li style="color:#a89486">Contatos ainda nao configurados.</li>';
    }

    var socials = $('footer-socials');
    if (socials) {
      var links = [];
      if (state.whatsapp) {
        links.push(
          '<a class="social-btn" href="' + escapeHtml(whatsappLink(state.whatsapp, state.whatsappMessage)) + '" target="_blank" rel="noopener" aria-label="WhatsApp">' + iconSvg('whatsapp') + '</a>'
        );
      }
      var igLink = instagramLink(settings.instagram);
      if (igLink) {
        links.push('<a class="social-btn" href="' + escapeHtml(igLink) + '" target="_blank" rel="noopener" aria-label="Instagram">' + iconSvg('instagram') + '</a>');
      }
      if (settings.facebook) {
        var fb = /^https?:\/\//i.test(settings.facebook) ? settings.facebook : 'https://facebook.com/' + settings.facebook.replace(/^@/, '');
        links.push('<a class="social-btn" href="' + escapeHtml(fb) + '" target="_blank" rel="noopener" aria-label="Facebook">' + iconSvg('facebook') + '</a>');
      }
      if (settings.tiktok) {
        var tt = /^https?:\/\//i.test(settings.tiktok) ? settings.tiktok : 'https://tiktok.com/@' + settings.tiktok.replace(/^@/, '');
        links.push('<a class="social-btn" href="' + escapeHtml(tt) + '" target="_blank" rel="noopener" aria-label="TikTok">' + iconSvg('tiktok') + '</a>');
      }
      links.push('<a class="social-btn" href="/admin/" aria-label="Painel ADM">' + iconSvg('admin') + '</a>');
      socials.innerHTML = links.join('');
    }
  }

  /* --------------------------------------------------------------------- */
  /* Carregamento                                                           */
  /* --------------------------------------------------------------------- */

  function showFatalError(message) {
    var loading = $('products-loading');
    if (loading) loading.hidden = true;
    var grid = $('products-grid');
    if (grid) grid.hidden = true;
    var empty = $('products-empty');
    if (empty) empty.hidden = true;
    var alertBox = $('products-alert');
    if (alertBox) {
      alertBox.innerHTML =
        '<div class="alert alert--error"><span>Nao foi possivel carregar os produtos: ' +
        escapeHtml(message) +
        '. <button type="button" id="retry-load" style="border:0;background:none;color:inherit;text-decoration:underline;font-weight:700;padding:0">Tentar novamente</button></span></div>';
      var retry = $('retry-load');
      if (retry) retry.addEventListener('click', load);
    }
  }

  function render(data) {
    state.data = data;
    initHeader(data);
    renderHero(data);
    renderAbout(data);
    renderProducts(data);
    renderSections(data);
    renderContact(data);
    renderLocation(data);
    renderFooter(data);
    initReveal();
  }

  function load() {
    var alertBox = $('products-alert');
    if (alertBox) alertBox.innerHTML = '';

    fetch('/api/site', { headers: { accept: 'application/json' } })
      .then(function (response) {
        if (!response.ok) throw new Error('HTTP ' + response.status);
        return response.json();
      })
      .then(function (data) {
        render(data);
      })
      .catch(function (error) {
        showFatalError(error.message || 'erro desconhecido');
      });
  }

  function init() {
    initMenu();
    initScrollEffects();
    initFilters();
    load();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();