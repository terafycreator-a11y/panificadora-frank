-- Migracao inicial (equivalente a schema.sql).
-- Aplicar com:
--   npx wrangler d1 migrations apply panificadora-frank-db --remote
-- ou diretamente:
--   npx wrangler d1 execute panificadora-frank-db --remote --file=./schema.sql
CREATE TABLE IF NOT EXISTS app_meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
INSERT INTO app_meta (key, value) VALUES ('schema_version', '1')
  ON CONFLICT(key) DO UPDATE SET value = excluded.value;

CREATE TABLE IF NOT EXISTS admins (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  email                TEXT    NOT NULL UNIQUE,
  name                 TEXT    NOT NULL DEFAULT 'Administrador',
  password_hash        TEXT    NOT NULL,
  role                 TEXT    NOT NULL DEFAULT 'admin',
  active               INTEGER NOT NULL DEFAULT 1,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  last_login_at        TEXT,
  created_at           TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at           TEXT    NOT NULL DEFAULT (datetime('now')),
  CHECK (role IN ('admin', 'editor'))
);
CREATE INDEX IF NOT EXISTS idx_admins_email ON admins(email);

CREATE TABLE IF NOT EXISTS sessions (
  id           TEXT    PRIMARY KEY,
  admin_id     INTEGER NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  token_hash   TEXT    NOT NULL UNIQUE,
  ip           TEXT,
  user_agent   TEXT,
  created_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  last_seen_at TEXT    NOT NULL DEFAULT (datetime('now')),
  expires_at   TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_admin   ON sessions(admin_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_sessions_token   ON sessions(token_hash);

CREATE TABLE IF NOT EXISTS media (
  id          TEXT    PRIMARY KEY,
  filename    TEXT    NOT NULL,
  mime_type   TEXT    NOT NULL,
  size        INTEGER NOT NULL,
  width       INTEGER,
  height      INTEGER,
  alt         TEXT    NOT NULL DEFAULT '',
  data        BLOB    NOT NULL,
  uploaded_by INTEGER REFERENCES admins(id) ON DELETE SET NULL,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_media_created ON media(created_at);

CREATE TABLE IF NOT EXISTS sections (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  title        TEXT    NOT NULL,
  subtitle     TEXT    NOT NULL DEFAULT '',
  body         TEXT    NOT NULL DEFAULT '',
  image        TEXT    NOT NULL DEFAULT '',
  button_label TEXT    NOT NULL DEFAULT '',
  button_url   TEXT    NOT NULL DEFAULT '',
  button_style TEXT    NOT NULL DEFAULT 'primary',
  layout       TEXT    NOT NULL DEFAULT 'image-right',
  background   TEXT    NOT NULL DEFAULT 'light',
  active       INTEGER NOT NULL DEFAULT 1,
  sort_order   INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at   TEXT    NOT NULL DEFAULT (datetime('now')),
  CHECK (layout     IN ('image-right', 'image-left', 'image-top', 'no-image')),
  CHECK (background IN ('light', 'tint', 'dark')),
  CHECK (button_style IN ('primary', 'secondary', 'whatsapp'))
);
CREATE INDEX IF NOT EXISTS idx_sections_order ON sections(sort_order, id);

CREATE TABLE IF NOT EXISTS products (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT    NOT NULL,
  description     TEXT    NOT NULL DEFAULT '',
  price           REAL,
  price_note      TEXT    NOT NULL DEFAULT '',
  image           TEXT    NOT NULL DEFAULT '',
  status          TEXT    NOT NULL DEFAULT 'available',
  available_until TEXT,
  active          INTEGER NOT NULL DEFAULT 1,
  highlight       INTEGER NOT NULL DEFAULT 0,
  sort_order      INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at      TEXT    NOT NULL DEFAULT (datetime('now')),
  CHECK (status IN ('available', 'unavailable', 'auto'))
);
CREATE INDEX IF NOT EXISTS idx_products_order  ON products(sort_order, id);
CREATE INDEX IF NOT EXISTS idx_products_active ON products(active);

CREATE TABLE IF NOT EXISTS section_products (
  section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (section_id, product_id)
);
CREATE INDEX IF NOT EXISTS idx_section_products_section ON section_products(section_id);

CREATE TABLE IF NOT EXISTS content_blocks (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS login_attempts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  email      TEXT    NOT NULL DEFAULT '',
  ip         TEXT    NOT NULL DEFAULT '',
  success    INTEGER NOT NULL DEFAULT 0,
  created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_login_attempts_lookup ON login_attempts(email, ip, created_at);