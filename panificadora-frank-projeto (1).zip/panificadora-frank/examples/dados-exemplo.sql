-- =============================================================================
-- OPCIONAL: dados de exemplo para testar o Painel ADM rapidamente
-- =============================================================================
-- Este conteudo e apenas um PONTO DE PARTIDA para testes.
-- Ele NAO e aplicado automaticamente em producao.
-- Depois de aplicar, voce pode editar ou excluir tudo pelo proprio Painel ADM.
--
-- Aplicar em producao:
--   npx wrangler d1 execute panificadora-frank-db --remote --file=./examples/dados-exemplo.sql
-- Aplicar localmente:
--   npx wrangler d1 execute panificadora-frank-db --local --file=./examples/dados-exemplo.sql
-- =============================================================================

-- Preencha os dados reais da Panificadora Frank:
UPDATE settings SET value = '(00) 0000-0000'          WHERE key = 'phone';
UPDATE settings SET value = '5511999999999'           WHERE key = 'whatsapp';
UPDATE settings SET value = '@panificadorafrank'      WHERE key = 'instagram';
UPDATE settings SET value = 'Rua Exemplo, 100'        WHERE key = 'address_line';
UPDATE settings SET value = 'Sua Cidade - SP, 00000-000' WHERE key = 'address_city';
UPDATE settings SET value = 'https://maps.google.com/?q=panificadora' WHERE key = 'google_maps_url';

-- Produtos de exemplo com as imagens que ja vêm no projeto:
INSERT INTO products (name, description, price, price_note, image, status, available_until, active, highlight, sort_order)
VALUES
  ('Pao frances',        'Assado varias vezes ao dia. Casca crocante e miolo macio, quentinho a toda hora.', 0.90, 'por unidade', '/assets/img/produto-pao-frances.jpg',   'available',   NULL,     1, 1, 10),
  ('Bolo de cenoura',    'Bolo caseiro de cenoura com cobertura de chocolate. Fatias e bolo inteiro por encomenda.', 18.00, 'o quilo', '/assets/img/produto-bolo-cenoura.jpg',  'available',   NULL,     1, 1, 20),
  ('Salgados assados',   'Coxinha, pao de queijo e pastel assado, saindo do forno no meio da tarde.', 7.50, 'a porcao',  '/assets/img/produto-salgado-assado.jpg','auto',        '17:30',  1, 0, 30),
  ('Pao de queijo',      'Feito com queijo minas e polvilho. Vendido quentinho, por unidade ou por bandeja.', 3.50, 'por unidade', '/assets/img/produto-salgado-assado.jpg','available', NULL,     1, 0, 40);

-- Quadros/secoes de exemplo (podem ser editados ou excluidos no Painel ADM):
INSERT INTO sections (title, subtitle, body, image, button_label, button_url, button_style, layout, background, active, sort_order)
VALUES
  ('Encomendas para festas',
   'Bolos, tortas e salgados',
   'Fazemos bolos, tortas e bandejas de salgados para aniversarios, batizados e confraternizacoes.

Encomende com antecedencia pelo WhatsApp e combinamos a retirada ou entrega.',
   '/assets/img/produto-bolo-cenoura.jpg',
   'Falar no WhatsApp', '/#contato', 'whatsapp', 'image-left', 'tint', 1, 10),
  ('Forno quente o dia inteiro',
   'Fabricacao propria',
   'Nossa producao comeca de madrugada.

Sao varias fornadas ao longo do dia para que o pao chegue sempre quentinho na sua mesa.',
   '/assets/img/sobre-panificadora.jpg',
   'Ver os produtos', '/#produtos', 'primary', 'image-right', 'light', 1, 20);

-- Relaciona produtos aos quadros:
INSERT OR IGNORE INTO section_products (section_id, product_id, sort_order)
SELECT s.id, p.id, 10 FROM sections s, products p WHERE s.title = 'Encomendas para festas' AND p.name = 'Bolo de cenoura';
INSERT OR IGNORE INTO section_products (section_id, product_id, sort_order)
SELECT s.id, p.id, 20 FROM sections s, products p WHERE s.title = 'Encomendas para festas' AND p.name = 'Salgados assados';
INSERT OR IGNORE INTO section_products (section_id, product_id, sort_order)
SELECT s.id, p.id, 10 FROM sections s, products p WHERE s.title = 'Forno quente o dia inteiro' AND p.name = 'Pao frances';
INSERT OR IGNORE INTO section_products (section_id, product_id, sort_order)
SELECT s.id, p.id, 20 FROM sections s, products p WHERE s.title = 'Forno quente o dia inteiro' AND p.name = 'Pao de queijo';