# Panificadora Frank — Site + Painel ADM

Projeto completo (site público + Painel ADM + backend + banco de dados) preparado para
rodar na **Cloudflare**, usando apenas **Cloudflare Workers + D1** — sem R2, sem
dependências externas e sem etapa de build.

| Área | Endereço |
| --- | --- |
| Site público | `/` |
| Painel ADM | `/admin/` |
| API | `/api/*` |
| Diagnóstico | `/api/health` |

---

## 1. Como o projeto é organizado

```
panificadora-frank/
├── src/                        # Worker (backend + API)
│   ├── index.js                # Entrada do Worker: roteador da API
│   ├── lib/
│   │   ├── auth.js             # Login, sessões, hash de senha, rate limit
│   │   └── util.js             # Utilidades (JSON, validação, cookies, datas)
│   └── routes/
│       ├── public.js           # Rotas públicas (/api/site, /api/media/:id...)
│       └── admin.js            # Rotas administrativas (produtos, seções, mídia...)
├── public/                     # Arquivos estáticos servidos pelo Worker
│   ├── index.html              # Site público
│   ├── assets/css/styles.css   # Estilo do site (mobile-first)
│   ├── assets/js/site.js       # Consome a API e monta a página
│   ├── assets/img/             # Imagens do projeto (hero, produtos, favicon)
│   └── admin/
│       ├── index.html          # Painel ADM (SPA em JS puro)
│       └── assets/admin.css|admin.js
├── schema.sql                  # Banco completo + valores padrão (idempotente)
├── migrations/0001_init.sql    # Migração inicial (para `wrangler d1 migrations`)
├── examples/dados-exemplo.sql  # Dados de exemplo OPCIONAIS (para testar)
├── scripts/
│   ├── create-admin.mjs        # Cria/redefine administrador (hash PBKDF2)
│   ├── e2e-test.mjs            # Testes ponta a ponta da API (128 verificações)
│   ├── check-project.mjs       # Verificação de arquivos/rotas/imports
│   ├── capture-screenshots.mjs # Capturas em celular/tablet/desktop
│   └── optimize-images.py      # Otimiza as imagens de design do site
├── wrangler.toml               # Configuração do Worker (Cloudflare)
└── package.json                # Scripts de apoio (wrangler como devDependency)
```

**Tecnologias:** JavaScript puro (ES Modules) no Worker e no navegador, HTML/CSS sem
frameworks, Cloudflare D1 (SQLite) como banco. Nenhuma etapa de build é necessária.

---

## 2. Rodar localmente

Pré-requisitos: Node.js 18+ (recomendado 20+).

```bash
npm install                                  # instala o wrangler
npm run db:local                             # cria as tabelas no banco local
npm run dev                                  # sobe em http://127.0.0.1:8787
```

Abra `http://127.0.0.1:8787/` (site) e `http://127.0.0.1:8787/admin/` (Painel ADM).

Na primeira vez, o Painel ADM mostra o **assistente de configuração**: crie o primeiro
administrador (nome, e-mail e senha). Depois desse primeiro cadastro, o assistente
desaparece sozinho e passa a valer somente o login normal.

**Dados de exemplo (opcional):** `npx wrangler d1 execute panificadora-frank-db --local --file=./examples/dados-exemplo.sql`
(preencha telefone/endereço reais antes de publicar).

---

## 3. Publicar na Cloudflare (passo a passo)

### 3.1. Instalar e entrar na conta

```bash
npm install
npx wrangler login          # abre o navegador para autorizar sua conta Cloudflare
```

### 3.2. Criar o banco D1 e colar o ID no `wrangler.toml`

```bash
npx wrangler d1 create panificadora-frank-db
```

O comando imprime um bloco parecido com:

```toml
[[d1_databases]]
binding = "DB"
database_name = "panificadora-frank-db"
database_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
```

Copie **o `database_id`** e substitua `COLE_AQUI_O_DATABASE_ID` no arquivo
`wrangler.toml`.

### 3.3. Criar as tabelas no banco de produção

```bash
npm run db:remote
```

Isso executa o `schema.sql` no banco real (o arquivo é idempotente: pode rodar de novo
sem apagar dados). Ele cria as tabelas `admins`, `sessions`, `media`, `sections`,
`products`, `section_products`, `content_blocks`, `settings`, `login_attempts` e
insere os textos padrão.

### 3.4. Criar o primeiro administrador

Escolha **uma** das opções:

**Opção A — pelo próprio site (recomendado):** depois do deploy, abra
`https://SEU-DOMINIO/admin/`. Como ainda não existe administrador, aparece a tela
“Configuracao inicial”. Crie seu usuário e senha ali. Nenhuma senha padrão existe no
código — a senha é definida por você e gravada já como hash.

**Opção B — por linha de comando (sem abrir o site):**

```bash
node scripts/create-admin.mjs --email seu@email.com --senha "SuaSenha123" --nome "Seu Nome"
```

Para ver apenas o SQL gerado (executar manualmente depois):

```bash
node scripts/create-admin.mjs --email seu@email.com --senha "SuaSenha123" --sql
```

> A senha é transformada em **PBKDF2-SHA256 (150.000 iterações)** antes de entrar no
> banco. Em nenhum momento ela é gravada em texto puro.

### 3.5. Publicar

```bash
npm run deploy
```

O `wrangler` devolve a URL pública, algo como
`https://panificadora-frank.SEU-SUBDOMINIO.workers.dev`.

### 3.6. (Opcional) Domínio próprio

No painel da Cloudflare: **Workers & Pages → panificadora-frank → Settings →
Domains & Routes → Add custom domain** e informe, por exemplo,
`www.panificadorafrank.com.br`. A Cloudflare cria o registro DNS automaticamente.

---

## 4. Variáveis, segredos e bindings

### 4.1. Variáveis não secretas (já configuradas em `wrangler.toml`)

| Nome | Valor padrão | Para que serve |
| --- | --- | --- |
| `APP_NAME` | `Panificadora Frank` | Nome exibido em mensagens e no `/api/health` |
| `APP_ENV` | `production` | Em `development` a API devolve detalhes técnicos nos erros |

### 4.2. Segredos

**Nenhum segredo é obrigatório.** O sistema funciona apenas com o binding `DB` (D1) e o
binding de arquivos estáticos `ASSETS`. Não há chaves de API, tokens ou senhas no
código-fonte.

### 4.3. Bindings

| Binding | Tipo | Obrigatório | Observação |
| --- | --- | --- | --- |
| `DB` | D1 Database | **Sim** | Criado no passo 3.2 |
| `ASSETS` | Assets | **Sim** | Já configurado (`directory = "./public"`) |
| `SESSION_KV` | KV Namespace | Não | Opcional; usado como camada extra de *rate limit* no login |
| `ALLOWED_ORIGIN` | variável | Não | Só é necessário se o Painel ADM for hospedado em **outro domínio** (CORS) |

#### Como habilitar o `SESSION_KV` (opcional)

O sistema de limite de tentativas de login já funciona **sem KV**, usando a tabela
`login_attempts` no D1. Se quiser uma camada adicional:

```bash
npx wrangler kv namespace create SESSION_KV
```

E descomente no `wrangler.toml`:

```toml
[[kv_namespaces]]
binding = "SESSION_KV"
id = "ID_RETORNADO_PELO_COMANDO"
```

Sem esse binding, nada quebra: o `/api/health` apenas informa `"kv_enabled": false`.

#### Como definir um segredo/variável pelo painel (alternativa ao `wrangler.toml`)

**Workers & Pages → panificadora-frank → Settings → Variables and Secrets → Add.**
Para variáveis do tipo *secret* (criptografadas), use também o comando:

```bash
npx wrangler secret put NOME_DA_VARIAVEL
```

---

## 5. Imagens: por que não usamos R2

O projeto **não usa R2**. As imagens enviadas pelo Painel ADM são guardadas na tabela
`media` do próprio **D1** (coluna `data`, do tipo BLOB) e entregues pela rota
`GET /api/media/:id` com cache de 1 ano (`immutable`).

Por que essa escolha:

- É compatível com Cloudflare sem custo adicional e sem configurar mais um serviço.
- O D1 é um SQLite gerenciado: cada linha suporta até ~2 MB, então limitamos o upload
  a 2 MB por imagem.
- As fotos de **design** do site (topo, "sobre", produtos de exemplo) ficam como
  arquivos estáticos em `public/assets/img/` — servidas direto pelo Worker, sem custo de
  banco.

Limite de upload e como ele é respeitado:

1. O navegador **redimensiona (máx. 1600 px) e comprime** a imagem antes de enviar
   (JPEG qualidade ~0,82, reduzindo mais se necessário). Uma foto de 7 MB chega ao
   servidor com ~1,5 MB.
2. O servidor valida o tipo real pelo conteúdo (*magic bytes*): apenas **JPG, PNG e
   WebP** são aceitos; SVG, PDF, executáveis e arquivos disfarçados são recusados.
3. O servidor recusa qualquer arquivo acima de 2 MB (HTTP 413) com mensagem clara.

> Se no futuro você precisar de muitos vídeos, arquivos grandes ou milhares de imagens,
> o caminho natural é adicionar R2. Hoje, para uma padaria, o D1 é suficiente e mais
> simples de manter.

---

## 6. Banco de dados

### Tabelas

| Tabela | Conteúdo |
| --- | --- |
| `admins` | Usuários do Painel ADM (senha em hash PBKDF2, papel admin/editor) |
| `sessions` | Sessões ativas (guardamos o SHA-256 do token, não o token) |
| `products` | Produtos: nome, descrição, preço, foto, status, horário-limite, ordem |
| `sections` | Quadros/seções dinâmicas criadas no Painel ADM |
| `section_products` | Relação entre seções e produtos (N:N) |
| `settings` | Configurações gerais (nome, contatos, endereço, horários, SEO...) |
| `content_blocks` | Textos editáveis do site (topo, sobre, produtos, contato...) |
| `media` | Imagens enviadas (binário no banco) |
| `login_attempts` | Tentativas de login (rate limit e auditoria) |
| `app_meta` | Versão do schema |

### Comandos úteis

```bash
# Aplicar/atualizar o schema em produção (idempotente)
npm run db:remote

# Ver os produtos no banco de produção
npx wrangler d1 execute panificadora-frank-db --remote --command "SELECT id, name, price, status FROM products;"

# Backup completo do banco de produção (arquivo .sql local)
npx wrangler d1 export panificadora-frank-db --remote --output=backup.sql

# Restaurar um backup
npx wrangler d1 execute panificadora-frank-db --remote --file=./backup.sql
```

---

## 7. Funcionalidades

### Site público (`/`)

- **Cabeçalho**: logo/nome, menu de navegação, botão de WhatsApp e **menu de três
  pontos** com navegação extra, Instagram, Google Maps e a opção **Painel ADM**.
- **Apresentação**: nome, frase de apresentação, imagem de destaque, botão para os
  produtos e botão de WhatsApp, além do selo “Aberto agora / Fechado”.
- **Sobre**: história editável no Painel ADM, com imagem substituível.
- **Produtos**: cards com nome, descrição, preço, foto, **status DISPONÍVEL /
  NÃO DISPONÍVEL**, selo de destaque, horário-limite e botão “Pedir” (WhatsApp).
  Filtros “Disponíveis agora” e “Ver todos”.
- **Quadros/seções dinâmicas**: quantas o administrador criar, com título, subtítulo,
  texto, imagem, botão (texto, link e estilo), produtos relacionados, ordem, ativo/
  inativo e três variações de fundo/layout.
- **Contato**: telefone (clique para ligar), WhatsApp, Instagram, e-mail, endereço e
  **horário de atendimento** com o dia atual destacado.
- **Localização**: mapa incorporado (ou botão) e endereço com link para o Google Maps.
- **Rodapé**: nome, contatos, Instagram, WhatsApp, endereço e links importantes.
- **Botão flutuante de WhatsApp** (vira ícone no celular).

### Painel ADM (`/admin/`)

- Login com e-mail e senha, sessão em **cookie HttpOnly + Secure + SameSite=Lax**,
  logout e proteção de todas as rotas administrativas.
- **Resumo** com indicadores e atalhos.
- **Produtos**: criar, editar, excluir (com confirmação), ativar/desativar, alterar
  disponibilidade, definir horário “disponível até”, enviar/trocar/remover foto e
  reordenar (setas ou campo de ordem).
- **Quadros/seções**: criar, editar, excluir, ativar/desativar, reordenar, escolher
  layout, fundo, botão e produtos relacionados.
- **Textos**: todos os textos principais do site, com upload de imagem integrado.
- **Imagens**: galeria com envio (otimização automática no navegador), pré-visualização,
  exclusão com aviso quando a imagem está em uso e cópia do endereço.
- **Configurações**: nome, logo, telefone, WhatsApp (com mensagem automática),
  Instagram, Facebook, TikTok, e-mail, endereço, link do Google Maps, mapa incorporado,
  horários de atendimento por dia da semana, fuso horário, moeda e SEO.
- **Conta**: troca de senha (encerra as outras sessões) e gestão de administradores
  (criar, ativar/desativar, excluir).
- Interface **mobile-first**: barra inferior de navegação no celular e abas no desktop;
  feedback visual (toasts), estados de carregamento e mensagens de erro claras.

---

## 8. Segurança implementada

- Senhas **nunca** em texto puro: PBKDF2-SHA256 com 150.000 iterações e salt aleatório.
- Sessões: token aleatório de 32 bytes; no banco fica apenas o **SHA-256** do token —
  quem ler o banco não consegue se passar por ninguém.
- Cookie de sessão `HttpOnly`, `Secure` e `SameSite=Lax`, com expiração de 14 dias.
- **Todas** as rotas `/api/admin/*` exigem sessão válida (testado automaticamente).
- Validação de dados no servidor: nome obrigatório, horários em formato `HH:MM`,
  links restritos a `http(s)`, caminhos internos, `mailto:`/`tel:` e `#` (bloqueia
  `javascript:`), e-mail válido, fuso horário existente, preços em formato brasileiro.
- Upload restrito por tipo real do arquivo (magic bytes) e por tamanho (2 MB).
- Limite de tentativas de login (8 falhas em 15 minutos bloqueiam temporariamente).
- Nenhuma credencial, token ou senha padrão no código-fonte.
- A rota `/api/health` não expõe dados sensíveis.

---

## 9. Verificação antes de considerar pronto

```bash
# 1) Verificações de estrutura: arquivos, rotas da API, imports e configuração
npm run build:check

# 2) Testes ponta a ponta (com o servidor local rodando em outra aba)
npm run dev
npm run test:e2e                 # 128 verificações: auth, CRUD, upload, site público

# 3) Capturas em celular/tablet/desktop (confere responsividade e erros de JS)
npm run shots
```

### Comandos disponíveis

| Comando | O que faz |
| --- | --- |
| `npm run dev` | Sobe o site + painel + API em `http://127.0.0.1:8787` |
| `npm run deploy` | Publica na Cloudflare |
| `npm run db:create` | Cria o banco D1 na Cloudflare |
| `npm run db:local` | Cria/atualiza as tabelas no banco **local** |
| `npm run db:remote` | Cria/atualiza as tabelas no banco de **produção** |
| `npm run admin:create` | Cria/redefine um administrador (opções `--email`, `--senha`, `--nome`, `--local`, `--sql`) |
| `npm run test:e2e` | Roda os 128 testes ponta a ponta da API |
| `npm run shots` | Gera capturas em 360/390/768/1440 px e aponta erros de JS |
| `npm run build:check` | Confere arquivos, imports, rotas, bindings e ausência de segredos |

O `e2e-test.mjs` reinicia o banco local automaticamente antes de rodar, então pode ser
executado várias vezes seguidas. Ele cobre: arquivos estáticos, proteção das rotas
administrativas, instalação do primeiro admin, login/logout, CRUD de produtos e seções,
reordenação, configurações, textos, upload/leitura/exclusão de imagens (incluindo
recusa de arquivos falsos), API do site público e troca de senha.

---

## 10. Perguntas frequentes

**Preciso configurar “Build command” na Cloudflare?**
Não. O projeto não tem etapa de build: o Worker é JavaScript puro e os arquivos
estáticos já estão em `public/`. Basta `npx wrangler deploy` (ou conectar o repositório
Git e deixar o comando de deploy padrão).

**Esqueci a senha do Painel ADM. E agora?**
Gere uma nova com o script:

```bash
node scripts/create-admin.mjs --email seu@email.com --senha "NovaSenha123"
```

(Se o e-mail já existir, a senha é redefinida.)

**Como faço backup dos textos, produtos e imagens?**
`npx wrangler d1 export panificadora-frank-db --remote --output=backup.sql` gera um
arquivo com todo o conteúdo, inclusive as imagens (em base64 no SQL).

**Posso usar outro banco (Postgres, MySQL)?**
O projeto foi feito para D1. Outro banco exigiria trocar a camada `src/lib/util.js` e as
consultas em `src/routes/*` — a arquitetura em si não impede, mas não é o caminho
suportado.

**O que NÃO funciona sem configuração externa?**
Nada é bloqueante: o site, o Painel ADM, o banco, o upload e a autenticação funcionam
com apenas `DB` + `ASSETS`. As únicas configurações **opcionais** são: `SESSION_KV`
(rate limit extra), `ALLOWED_ORIGIN` (se o painel ficar em outro domínio) e um domínio
personalizado. Para o mapa aparecer incorporado no site, é preciso colar o link de
*incorporar* do Google Maps no Painel ADM (o botão “Abrir no Google Maps” já funciona
com o link comum).
