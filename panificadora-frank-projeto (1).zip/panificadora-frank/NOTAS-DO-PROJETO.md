# Notas internas do projeto (estado da entrega)

Arquivo de apoio — resume o que já foi feito e validado neste projeto.
Pode ser apagado antes de publicar, se preferir.

## O que está pronto

- **Site público** (`public/index.html` + `assets/css/styles.css` + `assets/js/site.js`):
  cabeçalho com logo/menu/botão WhatsApp/menu de três pontos (com "Painel ADM"),
  apresentação, sobre, produtos com status DISPONÍVEL/NÃO DISPONÍVEL, quadros
  dinâmicos, contato, horários, localização e rodapé.
- **Painel ADM** (`public/admin/`): login real, sessão em cookie HttpOnly, resumo,
  CRUD de produtos, quadros/seções, textos, galeria de imagens, configurações e conta.
- **Backend** (`src/`): Worker único servindo API + arquivos estáticos, sem dependências.
- **Banco** (`schema.sql`): 10 tabelas no Cloudflare D1.
- **Imagens**: ficam no próprio D1 (tabela `media`), sem R2. Fotos de design em
  `public/assets/img/` (otimizadas: ~200–350 KB cada, geradas por IA, sem texto).

## Validações executadas

| Verificação | Resultado |
| --- | --- |
| `node scripts/e2e-test.mjs` (API ponta a ponta) | 128 aprovados, 0 falhas |
| `npm run build:check` (estrutura/imports/rotas/segredos) | 0 erros |
| `npx wrangler deploy --dry-run` | OK (18 arquivos, 56,78 KiB) |
| Capturas em 360/390/768/1440 px | sem overflow horizontal, sem erros de JS |
| Upload real de imagem 7,1 MB pelo painel | otimizado para 1,61 MB e salvo |

## Bugs encontrados e corrigidos durante a validação

1. `ok()` retornava `{ok: undefined}` — corrigido para sempre incluir `ok: true`.
2. Rotas `reorder` caíam no handler de criação — corrigido no roteador.
3. Configuração `[env.preview]` gerava ambiguidade no deploy — removida.
4. Atributo `hidden` era sobrescrito por `display: block` — regra `[hidden]` adicionada.
5. IDs de uploader duplicados (vários uploaders na mesma página) — IDs únicos por instância.
6. Div de preview do uploader sem `data-role` — corrigido (upload falhava silenciosamente).
7. Cabeçalho no celular truncava o nome da empresa — ajustes de mídia query.
8. Links de mapa/redes sociais eram descartados em silêncio — agora validados com erro claro.

## Comandos usados para testar localmente

```bash
npm install
npm run db:local          # cria as tabelas
npm run dev               # http://127.0.0.1:8787
node scripts/e2e-test.mjs # reinicia o banco local e roda 128 verificações
npm run build:check       # verificação de estrutura
```

Administrador criado nos testes locais: `admin@panificadorafrank.com` / `Panifica2026`
(apenas no banco **local** de desenvolvimento — não existe em produção).

## Correção final (após varredura de referências)

9. O `package.json` apontava para `scripts/generate-password-hash.mjs`, arquivo que nunca
   existiu. Substituído pelos scripts reais: `admin:create`, `test:e2e` e `shots`.
   O verificador (`npm run build:check`) agora checa automaticamente todos os comandos
   que apontam para arquivos em `scripts/`, para que esse tipo de erro não volte.
