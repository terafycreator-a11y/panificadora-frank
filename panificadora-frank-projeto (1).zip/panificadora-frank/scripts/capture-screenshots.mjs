#!/usr/bin/env node
/**
 * Captura telas do site publico e do Painel ADM em varios tamanhos de tela,
 * para conferir a responsividade (celular Android/iPhone, tablet e desktop).
 *
 * Uso:
 *   node scripts/capture-screenshots.mjs [url-base] [pasta-saida]
 */

import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';

const BASE = process.argv[2] || 'http://127.0.0.1:8787';
const OUT = resolve(process.argv[3] || '/home/ubuntu/panificadora-frank/../screenshots-verificacao');

const DEVICES = [
  { name: 'android-360', width: 360, height: 780, dpr: 3 },
  { name: 'iphone-390', width: 390, height: 844, dpr: 3 },
  { name: 'tablet-768', width: 768, height: 1024, dpr: 2 },
  { name: 'desktop-1440', width: 1440, height: 900, dpr: 1 },
];

const PAGES = [
  { name: 'site', path: '/', full: true },
  { name: 'admin', path: '/admin/', full: false, auth: true },
];

mkdirSync(OUT, { recursive: true });

const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
const results = [];

for (const device of DEVICES) {
  const context = await browser.newContext({
    viewport: { width: device.width, height: device.height },
    deviceScaleFactor: device.dpr,
    isMobile: device.width < 700,
    hasTouch: device.width < 700,
    locale: 'pt-BR',
  });

  // Autentica uma vez por contexto para capturar o painel logado.
  const loginResponse = await context.request.post(`${BASE}/api/auth/login`, {
    data: { email: process.env.ADMIN_EMAIL || 'admin@panificadorafrank.com', password: process.env.ADMIN_PASSWORD || 'Panifica2026' },
  });
  const loggedIn = loginResponse.ok();

  for (const page of PAGES) {
    if (page.auth && !loggedIn) continue;

    const tab = await context.newPage();
    const errors = [];
    tab.on('pageerror', (error) => errors.push(String(error.message)));
    tab.on('console', (message) => {
      if (message.type() === 'error') errors.push(message.text());
    });

    await tab.goto(`${BASE}${page.path}`, { waitUntil: 'networkidle' });
    await tab.waitForTimeout(1400);

    const file = `${OUT}/${page.name}-${device.name}.png`;
    await tab.screenshot({ path: file, fullPage: Boolean(page.full) });

    // Diagnostico de overflow horizontal (problema comum no celular).
    const metrics = await tab.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      clientWidth: document.documentElement.clientWidth,
      bodyScrollWidth: document.body.scrollWidth,
    }));

    results.push({
      page: page.name,
      device: device.name,
      file,
      overflowX: metrics.scrollWidth > metrics.clientWidth + 1,
      metrics,
      errors: errors.slice(0, 5),
    });

    await tab.close();
  }

  await context.close();
}

await browser.close();

console.log('\nCapturas e diagnostico:');
for (const item of results) {
  const status = item.overflowX ? 'OVERFLOW-X' : 'ok';
  console.log(`- ${item.page} @ ${item.device}: ${status} (scroll ${item.metrics.scrollWidth} / view ${item.metrics.clientWidth})`);
  if (item.errors.length) console.log(`    erros JS: ${item.errors.join(' | ')}`);
}
console.log(`\nImagens salvas em ${OUT}`);
