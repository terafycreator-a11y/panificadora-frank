#!/usr/bin/env python3
"""
Otimiza as imagens de design do site (public/assets/img) para uso na web.

- Redimensiona para no maximo 1600 px de largura (suficiente para retina em cards)
- Salva em JPEG progressivo, qualidade 82
- Remove metadados (EXIF) desnecessarios

Uso:
    python3 scripts/optimize-images.py
"""

import os
import sys
from pathlib import Path

try:
    from PIL import Image, ImageOps
except ImportError:
    sys.exit("Instale o Pillow: pip3 install Pillow")

IMG_DIR = Path(__file__).resolve().parent.parent / "public" / "assets" / "img"
MAX_WIDTH = 1600
QUALITY = 82

TARGETS = [
    "hero-panificadora.jpg",
    "sobre-panificadora.jpg",
    "produto-pao-frances.jpg",
    "produto-bolo-cenoura.jpg",
    "produto-salgado-assado.jpg",
]


def optimize(path: Path) -> str:
    before = path.stat().st_size
    with Image.open(path) as img:
        img = ImageOps.exif_transpose(img)
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        if img.width > MAX_WIDTH:
            ratio = MAX_WIDTH / img.width
            img = img.resize((MAX_WIDTH, round(img.height * ratio)), Image.LANCZOS)
        img.save(path, "JPEG", quality=QUALITY, optimize=True, progressive=True)
    after = path.stat().st_size
    return f"{path.name}: {before / 1024:.0f} KB -> {after / 1024:.0f} KB"


def main() -> None:
    if not IMG_DIR.is_dir():
        sys.exit(f"Pasta nao encontrada: {IMG_DIR}")

    files = [IMG_DIR / name for name in TARGETS if (IMG_DIR / name).exists()]
    if not files:
        sys.exit("Nenhuma imagem encontrada para otimizar.")

    for path in files:
        print(optimize(path))


if __name__ == "__main__":
    main()