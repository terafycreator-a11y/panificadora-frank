#!/usr/bin/env node
/**
 * Cria (ou redefine a senha de) um administrador do Painel ADM.
 *
 * Uso:
 *   node scripts/create-admin.mjs --email frank@panificadora.com --senha "MinhaSenha123" --nome "Frank"
 *   node scripts/create-admin.mjs --email ... --senha ... --local        (banco local)
 *   node scripts/create-admin.mjs --email ... --senha ... --sql          (apenas imprime o SQL)
 *
 * A senha e transformada em hash PBKDF2-SHA256 (150.000 iteracoes) antes de entrar
 * no banco — nenhuma senha em texto puro e gravada.
 */

import { execFileSync } from 'node:child_process';
import { randomBytes, pbkdf2Sync } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const ITERATIONS = 150000;
const DB_NAME = 'panificadora-frank-db';

function base64Url(buffer) {
  return Buffer.from(buffer).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function hashPassword(password) {
  const salt = randomBytes(16);
  const hash = pbkdf2Sync(password, salt, ITERATIONS, 32, 'sha256');
  return `pbkdf2$sha256$${ITERATIONS}$${base64Url(salt)}$${base64Url(hash)}`;
}

function parseArgs(argv) {
  const args = { local: false, sql: false, role: 'admin' };
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (token === '--local') args.local = true;
    else if (token === '--sql') args.sql = true;
    else if (token === '--remote') args.local = false;
    else if (token.startsWith('--')) {
      const key = token.replace(/^--/, '');
      const value = argv[i + 1];
      args[key] = value;
      i += 1;
    }
  }
  return args;
}

function quote(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function validatePassword(password) {
  if (!password || password.length < 8) return 'A senha deve ter pelo menos 8 caracteres.';
  if (!/[A-Za-z]/.test(password)) return 'A senha deve conter pelo menos uma letra.';
  if (!/\d/.test(password)) return 'A senha deve conter pelo menos um numero.';
  return null;
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const email = String(args.email || '').trim().toLowerCase();
  const password = String(args.senha || args.password || '');
  const name = String(args.nome || args.name || 'Administrador').trim();
  const role = args.role === 'editor' ? 'editor' : 'admin';

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    console.error('Informe um e-mail valido com --email.\n');
    printUsage();
    process.exit(1);
  }

  const pwdError = validatePassword(password);
  if (pwdError) {
    console.error(`${pwdError}\n`);
    printUsage();
    process.exit(1);
  }

  const hash = hashPassword(password);

  const sql =
    `INSERT INTO admins (email, name, password_hash, role, active, must_change_password) ` +
    `VALUES (${quote(email)}, ${quote(name)}, ${quote(hash)}, ${quote(role)}, 1, 0) ` +
    `ON CONFLICT(email) DO UPDATE SET password_hash = excluded.password_hash, ` +
    `name = excluded.name, role = excluded.role, active = 1, must_change_password = 0, ` +
    `updated_at = datetime('now');`;

  if (args.sql) {
    console.log(sql);
    return;
  }

  const scope = args.local ? '--local' : '--remote';
  console.log(`Gravando administrador ${email} no banco ${DB_NAME} (${args.local ? 'local' : 'producao'})...`);

  try {
    const output = execFileSync(
      'npx',
      ['wrangler', 'd1', 'execute', DB_NAME, scope, '--command', sql],
      { stdio: ['inherit', 'pipe', 'pipe'], encoding: 'utf8', cwd: resolve(dirname(fileURLToPath(import.meta.url)), '..') }
    );
    console.log(output.trim().slice(-600));
    console.log(`\nPronto. Acesse /admin e entre com ${email}.`);
  } catch (error) {
    console.error('\nFalha ao executar o wrangler.');
    if (error.stdout) console.error(String(error.stdout));
    if (error.stderr) console.error(String(error.stderr));
    console.error('\nAlternativa: gere somente o SQL com --sql e execute manualmente:');
    console.error(`  npx wrangler d1 execute ${DB_NAME} --remote --command "<SQL impresso acima>"`);
    process.exit(1);
  }
}

function printUsage() {
  console.log('Uso:');
  console.log('  node scripts/create-admin.mjs --email seu@email.com --senha "Senha123" [--nome "Seu Nome"] [--local|--remote] [--sql]');
}

main();