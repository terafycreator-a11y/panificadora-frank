#!/usr/bin/env node
/**
 * Teste ponta a ponta da API da Panificadora Frank.
 *
 * Execute com o servidor local ativo:
 *   npx wrangler dev --port 8787            (em outro terminal)
 *   node scripts/e2e-test.mjs               (ou BASE_URL=https://... node scripts/e2e-test.mjs)
 *
 * O teste cobre: instalacao do primeiro admin, login, protecao de rotas,
 * CRUD de produtos, secoes, configuracoes, textos, upload/listagem de imagens,
 * ordenacao e leitura do site publico.
 */

const BASE = (process.env.BASE_URL || 'http://127.0.0.1:8787').replace(/\/$/, '');

import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const PROJECT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

/**
 * Limpa o banco local antes de rodar (apenas quando BASE_URL aponta para localhost).
 * Assim a suite pode ser executada varias vezes seguidas sem falhas residuais.
 */
function resetLocalDatabase() {
  const isLocal = /localhost|127\.0\.0\.1/.test(BASE);
  if (!isLocal || process.env.SKIP_RESET === '1') {
    return;
  }

  const sql = [
    'DELETE FROM section_products;',
    'DELETE FROM sections;',
    'DELETE FROM products;',
    'DELETE FROM media;',
    'DELETE FROM sessions;',
    'DELETE FROM login_attempts;',
    'DELETE FROM admins;',
    'DELETE FROM content_blocks;',
    'DELETE FROM settings;',
    'DELETE FROM app_meta;',
  ].join(' ');

  try {
    execFileSync('npx', ['wrangler', 'd1', 'execute', 'panificadora-frank-db', '--local', '--command', sql], {
      cwd: PROJECT_ROOT,
      stdio: ['ignore', 'ignore', 'pipe'],
      encoding: 'utf8',
    });
    // Recria os valores padrao (settings/content_blocks) do schema.
    execFileSync('npx', ['wrangler', 'd1', 'execute', 'panificadora-frank-db', '--local', '--file=./schema.sql'], {
      cwd: PROJECT_ROOT,
      stdio: ['ignore', 'ignore', 'pipe'],
      encoding: 'utf8',
    });
    console.log('Banco local reiniciado para o teste.');
  } catch (error) {
    console.warn('Aviso: nao foi possivel reiniciar o banco local automaticamente.');
    if (error.stderr) console.warn(String(error.stderr).slice(0, 400));
  }
}

let cookie = '';
let passed = 0;
let failed = 0;
const failures = [];

function log(icon, message) {
  console.log(`${icon} ${message}`);
}

function check(name, condition, detail) {
  if (condition) {
    passed += 1;
    log('  ok', name);
  } else {
    failed += 1;
    failures.push(name + (detail ? ` -> ${detail}` : ''));
    log('  FAIL', name + (detail ? ` -> ${detail}` : ''));
  }
}

async function request(path, options = {}) {
  const headers = Object.assign({ accept: 'application/json' }, options.headers || {});
  if (cookie) headers.cookie = cookie;
  let body = options.body;
  if (body !== undefined && !(body instanceof FormData)) {
    headers['content-type'] = 'application/json';
    body = JSON.stringify(body);
  }

  const response = await fetch(BASE + path, {
    method: options.method || 'GET',
    headers,
    body,
    redirect: 'manual',
  });

  const setCookie = response.headers.get('set-cookie');
  if (setCookie) {
    cookie = setCookie.split(';')[0];
  }

  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  return { status: response.status, data, headers: response.headers, raw: text };
}

/* -------------------------------------------------------------------------- */
/* 1. Arquivos estaticos                                                      */
/* -------------------------------------------------------------------------- */
async function testStaticFiles() {
  console.log('\n[1] Arquivos estaticos');

  const html = await fetch(BASE + '/').then((r) => r.text().catch(() => ''));
  check('Pagina inicial responde 200', html.length > 500, `tamanho ${html.length}`);
  check('Pagina inicial contem "Panificadora Frank"', html.includes('Panificadora Frank'));
  check('Menu de tres pontos presente', html.includes('menu-trigger'));
  check('Opcao Painel ADM presente no menu', html.includes('/admin/'));

  const admin = await fetch(BASE + '/admin/').then((r) => r.text().catch(() => ''));
  check('Painel ADM (/admin/) responde', admin.includes('Painel ADM'), `tamanho ${admin.length}`);

  const css = await fetch(BASE + '/assets/css/styles.css');
  check('CSS do site carrega', css.status === 200);

  const adminCss = await fetch(BASE + '/admin/assets/admin.css');
  check('CSS do painel carrega', adminCss.status === 200);

  const js = await fetch(BASE + '/assets/js/site.js');
  check('JS do site carrega', js.status === 200);

  const adminJs = await fetch(BASE + '/admin/assets/admin.js');
  check('JS do painel carrega', adminJs.status === 200);

  for (const img of [
    'hero-panificadora.jpg',
    'sobre-panificadora.jpg',
    'produto-pao-frances.jpg',
    'produto-bolo-cenoura.jpg',
    'produto-salgado-assado.jpg',
    'favicon.svg',
  ]) {
    const res = await fetch(`${BASE}/assets/img/${img}`);
    check(`Imagem ${img} existe`, res.status === 200);
  }
}

/* -------------------------------------------------------------------------- */
/* 2. Protecao de rotas                                                       */
/* -------------------------------------------------------------------------- */
async function testAuthProtection() {
  console.log('\n[2] Protecao das rotas administrativas (sem sessao)');

  const protectedRoutes = [
    ['GET', '/api/admin/products'],
    ['POST', '/api/admin/products'],
    ['PUT', '/api/admin/products/1'],
    ['DELETE', '/api/admin/products/1'],
    ['GET', '/api/admin/sections'],
    ['POST', '/api/admin/sections'],
    ['GET', '/api/admin/settings'],
    ['PUT', '/api/admin/settings'],
    ['GET', '/api/admin/content'],
    ['PUT', '/api/admin/content'],
    ['GET', '/api/admin/media'],
    ['POST', '/api/admin/media'],
    ['DELETE', '/api/admin/media/abc'],
    ['GET', '/api/admin/admins'],
    ['POST', '/api/admin/change-password'],
  ];

  for (const [method, path] of protectedRoutes) {
    const res = await request(path, { method, body: method === 'GET' ? undefined : {} });
    check(`${method} ${path} exige autenticacao`, res.status === 401, `status ${res.status}`);
  }

  const setupStatus = await request('/api/setup/status');
  check('Setup necessario no banco limpo', setupStatus.data?.setup_required === true);
}

/* -------------------------------------------------------------------------- */
/* 3. Instalacao do primeiro administrador                                    */
/* -------------------------------------------------------------------------- */
async function testSetup() {
  console.log('\n[3] Instalacao do primeiro administrador');

  const weak = await request('/api/setup', {
    method: 'POST',
    body: { name: 'Frank', email: 'admin@panificadorafrank.com', password: '123', password_confirm: '123' },
  });
  check('Senha fraca e recusada', weak.status === 400, JSON.stringify(weak.data));

  const mismatch = await request('/api/setup', {
    method: 'POST',
    body: { name: 'Frank', email: 'admin@panificadorafrank.com', password: 'SenhaBoa123', password_confirm: 'Outra123' },
  });
  check('Senhas diferentes sao recusadas', mismatch.status === 400, JSON.stringify(mismatch.data));

  const invalidEmail = await request('/api/setup', {
    method: 'POST',
    body: { name: 'Frank', email: 'email-invalido', password: 'SenhaBoa123', password_confirm: 'SenhaBoa123' },
  });
  check('E-mail invalido e recusado', invalidEmail.status === 400);

  const ok = await request('/api/setup', {
    method: 'POST',
    body: {
      name: 'Frank Administrador',
      email: 'admin@panificadorafrank.com',
      password: 'Panifica2026',
      password_confirm: 'Panifica2026',
    },
  });
  check('Primeiro administrador criado', ok.status === 200 && ok.data?.ok === true, JSON.stringify(ok.data));

  const me = await request('/api/auth/me');
  check('Sessao criada automaticamente apos o setup', me.data?.authenticated === true);

  const again = await request('/api/setup', {
    method: 'POST',
    body: { name: 'Invasor', email: 'invasor@x.com', password: 'Panifica2026', password_confirm: 'Panifica2026' },
  });
  check('Setup bloqueado depois do primeiro admin', again.status === 409, `status ${again.status}`);
}

/* -------------------------------------------------------------------------- */
/* 4. Sessao e login                                                          */
/* -------------------------------------------------------------------------- */
async function testSession() {
  console.log('\n[4] Sessao, login e logout');

  const wrong = await request('/api/auth/login', {
    method: 'POST',
    body: { email: 'admin@panificadorafrank.com', password: 'senha-errada' },
  });
  check('Login com senha errada falha', wrong.status === 401);

  const wrongEmail = await request('/api/auth/login', {
    method: 'POST',
    body: { email: 'naoexiste@x.com', password: 'Panifica2026' },
  });
  check('Login com e-mail inexistente falha', wrongEmail.status === 401);

  // Sessao publica usada para o login.
  cookie = '';
  const login = await request('/api/auth/login', {
    method: 'POST',
    body: { email: 'admin@panificadorafrank.com', password: 'Panifica2026' },
  });
  check('Login com credenciais corretas funciona', login.status === 200 && login.data?.ok === true, JSON.stringify(login.data));
  check('Cookie de sessao foi definido', Boolean(cookie), cookie);

  const me = await request('/api/auth/me');
  check('Rota /me reconhece o administrador', me.data?.authenticated === true && me.data?.admin?.email === 'admin@panificadorafrank.com');

  const emailCase = await request('/api/auth/login', {
    method: 'POST',
    body: { email: 'ADMIN@PANIFICADORAFRANK.COM', password: 'Panifica2026' },
  });
  check('Login ignora maiusculas no e-mail', emailCase.status === 200);
}

/* -------------------------------------------------------------------------- */
/* 5. Produtos                                                                */
/* -------------------------------------------------------------------------- */
async function testProducts() {
  console.log('\n[5] Produtos (criar, editar, ativar, ordenar, excluir)');

  const missingName = await request('/api/admin/products', { method: 'POST', body: { description: 'sem nome' } });
  check('Produto sem nome e recusado', missingName.status === 400);

  const badStatus = await request('/api/admin/products', {
    method: 'POST',
    body: { name: 'Produto de teste temporario', status: 'invalido' },
  });
  check('Status invalido e aceito como padrao (available)', badStatus.status === 201, `status ${badStatus.status}`);
  const tempProductId = badStatus.data?.id;

  const tempFetched = (await request('/api/admin/products')).data.products.find((p) => p.id === tempProductId);
  check('Status desconhecido virou "available"', tempFetched?.status === 'available', tempFetched?.status);

  const autoWithoutTime = await request('/api/admin/products', {
    method: 'POST',
    body: { name: 'Produto automatico', status: 'auto' },
  });
  check('Status "auto" sem horario e recusado', autoWithoutTime.status === 400, JSON.stringify(autoWithoutTime.data));

  const badTime = await request('/api/admin/products', {
    method: 'POST',
    body: { name: 'Produto horario invalido', status: 'auto', available_until: '99:99' },
  });
  check('Horario invalido e recusado', badTime.status === 400);

  const created = await request('/api/admin/products', {
    method: 'POST',
    body: {
      name: 'Pao frances',
      description: 'Assado varias vezes ao dia',
      price: '0,90',
      price_note: 'por unidade',
      image: '/assets/img/produto-pao-frances.jpg',
      status: 'available',
      active: true,
      highlight: true,
    },
  });
  check('Produto criado com preco em formato brasileiro', created.status === 201 && created.data?.id > 0, JSON.stringify(created.data));
  const productId = created.data.id;

  const autoCreated = await request('/api/admin/products', {
    method: 'POST',
    body: {
      name: 'Salgados assados',
      description: 'Saem do forno a tarde',
      price: '7.50',
      image: '/assets/img/produto-salgado-assado.jpg',
      status: 'auto',
      available_until: '17:30',
      active: true,
    },
  });
  check('Produto com horario-limite criado', autoCreated.status === 201, JSON.stringify(autoCreated.data));
  const autoId = autoCreated.data.id;

  // Remove o produto temporario para manter a lista previsivel.
  const tempDelete = await request(`/api/admin/products/${tempProductId}`, { method: 'DELETE' });
  check('Produto excluido', tempDelete.status === 200);

  const list = await request('/api/admin/products');
  const listItems = list.data?.products || [];
  check('Listagem traz os dois produtos', listItems.length === 2, `total ${listItems.length}`);
  const pao = listItems.find((p) => p.id === productId);
  check('Preco "0,90" convertido para 0.9', Number(pao?.price) === 0.9, `valor ${pao?.price}`);
  const salgado = listItems.find((p) => p.id === autoId);
  check('Preco "7.50" convertido para 7.5', Number(salgado?.price) === 7.5, `valor ${salgado?.price}`);
  check('Horario-limite salvo corretamente', salgado?.available_until === '17:30');

  const updated = await request(`/api/admin/products/${productId}`, {
    method: 'PUT',
    body: {
      name: 'Pao frances integral',
      description: 'Nova descricao',
      price: '1,20',
      status: 'unavailable',
      active: true,
      highlight: false,
      sort_order: 5,
    },
  });
  check('Produto atualizado', updated.status === 200 && updated.data?.ok === true);

  const afterUpdate = (await request('/api/admin/products')).data.products.find((p) => p.id === productId);
  check('Nome atualizado', afterUpdate?.name === 'Pao frances integral');
  check('Status atualizado para unavailable', afterUpdate?.status === 'unavailable');
  check('Preco atualizado', Number(afterUpdate?.price) === 1.2);

  const badIdUpdate = await request('/api/admin/products/99999', { method: 'PUT', body: { name: 'X' } });
  check('Editar produto inexistente responde 404', badIdUpdate.status === 404);

  const reorder = await request('/api/admin/products/reorder', {
    method: 'POST',
    body: { order: [autoId, productId] },
  });
  check('Reordenacao de produtos funciona', reorder.status === 200, JSON.stringify(reorder.data));

  const ordered = (await request('/api/admin/products')).data.products;
  check(
    'Produto reordenado para cima aparece antes',
    ordered.findIndex((p) => p.id === autoId) < ordered.findIndex((p) => p.id === productId),
    `ordem: ${ordered.map((p) => p.id).join(', ')}`
  );

  const badReorder = await request('/api/admin/products/reorder', { method: 'POST', body: { order: [] } });
  check('Reordenacao com lista vazia e recusada', badReorder.status === 400);

  const mediaCount = (await request('/api/admin/media')).data.media.length;
  console.log(`  info ${mediaCount} imagem(ns) na galeria`);
}

/* -------------------------------------------------------------------------- */
/* 6. Secoes dinamicas                                                        */
/* -------------------------------------------------------------------------- */
async function testSections() {
  console.log('\n[6] Quadros / secoes dinamicas');

  const products = (await request('/api/admin/products')).data.products;
  const ids = products.map((p) => p.id);

  const noTitle = await request('/api/admin/sections', { method: 'POST', body: { body: 'sem titulo' } });
  check('Secao sem titulo e recusada', noTitle.status === 400);

  const badUrl = await request('/api/admin/sections', {
    method: 'POST',
    body: { title: 'Promocoes', button_label: 'Ver', button_url: 'javascript:alert(1)' },
  });
  check('Link perigoso (javascript:) e bloqueado', badUrl.status === 400, JSON.stringify(badUrl.data));

  const created = await request('/api/admin/sections', {
    method: 'POST',
    body: {
      title: 'Novidades da semana',
      subtitle: 'Chegou hoje',
      body: 'Paragrafo um.\n\nParagrafo dois.',
      image: '/assets/img/produto-bolo-cenoura.jpg',
      button_label: 'Ver promocoes',
      button_url: '/#produtos',
      button_style: 'primary',
      layout: 'image-left',
      background: 'tint',
      active: true,
      product_ids: ids,
    },
  });
  check('Secao criada', created.status === 201 && created.data?.id > 0, JSON.stringify(created.data));
  const sectionId = created.data.id;

  const sections = (await request('/api/admin/sections')).data.sections;
  const section = sections.find((s) => s.id === sectionId);
  check('Secao listada com produtos relacionados', (section?.product_ids || []).length === ids.length, `relacionados ${section?.product_ids?.length}`);

  const external = await request('/api/admin/sections', {
    method: 'POST',
    body: { title: 'Encomendas', button_label: 'WhatsApp', button_url: 'https://wa.me/5511999999999', button_style: 'whatsapp', layout: 'no-image', active: true },
  });
  check('Secao com link externo https e aceita', external.status === 201);

  const updated = await request(`/api/admin/sections/${sectionId}`, {
    method: 'PUT',
    body: {
      title: 'Novidades atualizadas',
      subtitle: 'Chegou hoje',
      body: 'Texto novo',
      image: '',
      button_label: '',
      button_url: '',
      button_style: 'secondary',
      layout: 'image-top',
      background: 'dark',
      active: true,
      product_ids: [ids[0]],
    },
  });
  check('Secao atualizada', updated.status === 200);

  const afterUpdate = (await request('/api/admin/sections')).data.sections.find((s) => s.id === sectionId);
  check('Titulo da secao atualizado', afterUpdate?.title === 'Novidades atualizadas');
  check('Produtos relacionados reduzidos para 1', (afterUpdate?.product_ids || []).length === 1);

  const reorder = await request('/api/admin/sections/reorder', {
    method: 'POST',
    body: { order: [sectionId] },
  });
  check('Reordenacao de secoes funciona', reorder.status === 200);
}

/* -------------------------------------------------------------------------- */
/* 7. Configuracoes e textos                                                  */
/* -------------------------------------------------------------------------- */
async function testSettingsAndContent() {
  console.log('\n[7] Configuracoes e textos');

  const badTz = await request('/api/admin/settings', { method: 'PUT', body: { timezone: 'Fuso/Inexistente' } });
  check('Fuso horario invalido e recusado', badTz.status === 400, JSON.stringify(badTz.data));

  const badOrigin = await request('/api/admin/settings', {
    method: 'PUT',
    body: { google_maps_url: 'javascript:alert(1)' },
  });
  check('Link de mapa com javascript: e bloqueado', badOrigin.status === 400);

  const saved = await request('/api/admin/settings', {
    method: 'PUT',
    body: {
      company_name: 'Panificadora Frank',
      company_tagline: 'Pao quentinho todos os dias',
      phone: '(11) 4002-8922',
      whatsapp: '5511988887777',
      instagram: '@panificadorafrank',
      address_line: 'Rua das Flores, 123',
      address_city: 'Sao Paulo - SP',
      google_maps_url: 'https://maps.google.com/?q=panificadora+frank',
      timezone: 'America/Sao_Paulo',
      currency: 'BRL',
      seo_title: 'Panificadora Frank - Paes e bolos fresquinhos',
      seo_description: 'Paes, bolos e salgados feitos diariamente.',
      business_hours: [
        { day: 'monday', label: 'Segunda-feira', closed: false, open: '06:00', close: '19:00' },
        { day: 'tuesday', label: 'Terca-feira', closed: false, open: '06:00', close: '19:00' },
        { day: 'wednesday', label: 'Quarta-feira', closed: false, open: '06:00', close: '19:00' },
        { day: 'thursday', label: 'Quinta-feira', closed: false, open: '06:00', close: '19:00' },
        { day: 'friday', label: 'Sexta-feira', closed: false, open: '06:00', close: '19:00' },
        { day: 'saturday', label: 'Sabado', closed: false, open: '06:00', close: '18:00' },
        { day: 'sunday', label: 'Domingo', closed: true, open: '07:00', close: '12:00' },
      ],
    },
  });
  check('Configuracoes salvas', saved.status === 200 && saved.data?.ok === true, JSON.stringify(saved.data));

  const settings = (await request('/api/admin/settings')).data.settings;
  check('Nome da empresa salvo', settings.company_name === 'Panificadora Frank');
  check('WhatsApp salvo', settings.whatsapp === '5511988887777');
  const hours = JSON.parse(settings.business_hours);
  check('Horarios salvos (7 dias)', hours.length === 7);
  check('Domingo marcado como fechado', hours.find((h) => h.day === 'sunday')?.closed === true);

  const badContentKey = await request('/api/admin/content', { method: 'PUT', body: { 'chave.invalida': 'x' } });
  check('Chave de texto desconhecida e ignorada', badContentKey.status === 400);

  const contentSaved = await request('/api/admin/content', {
    method: 'PUT',
    body: {
      'hero.title': 'Panificadora Frank',
      'hero.subtitle': 'Paes, bolos e salgados feitos diariamente com receita de familia.',
      'hero.image': '/assets/img/hero-panificadora.jpg',
      'about.title': 'Sobre a Panificadora Frank',
      'about.body': 'Primeiro paragrafo.\n\nSegundo paragrafo.',
      'about.image': '/assets/img/sobre-panificadora.jpg',
      'products.title': 'Nossos produtos',
      'footer.about': 'Pao fresquinho todos os dias.',
    },
  });
  check('Textos do site salvos', contentSaved.status === 200, JSON.stringify(contentSaved.data));

  const content = (await request('/api/admin/content')).data.content;
  check('Titulo do topo salvo', content['hero.title'] === 'Panificadora Frank');
  check('Texto do "Sobre" salvo', content['about.body'].includes('Primeiro paragrafo'));
}

/* -------------------------------------------------------------------------- */
/* 8. Imagens                                                                 */
/* -------------------------------------------------------------------------- */
async function testMedia() {
  console.log('\n[8] Upload, leitura e exclusao de imagens');

  // PNG 1x1 valido
  const pngBase64 =
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  const uploaded = await request('/api/admin/media', {
    method: 'POST',
    body: { filename: 'teste.png', mime_type: 'image/png', data_base64: pngBase64, width: 1, height: 1 },
  });
  check('PNG enviado', uploaded.status === 201 && uploaded.data?.media?.id, JSON.stringify(uploaded.data));
  const mediaId = uploaded.data.media.id;
  check('URL publica da imagem gerada', uploaded.data.media.url === `/api/media/${mediaId}`);

  const served = await fetch(`${BASE}/api/media/${mediaId}`);
  check('Imagem servida publicamente', served.status === 200);
  check('Tipo de conteudo correto', served.headers.get('content-type') === 'image/png');
  check('Cache longo configurado', (served.headers.get('cache-control') || '').includes('immutable'));

  const fakeImage = await request('/api/admin/media', {
    method: 'POST',
    body: { filename: 'malicioso.png', mime_type: 'image/png', data_base64: btoa('#!/bin/sh\nrm -rf /') },
  });
  check('Arquivo que nao e imagem e recusado', fakeImage.status === 415, JSON.stringify(fakeImage.data));

  const svgAttempt = await request('/api/admin/media', {
    method: 'POST',
    body: { filename: 'vetor.svg', mime_type: 'image/svg+xml', data_base64: btoa('<svg onload="alert(1)"/>') },
  });
  check('SVG (script) recusado', svgAttempt.status === 415);

  const wrongExtension = await request('/api/admin/media', {
    method: 'POST',
    body: { filename: 'foto.jpg', mime_type: 'image/png', data_base64: pngBase64 },
  });
  check('Tipo real detectado pelo conteudo (nao pela extensao)', wrongExtension.status === 201 && wrongExtension.data.media.mime_type === 'image/png');

  const form = new FormData();
  form.append('file', new Blob([Buffer.from(pngBase64, 'base64')], { type: 'image/png' }), 'multipart.png');
  form.append('width', '1');
  form.append('height', '1');
  const multipart = await request('/api/admin/media', { method: 'POST', body: form });
  check('Upload via multipart/form-data funciona', multipart.status === 201, JSON.stringify(multipart.data));

  const list = await request('/api/admin/media');
  check('Galeria lista as imagens enviadas', (list.data.media || []).length === 3, `total ${list.data.media?.length}`);
  check('Listagem nao retorna o binario das imagens', list.data.media.every((m) => m.data === undefined));

  const missing = await fetch(`${BASE}/api/media/naoexiste`);
  check('Imagem inexistente responde 404', missing.status === 404);

  const altUpdate = await request(`/api/admin/media/${mediaId}`, { method: 'PATCH', body: { alt: 'Descricao da imagem' } });
  check('Descricao (alt) da imagem atualizada', altUpdate.status === 200);

  const deleted = await request(`/api/admin/media/${multipart.data.media.id}`, { method: 'DELETE' });
  check('Imagem excluida', deleted.status === 200);

  const afterDelete = await fetch(`${BASE}/api/media/${multipart.data.media.id}`);
  check('Imagem excluida nao e mais servida', afterDelete.status === 404);

  // Guarda uma imagem para o teste do site publico
  const heroImage = await request('/api/admin/media', {
    method: 'POST',
    body: { filename: 'hero.png', mime_type: 'image/png', data_base64: pngBase64, alt: 'Imagem de destaque' },
  });
  return heroImage.data.media.url;
}

/* -------------------------------------------------------------------------- */
/* 9. Site publico                                                            */
/* -------------------------------------------------------------------------- */
async function testPublicSite(mediaUrl) {
  console.log('\n[9] API do site publico');

  const site = await request('/api/site');
  check('/api/site responde', site.status === 200);

  const data = site.data || {};
  check('Configuracoes publicas presentes', data.settings?.company_name === 'Panificadora Frank');
  check('Textos presentes', data.content?.['hero.title'] === 'Panificadora Frank');
  check('Horarios publicos presentes', Array.isArray(data.hours) && data.hours.length === 7);
  check('Produtos disponiveis retornados', Array.isArray(data.products));
  check('Secoes dinamicas retornadas', Array.isArray(data.sections) && data.sections.length >= 2, `total ${data.sections?.length}`);

  const section = (data.sections || []).find((s) => s.title === 'Novidades atualizadas');
  check('Secao ativa aparece no site publico', Boolean(section));
  check('Secao traz produto relacionado resolvido', (section?.products || []).length === 1, `relacionados ${section?.products?.length}`);

  const pao = (data.all_products || []).find((p) => p.name === 'Pao frances integral');
  check('Produto com status "unavailable" aparece como indisponivel', pao?.availability?.available === false, JSON.stringify(pao?.availability));
  check('Preco formatado em BRL no site', Boolean(pao?.price_formatted?.includes('R$')), pao?.price_formatted);

  const salgado = (data.all_products || []).find((p) => p.name === 'Salgados assados');
  check('Produto com horario-limite tem regra automatica', salgado?.status === 'auto');
  check('Disponibilidade automatica calculada', typeof salgado?.availability?.available === 'boolean', JSON.stringify(salgado?.availability));
  check('Detalhe do horario-limite informado', Boolean(salgado?.availability?.detail));

  check('Produtos indisponiveis fora da lista de disponiveis', (data.products || []).every((p) => p.availability.available === true));

  const exported = await request('/api/products');
  check('/api/products responde apenas com disponiveis', exported.status === 200 && Array.isArray(exported.data.products));

  const health = await request('/api/health');
  check('/api/health informa o banco como ok', health.data?.database === 'ok');
  check('/api/health nao expoe segredos', !JSON.stringify(health.data).includes('password'));

  console.log(`  info imagem de destaque disponivel em ${mediaUrl}`);
}

/* -------------------------------------------------------------------------- */
/* 10. Alteracao de senha e administradores                                   */
/* -------------------------------------------------------------------------- */
async function testAccount() {
  console.log('\n[10] Conta, senha e administradores');

  const wrongCurrent = await request('/api/admin/change-password', {
    method: 'POST',
    body: { current_password: 'errada', new_password: 'NovaSenha123', new_password_confirm: 'NovaSenha123' },
  });
  check('Troca de senha exige a senha atual', wrongCurrent.status === 401);

  const weakNew = await request('/api/admin/change-password', {
    method: 'POST',
    body: { current_password: 'Panifica2026', new_password: 'abc', new_password_confirm: 'abc' },
  });
  check('Nova senha fraca e recusada', weakNew.status === 400);

  const noAdmins = await request('/api/admin/admins');
  check('Listagem de administradores funciona', noAdmins.status === 200 && noAdmins.data.admins.length === 1);

  const editor = await request('/api/admin/admins', {
    method: 'POST',
    body: { name: 'Editor Teste', email: 'editor@panificadorafrank.com', password: 'Editor2026x', role: 'editor' },
  });
  check('Segundo administrador criado', editor.status === 201, JSON.stringify(editor.data));

  const duplicated = await request('/api/admin/admins', {
    method: 'POST',
    body: { name: 'Duplicado', email: 'editor@panificadorafrank.com', password: 'Editor2026x' },
  });
  check('E-mail duplicado e recusado', duplicated.status === 400);

  const me = await request('/api/auth/me');
  const selfDelete = await request(`/api/admin/admins/${me.data.admin.id}`, { method: 'DELETE' });
  check('Nao permite excluir o proprio usuario', selfDelete.status === 400, JSON.stringify(selfDelete.data));

  const deleteEditor = await request(`/api/admin/admins/${editor.data.id}`, { method: 'DELETE' });
  check('Exclusao de outro administrador funciona', deleteEditor.status === 204, `status ${deleteEditor.status}`);
}

/* -------------------------------------------------------------------------- */
/* 11. Seguranca do banco                                                     */
/* -------------------------------------------------------------------------- */
async function testSecurity() {
  console.log('\n[11] Verificacoes de seguranca');

  const health = await request('/api/health');
  check('Health check nao expoe estrutura interna de senhas', !health.raw.includes('pbkdf2'));

  const me = await request('/api/auth/me');
  check('Sessao continua valida durante os testes', me.data?.authenticated === true);

  const badMethod = await request('/api/admin/settings/1', { method: 'DELETE' });
  check('Metodo nao suportado responde 405', badMethod.status === 405, `status ${badMethod.status}`);

  const anyProduct = (await request('/api/admin/products')).data.products[0];
  const patchProduct = await request(`/api/admin/products/${anyProduct.id}`, {
    method: 'PATCH',
    body: { name: anyProduct.name },
  });
  check('PATCH em produto e aceito como atualizacao parcial', patchProduct.status === 200, `status ${patchProduct.status}`);

  const unknown = await request('/api/rota-inexistente');
  check('Rota inexistente responde 404', unknown.status === 404);

  const unknownAdmin = await request('/api/admin/inexistente');
  check('Rota administrativa inexistente responde 404', unknownAdmin.status === 404);
}

/* -------------------------------------------------------------------------- */
/* Execucao                                                                   */
/* -------------------------------------------------------------------------- */
async function main() {
  console.log(`\nTestando a API em ${BASE}\n${'='.repeat(60)}`);

  resetLocalDatabase();

  try {
    await testStaticFiles();
    await testAuthProtection();
    await testSetup();
    await testSession();
    await testProducts();
    await testSections();
    await testSettingsAndContent();
    const mediaUrl = await testMedia();
    await testPublicSite(mediaUrl);
    await testAccount();
    await testSecurity();
  } catch (error) {
    failed += 1;
    failures.push(`Erro inesperado: ${error.message}`);
    console.error('\nErro inesperado:', error);
  }

  console.log(`\n${'='.repeat(60)}`);
  console.log(`Resultado: ${passed} aprovados, ${failed} falharam`);
  if (failures.length) {
    console.log('\nFalhas:');
    failures.forEach((f) => console.log(`  - ${f}`));
    process.exit(1);
  }
  console.log('Todos os testes passaram.\n');
}

main();
