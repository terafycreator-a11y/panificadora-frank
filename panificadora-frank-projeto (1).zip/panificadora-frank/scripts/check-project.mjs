#!/usr/bin/env node
/**
 * Verificacao do projeto antes da publicacao.
 *
 * Confere:
 *   - arquivos obrigatorios (Worker, site, painel, schema, configuracao)
 *   - sintaxe de todos os arquivos JavaScript
 *   - imports/exports entre os modulos do Worker
 *   - rotas da API referenciadas pelo front-end x rotas implementadas no Worker
 *   - configuracoes obrigatorias do wrangler.toml (D1, assets)
 *   - ausencia de segredos/senhas fixas no codigo
 *
 * Uso:
 *   npm run build:check
 */

import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

let problems = 0;
let warnings = 0;

function ok(message) {
  console.log(`  ok    ${message}`);
}

function problem(message) {
  problems += 1;
  console.log(`  ERRO  ${message}`);
}

function warn(message) {
  warnings += 1;
  console.log(`  aviso ${message}`);
}

function section(title) {
  console.log(`\n${title}`);
}

function read(relativePath) {
  return readFileSync(join(ROOT, relativePath), 'utf8');
}

function exists(relativePath) {
  return existsSync(join(ROOT, relativePath));
}

/* -------------------------------------------------------------------------- */
/* 1. Arquivos obrigatorios                                                   */
/* -------------------------------------------------------------------------- */
section('[1] Arquivos obrigatorios');

const REQUIRED_FILES = [
  'package.json',
  'wrangler.toml',
  'schema.sql',
  'migrations/0001_init.sql',
  'README.md',
  'src/index.js',
  'src/lib/util.js',
  'src/lib/auth.js',
  'src/routes/public.js',
  'src/routes/admin.js',
  'public/index.html',
  'public/assets/css/styles.css',
  'public/assets/js/site.js',
  'public/assets/img/favicon.svg',
  'public/admin/index.html',
  'public/admin/assets/admin.css',
  'public/admin/assets/admin.js',
  'scripts/create-admin.mjs',
  'scripts/e2e-test.mjs',
  'examples/dados-exemplo.sql',
];

for (const file of REQUIRED_FILES) {
  if (exists(file)) ok(file);
  else problem(`arquivo ausente: ${file}`);
}

/* -------------------------------------------------------------------------- */
/* 2. Sintaxe dos arquivos JavaScript                                         */
/* -------------------------------------------------------------------------- */
section('[2] Sintaxe de JavaScript');

function collectJs(dir, out = []) {
  for (const entry of readdirSync(join(ROOT, dir))) {
    const relative = `${dir}/${entry}`;
    const full = join(ROOT, relative);
    if (statSync(full).isDirectory()) {
      if (entry === 'node_modules' || entry === '.wrangler') continue;
      collectJs(relative, out);
    } else if (/\.(js|mjs)$/.test(entry)) {
      out.push(relative);
    }
  }
  return out;
}

const JS_FILES = [
  ...collectJs('src'),
  ...collectJs('public/assets/js'),
  ...collectJs('public/admin/assets'),
  ...collectJs('scripts'),
];

for (const file of JS_FILES) {
  try {
    execFileSync('node', ['--check', join(ROOT, file)], { stdio: 'pipe' });
    ok(`sintaxe ${file}`);
  } catch (error) {
    problem(`erro de sintaxe em ${file}: ${String(error.stderr || error.message).split('\n')[0]}`);
  }
}

/* -------------------------------------------------------------------------- */
/* 3. Imports e exports dos modulos do Worker                                 */
/* -------------------------------------------------------------------------- */
section('[3] Imports e exports do Worker');

function importsOf(source) {
  const list = [];
  const regex = /import\s+(?:[\s\S]*?)\s+from\s+['"]([^'"]+)['"]/g;
  let match;
  while ((match = regex.exec(source))) list.push(match[1]);
  return list;
}

/** Extrai pares { specifier, names } de cada declaracao de import nomeado. */
function importStatements(source) {
  const statements = [];
  const regex = /import\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"]/g;
  let match;
  while ((match = regex.exec(source))) {
    const names = match[1]
      .split(',')
      .map((part) => part.trim().split(/\s+as\s+/)[0].trim())
      .filter(Boolean);
    statements.push({ specifier: match[2], names });
  }
  return statements;
}

function exportedNames(source) {
  const names = new Set();
  const patterns = [
    /export\s+(?:async\s+)?function\s+([A-Za-z0-9_$]+)/g,
    /export\s+(?:const|let|var)\s+([A-Za-z0-9_$]+)/g,
    /export\s+class\s+([A-Za-z0-9_$]+)/g,
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(source))) names.add(match[1]);
  }
  return names;
}

function importedNames(source) {
  const names = new Set();
  const regex = /import\s+\{([^}]+)\}\s+from/g;
  let match;
  while ((match = regex.exec(source))) {
    match[1]
      .split(',')
      .map((part) => part.trim().split(/\s+as\s+/)[0].trim())
      .filter(Boolean)
      .forEach((name) => names.add(name));
  }
  return names;
}

const WORKER_FILES = ['src/index.js', 'src/lib/auth.js', 'src/routes/public.js', 'src/routes/admin.js'];

for (const file of WORKER_FILES) {
  const source = read(file);

  for (const { specifier, names } of importStatements(source)) {
    if (!specifier.startsWith('.')) {
      problem(`${file} importa modulo externo "${specifier}" (o Worker deve usar apenas caminhos relativos)`);
      continue;
    }
    const target = resolve(ROOT, dirname(file), specifier);
    if (!existsSync(target)) {
      problem(`${file} importa "${specifier}" que nao existe`);
      continue;
    }
    const targetRelative = target.replace(`${ROOT}/`, '');
    const targetSource = readFileSync(target, 'utf8');
    const available = exportedNames(targetSource);

    let missing = 0;
    for (const name of names) {
      if (!available.has(name)) {
        problem(`${file}: "${name}" nao esta exportado por ${targetRelative}`);
        missing += 1;
      }
    }
    if (!missing) ok(`${file} -> ${specifier} (${names.length} nome(s))`);
  }
}

// Confere se o que o index.js importa existe de fato nos modulos de destino.
const indexSource = read('src/index.js');
const indexImports = importedNames(indexSource);
const authExports = exportedNames(read('src/lib/auth.js'));
const publicExports = exportedNames(read('src/routes/public.js'));
const adminExports = exportedNames(read('src/routes/admin.js'));
const utilExports = exportedNames(read('src/lib/util.js'));
const allExports = new Set([...authExports, ...publicExports, ...adminExports, ...utilExports]);

for (const name of indexImports) {
  if (!allExports.has(name)) problem(`src/index.js importa "${name}", que nao foi encontrado nos modulos`);
}

if (indexImports.size) ok(`${indexImports.size} imports nomeados verificados em src/index.js`);

/* -------------------------------------------------------------------------- */
/* 4. Rotas: front-end x Worker                                               */
/* -------------------------------------------------------------------------- */
section('[4] Rotas da API usadas pelo front-end');

const adminJs = read('public/admin/assets/admin.js');
const siteJs = read('public/assets/js/site.js');

const frontEndCalls = new Set();
const callRegex = /(?:api\(|fetch\()\s*['"`]([^'"`]+)['"`]/g;
for (const source of [adminJs, siteJs]) {
  let match;
  while ((match = callRegex.exec(source))) {
    const path = match[1];
    if (path.startsWith('/api') || path.startsWith('/')) frontEndCalls.add(path);
  }
}

const workerSource = read('src/index.js');
for (const call of frontEndCalls) {
  const clean = call.replace('/api', '').replace(/\$\{[^}]+\}/g, ':id').replace(/\/$/, '');
  const base = clean.split('/')[1] || '';
  const known =
    workerSource.includes(`/api${clean}`) ||
    workerSource.includes(`'${clean}'`) ||
    ['site', 'products', 'media', 'health', 'setup', 'auth', 'admin'].includes(base);

  if (known) ok(`rota ${call}`);
  else warn(`rota ${call} nao foi localizada explicitamente em src/index.js`);
}

/* -------------------------------------------------------------------------- */
/* 5. Configuracao do Cloudflare                                              */
/* -------------------------------------------------------------------------- */
section('[5] Configuracao do Cloudflare (wrangler.toml)');

const wrangler = read('wrangler.toml');

if (/main\s*=\s*"src\/index\.js"/.test(wrangler)) ok('entrada do Worker (main) definida');
else problem('wrangler.toml sem "main" apontando para src/index.js');

if (/directory\s*=\s*"\.\/public"/.test(wrangler)) ok('pasta de arquivos estaticos definida');
else problem('wrangler.toml sem [assets] directory = "./public"');

if (/binding\s*=\s*"DB"/.test(wrangler)) ok('binding do banco D1 (DB) definido');
else problem('wrangler.toml sem binding DB');

if (/database_id\s*=\s*"COLE_AQUI_O_DATABASE_ID"/.test(wrangler)) {
  warn('database_id ainda e o valor de exemplo — troque pelo ID real antes do deploy');
} else if (/database_id\s*=\s*"[0-9a-f-]{36}"/.test(wrangler)) {
  ok('database_id preenchido');
}

if (/compatibility_date\s*=/.test(wrangler)) ok('compatibility_date definida');
else warn('wrangler.toml sem compatibility_date');

if (/account_id\s*=/.test(wrangler)) warn('account_id fixo no wrangler.toml (nao e obrigatorio)');

/* -------------------------------------------------------------------------- */
/* 6. Segredos e senhas fixas                                                 */
/* -------------------------------------------------------------------------- */
section('[6] Segredos e senhas fixas no codigo');

// Todo comando "node scripts/arquivo.mjs" precisa apontar para um arquivo existente.
const packageJson = JSON.parse(read('package.json'));
for (const [name, command] of Object.entries(packageJson.scripts || {})) {
  const match = /node\s+(scripts\/[^\s]+)/.exec(command);
  if (!match) {
    ok(`script "${name}" -> ${command}`);
    continue;
  }
  if (exists(match[1])) ok(`script "${name}" -> ${match[1]}`);
  else problem(`script "${name}" aponta para ${match[1]}, que nao existe`);
}

const SUSPICIOUS = [
  { pattern: /password\s*[:=]\s*['"][^'"]{3,}['"]/i, label: 'senha fixa no codigo' },
  { pattern: /api[_-]?key\s*[:=]\s*['"][^'"]{8,}['"]/i, label: 'chave de API fixa no codigo' },
  { pattern: /secret\s*[:=]\s*['"][^'"]{8,}['"]/i, label: 'segredo fixo no codigo' },
  { pattern: /Bearer\s+[A-Za-z0-9\-_.]{20,}/, label: 'token fixo no codigo' },
];

const SCAN_FILES = [...WORKER_FILES, 'public/assets/js/site.js', 'public/admin/assets/admin.js'];

for (const file of SCAN_FILES) {
  const source = read(file);
  for (const { pattern, label } of SUSPICIOUS) {
    const match = pattern.exec(source);
    if (match) {
      // Ignorar chaves de objeto comuns em payloads (ex.: password: password).
      const line = match[0];
      if (/password\s*[:=]\s*(password|next|confirm|payload|body|input)/i.test(line)) continue;
      problem(`${file}: possivel ${label} -> ${line.slice(0, 60)}`);
    }
  }
}
ok('varredura de segredos concluida');

// Garante que o hash de senha usa PBKDF2 e nunca texto puro.
const authSource = read('src/lib/auth.js');
if (authSource.includes('pbkdf2') && authSource.includes('hashPassword')) ok('senhas com hash PBKDF2');
else problem('o modulo de autenticacao nao usa hash PBKDF2');

if (/password_hash/.test(read('schema.sql'))) ok('banco guarda apenas o hash da senha');
else problem('tabela de admins nao tem coluna password_hash');

/* -------------------------------------------------------------------------- */
/* 7. Consistencia entre schema e codigo                                      */
/* -------------------------------------------------------------------------- */
section('[7] Consistencia entre schema e codigo');

const schema = read('schema.sql');
const TABLES = ['admins', 'sessions', 'media', 'sections', 'products', 'section_products', 'content_blocks', 'settings', 'login_attempts'];

for (const table of TABLES) {
  if (new RegExp(`CREATE TABLE IF NOT EXISTS ${table}\\b`).test(schema)) ok(`tabela ${table}`);
  else problem(`tabela ${table} ausente no schema.sql`);
}

const settingsKeys = read('src/routes/admin.js');
for (const key of ['company_name', 'whatsapp', 'instagram', 'google_maps_url', 'business_hours']) {
  if (schema.includes(`'${key}'`)) ok(`configuracao padrao ${key}`);
  else warn(`configuracao ${key} sem valor padrao no schema`);
  if (!settingsKeys.includes(key)) warn(`configuracao ${key} nao esta na lista de chaves aceitas`);
}

/* -------------------------------------------------------------------------- */
/* Resultado                                                                  */
/* -------------------------------------------------------------------------- */
console.log(`\n${'='.repeat(64)}`);
console.log(`Verificacao concluida: ${problems} erro(s), ${warnings} aviso(s).`);

if (problems > 0) {
  console.log('\nCorrija os erros acima antes de publicar.');
  process.exit(1);
}

console.log('Nenhum erro encontrado. Projeto pronto para publicar na Cloudflare.');
if (warnings > 0) console.log('Revise os avisos (nao impedem a publicacao).');
